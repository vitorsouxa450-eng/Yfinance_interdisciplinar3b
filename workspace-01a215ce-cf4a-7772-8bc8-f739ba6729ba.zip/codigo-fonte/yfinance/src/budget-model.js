// Shared, dependency-free budget rules. Snapshots preserve limits, not frozen expenses.
export const currentBudgetMonth = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" })
    .format(new Date())
    .slice(0, 7);
export function validMonth(month) {
  return (
    typeof month === "string" && /^(19|20)\d{2}-(0[1-9]|1[0-2])$/.test(month)
  );
}
function nextMonth(month) {
  const [y, m] = month.split("-").map(Number);
  return new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 7);
}
const entriesFrom = (categories) =>
  Object.fromEntries(
    categories
      .filter((c) => c.type === "expense")
      .map((c) => [
        c.id,
        { name: c.name, color: c.color || "#3b82f6", limit: c.budget || 0 },
      ]),
  );
export function ensureBudgetHistory(state, month = currentBudgetMonth()) {
  if (!validMonth(month)) throw new Error("Mês de orçamento inválido.");
  let changed = false;
  if (!state.budgetHistory) {
    state.budgetHistory = {};
    changed = true;
  }
  const months = Object.keys(state.budgetHistory).filter(validMonth).sort();
  if (!months.length) {
    state.budgetHistory[month] = {
      source: "initial",
      entries: entriesFrom(state.categories),
    };
    return true;
  }
  // Only advance the calendar. Never invent budgets from before the first snapshot.
  const last = months.at(-1);
  if (last > month)
    throw Object.assign(
      new Error(
        "O relógio do servidor está anterior ao histórico. Corrija a data antes de salvar.",
      ),
      { status: 409 },
    );
  if (last < month) {
    let previous = state.budgetHistory[last];
    for (
      let cursor = nextMonth(last);
      cursor <= month;
      cursor = nextMonth(cursor)
    ) {
      const entries = Object.fromEntries(
        state.categories
          .filter((c) => c.type === "expense")
          .map((c) => [
            c.id,
            {
              name: c.name,
              color: c.color || "#3b82f6",
              limit: previous.entries[c.id]?.limit ?? c.budget ?? 0,
            },
          ]),
      );
      state.budgetHistory[cursor] = { source: "carried", entries };
      previous = state.budgetHistory[cursor];
      changed = true;
    }
    for (const c of state.categories)
      if (c.type === "expense")
        c.budget = state.budgetHistory[month].entries[c.id]?.limit ?? 0;
  }
  return changed;
}
export function syncCurrentBudgets(state, month = currentBudgetMonth()) {
  let changed = ensureBudgetHistory(state, month);
  // A clock that moves backwards must not rewrite an archived snapshot.
  const latest = Object.keys(state.budgetHistory).sort().at(-1);
  if (latest !== month)
    throw Object.assign(
      new Error(
        "O relógio do servidor está anterior ao histórico. Corrija a data antes de salvar.",
      ),
      { status: 409 },
    );
  const entries = entriesFrom(state.categories);
  if (
    JSON.stringify(state.budgetHistory[month].entries) !==
    JSON.stringify(entries)
  ) {
    state.budgetHistory[month] = { ...state.budgetHistory[month], entries };
    changed = true;
  }
  return changed;
}
export function budgetEntries(state, month) {
  return state.budgetHistory?.[month]?.entries || null;
}
export function budgetLimit(state, categoryId, month) {
  return budgetEntries(state, month)?.[categoryId]?.limit ?? null;
}
export function budgetRows(state, month) {
  const entries = budgetEntries(state, month);
  const ids = new Set([
    ...Object.keys(entries || {}),
    ...state.transactions
      .filter((t) => t.type === "expense" && t.date.startsWith(month))
      .map((t) => t.categoryId),
  ]);
  if (month === currentBudgetMonth())
    for (const c of state.categories.filter((c) => c.type === "expense"))
      ids.add(c.id);
  return [...ids].map((id) => {
    const c = state.categories.find((c) => c.id === id),
      saved = entries?.[id];
    const spent =
      state.transactions
        .filter(
          (t) =>
            t.type === "expense" &&
            t.categoryId === id &&
            t.date.startsWith(month),
        )
        .reduce((n, t) => n + Math.round(t.amount * 100), 0) / 100;
    return {
      id,
      name: saved?.name || c?.name || "Categoria removida",
      color: saved?.color || c?.color || "#3b82f6",
      limit: saved?.limit ?? null,
      spent,
    };
  });
}
