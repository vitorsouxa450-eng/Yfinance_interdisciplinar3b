import { dueDate, validDate, todayBR } from "./schedule-model.js";
import { validMonth } from "./budget-model.js";
export function shiftMonth(month, offset) {
  if (!validMonth(month) || !Number.isInteger(offset))
    throw new Error("Mês inválido.");
  const [y, m] = month.split("-").map(Number);
  const next = new Date(Date.UTC(y, m - 1 + offset, 1))
    .toISOString()
    .slice(0, 7);
  return validMonth(next) ? next : month;
}
export function monthDays(month) {
  if (!validMonth(month))
    throw new Error("Selecione um mês válido entre 1900 e 2099.");
  const [y, m] = month.split("-").map(Number),
    count = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return {
    offset: (new Date(Date.UTC(y, m - 1, 1)).getUTCDay() + 6) % 7,
    days: Array.from(
      { length: count },
      (_, i) => `${month}-${String(i + 1).padStart(2, "0")}`,
    ),
  };
}
// Seek directly to the queried month, instead of walking years of daily rules.
function firstIndex(rule, start) {
  const a = new Date(rule.startDate + "T00:00:00Z"),
    b = new Date(start + "T00:00:00Z");
  const days = Math.floor((b - a) / 86400000);
  const estimate =
    rule.frequency === "daily"
      ? days
      : rule.frequency === "weekly"
        ? Math.floor(days / 7)
        : rule.frequency === "monthly"
          ? (b.getUTCFullYear() - a.getUTCFullYear()) * 12 +
            b.getUTCMonth() -
            a.getUTCMonth()
          : b.getUTCFullYear() - a.getUTCFullYear();
  let index = Math.max(0, rule.nextIndex || 0, estimate);
  while (dueDate(rule, index) < start) index++;
  return index;
}
export function calendarEvents(state, month, today = todayBR()) {
  const { days } = monthDays(month),
    start = days[0],
    end = days.at(-1),
    events = [];
  for (const t of state.transactions || [])
    if (t.recurringId && t.date >= start && t.date <= end)
      events.push({
        id: `posted:${t.id}`,
        date: t.date,
        title: t.description,
        kind: t.type,
        status: "recorded",
        amount: t.amount,
        page: t.type === "income" ? "receitas" : "despesas",
      });
  const posted = new Set(
    (state.transactions || [])
      .filter((t) => t.recurringId)
      .map((t) => `${t.recurringId}:${t.date}`),
  );
  for (const rule of state.recurring || []) {
    if (
      rule.status !== "active" ||
      !validDate(rule.startDate) ||
      !["daily", "weekly", "monthly", "yearly"].includes(rule.frequency)
    )
      continue;
    if (
      !(state.categories || []).some(
        (c) => c.id === rule.categoryId && c.type === rule.type,
      )
    )
      continue;
    for (let index = firstIndex(rule, start); ; index++) {
      const date = dueDate(rule, index);
      if (
        date > end ||
        (rule.endDate && date > rule.endDate) ||
        (rule.limit && index >= rule.limit)
      )
        break;
      if (!posted.has(`${rule.id}:${date}`))
        events.push({
          id: `forecast:${rule.id}:${index}`,
          date,
          title: rule.description,
          kind: rule.type,
          status: date < today ? "pending" : "forecast",
          amount: rule.amount,
          page: "recorrencias",
        });
    }
  }
  for (const goal of state.goals || [])
    if (validDate(goal.date) && goal.date >= start && goal.date <= end)
      events.push({
        id: `goal:${goal.id}`,
        date: goal.date,
        title: goal.name,
        kind: "goal",
        status:
          goal.current >= goal.target
            ? "completed"
            : goal.date < today
              ? "overdue"
              : "deadline",
        amount: Math.max(
          0,
          Math.round((goal.target - goal.current) * 100) / 100,
        ),
        page: "metas",
      });
  return events.sort(
    (a, b) =>
      a.date.localeCompare(b.date) ||
      a.kind.localeCompare(b.kind) ||
      a.title.localeCompare(b.title, "pt-BR"),
  );
}
export function calendarSummary(events) {
  const forecast = events.filter(
    (e) => e.status === "forecast" || e.status === "pending",
  );
  const sum = (kind) =>
    forecast
      .filter((e) => e.kind === kind)
      .reduce((n, e) => n + Math.round(e.amount * 100), 0) / 100;
  return {
    income: sum("income"),
    expense: sum("expense"),
    goals: events.filter((e) => e.kind === "goal" && e.status !== "completed")
      .length,
  };
}
