import React, { useState } from "react";
import { BookOpen, ArrowRight, ShieldCheck, Lightbulb } from "lucide-react";
import { studyGoals, studyRecommendations } from "./study-model.js";
import "./release.css";
export default function StudyReview({ state, openLesson }) {
  const [focus, setFocus] = useState("all"),
    [showAll, setShowAll] = useState(false);
  const recommendations = studyRecommendations(state, focus),
    reviewCount = recommendations.filter((r) => r.kind === "review").length,
    display = showAll ? recommendations : recommendations.slice(0, 3);
  return (
    <section className="study-review">
      <div className="card sim-hero">
        <span className="planning-icon">
          <Lightbulb size={25} />
        </span>
        <div>
          <span className="sim-eyebrow">UM PRÓXIMO PASSO EXPLICADO</span>
          <h2>Retome o que merece atenção.</h2>
          <p>
            Sugestões locais com base na sua última tentativa concluída e no
            assunto que você escolher. Sem julgamentos, sem chave de IA e sem
            bloquear seu caminho.
          </p>
        </div>
      </div>
      <div className="study-controls">
        <label>
          O que você quer aprender agora?
          <select
            aria-label="Objetivo da revisão"
            value={focus}
            onChange={(e) => {
              setFocus(e.target.value);
              setShowAll(false);
            }}
          >
            {studyGoals.map((g) => (
              <option key={g.id} value={g.id}>
                {g.label}
              </option>
            ))}
          </select>
        </label>
        <p role="status">
          {reviewCount
            ? `${reviewCount} aula(s) com pontos para revisar neste assunto.`
            : "Nenhum erro pendente nos quizzes concluídos deste assunto."}
        </p>
      </div>
      <details className="card study-method">
        <summary>Como estas sugestões são escolhidas?</summary>
        <p>
          O assunto selecionado filtra as aulas. Primeiro aparecem as que
          tiveram erros na última tentativa concluída, com mais erros antes.
          Depois vêm aulas sem quiz concluído e, por último, aulas cuja última
          tentativa foi totalmente correta. Empates seguem a ordem das aulas.
        </p>
        <p>
          Um rascunho não substitui sua última tentativa concluída. Sua melhor
          nota não diminui; uma tentativa mais recente pode indicar algo útil
          para retomar, mesmo que você já tenha sido aprovado. A seleção de
          assunto é temporária e não analisa seus gastos nem seu perfil pessoal.
        </p>
      </details>
      <div className="study-cards">
        {display.map((r) => (
          <article className="card study-card" key={r.id}>
            <div className="study-card-top">
              <span className="release-kicker">
                Aula {String(r.id + 1).padStart(2, "0")} · {r.duration}
              </span>
              <span className="study-tag">
                {r.kind === "review"
                  ? "Revisar"
                  : r.kind === "start"
                    ? "Explorar"
                    : "Consolidar"}
              </span>
            </div>
            <h3>{r.title}</h3>
            <p>{r.reason}</p>
            {r.mistakes.length > 0 && (
              <details>
                <summary>Ver os pontos da tentativa {r.attempt}</summary>
                <ul>
                  {r.mistakes.map((q) => (
                    <li key={q.index}>
                      <strong>
                        {q.index + 1}. {q.prompt}
                      </strong>
                      <p>
                        <b>Resposta esperada:</b> {q.correct}
                      </p>
                      <p>{q.explanation}</p>
                    </li>
                  ))}
                </ul>
              </details>
            )}
            <div className="study-actions">
              <button className="secondary" onClick={() => openLesson(r.id)}>
                <BookOpen size={15} />
                Ler a aula
              </button>
              <button
                className="primary"
                onClick={() =>
                  openLesson(r.id, r.kind === "practice" ? "desafio" : "quiz")
                }
              >
                {r.kind === "practice" ? "Abrir prática" : "Abrir quiz"}
                <ArrowRight size={15} />
              </button>
            </div>
          </article>
        ))}
      </div>
      {recommendations.length > 3 && (
        <button className="secondary" onClick={() => setShowAll((v) => !v)}>
          {showAll
            ? "Mostrar apenas 3 sugestões"
            : `Ver as ${recommendations.length} aulas do assunto`}
        </button>
      )}
      <p className="release-note">
        <ShieldCheck size={16} />
        As sugestões não marcam aulas como concluídas nem mudam suas respostas.
        Não são avaliação profissional ou recomendação individual de
        investimento.
      </p>
    </section>
  );
}
