let csrf = "",
  accountId = "";
const channel =
  typeof BroadcastChannel !== "undefined"
    ? new BroadcastChannel("yf-session-boundary")
    : null;
if (channel) channel.onmessage = () => location.assign("/login");
export const csrfHeaders = () => ({
  "X-CSRF-Token": csrf,
  ...(accountId ? { "X-Account-Context": accountId } : {}),
});
export async function api(url, body) {
  const legacy = ["bootstrap", "auth/claim-legacy"].includes(url)
    ? localStorage.getItem("yf-token")
    : null;
  const r = await fetch("/api/" + url, {
    method: body === undefined ? "GET" : "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      ...csrfHeaders(),
      ...(legacy ? { Authorization: "Bearer " + legacy } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const incoming = r.headers.get("x-account-id");
  if (
    incoming &&
    accountId &&
    incoming !== accountId &&
    !url.startsWith("auth/")
  ) {
    window.dispatchEvent(new Event("yf-session-expired"));
    throw Error("A conta mudou. Recarregue antes de continuar.");
  }
  if (incoming) accountId = incoming;
  const token = r.headers.get("x-csrf-token");
  if (token) csrf = token;
  const data = await r.json();
  if (!r.ok) {
    if (
      r.status === 401 &&
      ["state", "action", "chat", "account"].includes(url)
    )
      window.dispatchEvent(new Event("yf-session-expired"));
    throw Object.assign(Error(data.error || "Não foi possível concluir."), {
      status: r.status,
    });
  }
  if (data.state) localStorage.removeItem("yf-token");
  if (
    url === "logout" ||
    url === "account/delete" ||
    url === "account/password" ||
    url === "account/2fa/disable" ||
    url === "auth/reset-password" ||
    (url.startsWith("auth/") && data.state)
  )
    channel?.postMessage("changed");
  return data;
}
