import React, { useState } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  ArrowUpRight,
  Info,
  Target,
  TrendingUp,
  Receipt,
} from "lucide-react";
import {
  calendarEvents,
  calendarSummary,
  monthDays,
  shiftMonth,
} from "./calendar-model.js";
import { todayBR } from "./schedule-model.js";
import { validMonth } from "./budget-model.js";
import "./release.css";
const names = { income: "Receita", expense: "Despesa", goal: "Meta" };
const statuses = {
  forecast: "Previsto · não lançado",
  pending: "Pendente de processamento",
  recorded: "Registrado · não confirma pagamento",
  completed: "Meta alcançada",
  overdue: "Prazo passado · meta em aberto",
  deadline: "Prazo da meta",
};
const label = (d) =>
  new Date(d + "T12:00:00Z").toLocaleDateString("pt-BR", {
    timeZone: "UTC",
    day: "2-digit",
    month: "short",
  });
export default function FinancialCalendar({ state, money, go }) {
  const today = todayBR(),
    [month, setMonth] = useState(today.slice(0, 7)),
    [selected, setSelected] = useState(null),
    [filter, setFilter] = useState("all");
  const events = calendarEvents(state, month, today),
    summary = calendarSummary(events),
    grid = monthDays(month),
    filtered = events.filter((e) => filter === "all" || e.kind === filter),
    visible = filtered.filter((e) => !selected || e.date === selected);
  const choose = (m) => {
    if (validMonth(m)) {
      setMonth(m);
      setSelected(null);
    }
  };
  return (
    <div className="release-page">
      <header className="release-heading">
        <span className="planning-icon">
          <CalendarDays size={25} />
        </span>
        <div>
          <h1>Seu calendário financeiro</h1>
          <p>
            Vencimentos e objetivos no mesmo lugar. Uma previsão, não um extrato
            bancário.
          </p>
        </div>
      </header>
      <div className="card release-callout">
        <Info size={19} />
        <p>
          As previsões usam as regras <strong>ativas</strong>. Pausadas e
          encerradas não geram previsões; seus lançamentos já registrados
          continuam visíveis. Prazos de metas não são cobranças. O calendário
          não paga contas, não gera lançamentos e não envia lembretes externos.
        </p>
      </div>
      <div className="calendar-summary">
        <div className="card">
          <TrendingUp size={20} />
          <span>Receitas recorrentes ainda previstas</span>
          <strong>{money(summary.income)}</strong>
        </div>
        <div className="card">
          <Receipt size={20} />
          <span>Despesas recorrentes ainda previstas</span>
          <strong>{money(summary.expense)}</strong>
        </div>
        <div className="card">
          <Target size={20} />
          <span>Metas em aberto com prazo no mês</span>
          <strong>{summary.goals}</strong>
        </div>
      </div>
      <div className="calendar-controls">
        <div>
          <button
            className="secondary"
            aria-label="Mês anterior do calendário"
            disabled={month === "1900-01"}
            onClick={() => choose(shiftMonth(month, -1))}
          >
            <ChevronLeft size={17} />
          </button>
          <label>
            <span className="release-sr">Mês do calendário</span>
            <input
              aria-label="Mês do calendário"
              type="month"
              min="1900-01"
              max="2099-12"
              value={month}
              onChange={(e) => choose(e.target.value)}
            />
          </label>
          <button
            className="secondary"
            aria-label="Próximo mês do calendário"
            disabled={month === "2099-12"}
            onClick={() => choose(shiftMonth(month, 1))}
          >
            <ChevronRight size={17} />
          </button>
          <button
            className="secondary"
            onClick={() => choose(today.slice(0, 7))}
          >
            Mês atual
          </button>
        </div>
        <label className="calendar-filter">
          Mostrar
          <select
            aria-label="Filtrar eventos do calendário"
            value={filter}
            onChange={(e) => {
              setFilter(e.target.value);
              setSelected(null);
            }}
          >
            <option value="all">Todos os eventos</option>
            <option value="expense">Despesas recorrentes</option>
            <option value="income">Receitas recorrentes</option>
            <option value="goal">Prazos de metas</option>
          </select>
        </label>
      </div>
      <div className="calendar-layout">
        <section className="card calendar-month" aria-label="Dias do mês">
          <div className="calendar-week" aria-hidden="true">
            {["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"].map((d) => (
              <span key={d}>{d}</span>
            ))}
          </div>
          <div className="calendar-grid">
            {Array.from({ length: grid.offset }, (_, i) => (
              <span aria-hidden="true" key={"blank" + i} />
            ))}
            {grid.days.map((date) => {
              const items = filtered.filter((e) => e.date === date);
              return (
                <button
                  key={date}
                  className={
                    (date === today ? "today " : "") +
                    (date === selected ? "selected" : "")
                  }
                  aria-pressed={date === selected}
                  aria-current={date === today ? "date" : undefined}
                  aria-label={`${label(date)}${date === today ? ", hoje" : ""}, ${items.length} evento(s)`}
                  onClick={() => setSelected(date === selected ? null : date)}
                >
                  <strong>{Number(date.slice(-2))}</strong>
                  <span className="calendar-dots" aria-hidden="true">
                    {["income", "expense", "goal"]
                      .filter((k) => items.some((e) => e.kind === k))
                      .map((k) => (
                        <i key={k} className={k} />
                      ))}
                  </span>
                  {items.length > 0 && (
                    <small aria-hidden="true">{items.length}</small>
                  )}
                </button>
              );
            })}
          </div>
          <p className="calendar-legend">
            <span>
              <i className="income" />
              Receita
            </span>
            <span>
              <i className="expense" />
              Despesa
            </span>
            <span>
              <i className="goal" />
              Meta
            </span>
          </p>
          <p className="planning-note">
            Selecione um dia para filtrar a agenda. Os totais acima consideram o
            mês inteiro, sem incluir lançamentos já registrados nem valores de
            metas.
          </p>
        </section>
        <section
          className="card calendar-agenda"
          aria-label="Agenda de eventos"
        >
          <div className="release-section-title">
            <h2>
              {selected ? `Agenda de ${label(selected)}` : "Agenda do mês"}
            </h2>
            {selected && (
              <button className="text-btn" onClick={() => setSelected(null)}>
                Ver mês inteiro
              </button>
            )}
          </div>
          <p className="planning-note" role="status">
            {visible.length} evento(s) neste recorte
          </p>
          {!visible.length ? (
            <div className="release-empty">
              <CalendarDays size={30} />
              <h3>Nenhum evento neste recorte</h3>
              <p>
                Cadastre uma recorrência ativa ou uma meta com prazo.
                Lançamentos manuais não fazem parte desta agenda.
              </p>
              <button className="secondary" onClick={() => go("recorrencias")}>
                Ver recorrências
              </button>
            </div>
          ) : (
            <ul className="calendar-events">
              {visible.map((e) => (
                <li key={e.id}>
                  <span className="calendar-event-date">{label(e.date)}</span>
                  <div>
                    <span className="release-kicker">{names[e.kind]}</span>
                    <h3>{e.title}</h3>
                    <p>{statuses[e.status]}</p>
                    <strong>
                      {e.kind === "goal" ? "Falta guardar: " : ""}
                      {money(e.amount)}
                    </strong>
                  </div>
                  <button
                    className="icon-btn"
                    aria-label={`Abrir ${e.kind === "goal" ? "metas" : "registros"}: ${e.title}`}
                    onClick={() => go(e.page)}
                  >
                    <ArrowUpRight size={18} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
