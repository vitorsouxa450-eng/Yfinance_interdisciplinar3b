import React, { useRef, useState, useEffect } from "react";
import {
  Upload,
  ShieldCheck,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  LoaderCircle,
  Download,
  Undo2,
  Eye,
  ChevronLeft,
  ChevronRight,
  X,
  Info,
} from "lucide-react";
import "./excel-import.css";
const fieldNames = {
  description: "Descrição",
  amount: "Valor",
  date: "Data / prazo",
  categoryId: "Categoria",
  payment: "Pagamento",
  notes: "Observações",
  name: "Nome",
  category: "Categoria da meta",
  target: "Objetivo",
  current: "Acumulado",
  color: "Cor",
  budget: "Limite mensal",
  type: "Tipo",
  frequency: "Frequência",
  startDate: "Início",
  endDate: "Data final",
  limit: "Limite de datas",
  status: "Situação",
};
const enumLabels = {
  income: "Receita",
  expense: "Despesa",
  active: "Ativa",
  paused: "Pausada",
  ended: "Encerrada",
  daily: "Diária",
  weekly: "Semanal",
  monthly: "Mensal",
  yearly: "Anual",
};
export default function ExcelImport({
  state,
  request,
  info,
  busy,
  hidden,
  onReveal,
}) {
  const [file, setFile] = useState(null),
    [preview, setPreview] = useState(null),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [confirmed, setConfirmed] = useState(false),
    [page, setPage] = useState(0),
    [filter, setFilter] = useState("all"),
    [pending, setPending] = useState(false),
    [undoConfirm, setUndoConfirm] = useState(false);
  const picker = useRef(),
    alive = useRef(true),
    locked = useRef(false);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  const working = busy || pending;
  function reset() {
    setPreview(null);
    setConfirmed(false);
    setPage(0);
    setFilter("all");
    setError("");
    setMessage("");
  }
  async function run(task) {
    if (locked.current || busy) return;
    locked.current = true;
    setPending(true);
    setError("");
    try {
      await task();
    } catch (e) {
      if (alive.current) setError(e.message);
    } finally {
      locked.current = false;
      if (alive.current) setPending(false);
    }
  }
  async function analyze() {
    if (!file) return;
    await run(async () => {
      setPreview(null);
      setConfirmed(false);
      setMessage("");
      const result = await request("preview", file);
      if (alive.current) {
        setPreview(result.preview);
        setPage(0);
        setFilter("all");
      }
    });
  }
  async function cancel() {
    await run(async () => {
      if (preview) await request("cancel", { previewId: preview.previewId });
      if (alive.current) {
        reset();
        setFile(null);
        if (picker.current) picker.current.value = "";
      }
    });
  }
  async function commit() {
    if (!confirmed || !preview) return;
    await run(async () => {
      try {
        const result = await request("commit", {
          previewId: preview.previewId,
          confirm: true,
        });
        if (alive.current) {
          setPreview(null);
          setConfirmed(false);
          setFile(null);
          setMessage(result.importMessage);
          if (picker.current) picker.current.value = "";
        }
      } catch (e) {
        if (e.status === 409 && alive.current) {
          setPreview(null);
          setConfirmed(false);
        }
        throw e;
      }
    });
  }
  async function undo() {
    await run(async () => {
      const result = await request("undo", {
        backupId: info.id,
        confirm: true,
      });
      if (alive.current) {
        reset();
        setUndoConfirm(false);
        setMessage(result.importMessage);
      }
    });
  }
  async function downloadBackup() {
    await run(async () => {
      const blob = await request(`backup/${info.id}`, null, true);
      const url = URL.createObjectURL(blob),
        a = document.createElement("a");
      a.href = url;
      a.download = "YFinance-backup-antes-da-importacao.json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }
  function value(name, v) {
    if (v == null || v === "") return "—";
    if (name === "categoryId")
      return (
        state.categories.find((c) => c.id === v)?.name ||
        "Categoria indisponível"
      );
    if (["amount", "target", "current", "budget"].includes(name))
      return Number(v).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL",
      });
    return enumLabels[v] || String(v);
  }
  const changes = (preview?.changes || []).filter(
      (c) => filter === "all" || c.entity === filter,
    ),
    pages = Math.max(1, Math.ceil(changes.length / 25));
  if (hidden)
    return (
      <section className="card excel-import import-private">
        <ShieldCheck size={30} />
        <h2>Revise os dados com privacidade</h2>
        <p>
          A prévia e o backup contêm valores completos. Revele os valores para
          selecionar, revisar ou confirmar uma importação.
        </p>
        <button className="primary" onClick={onReveal}>
          <Eye size={17} />
          Mostrar valores e importar
        </button>
      </section>
    );
  return (
    <div className="excel-import">
      <section className="card import-intro">
        <div className="import-title-icon">
          <Upload size={25} />
        </div>
        <div>
          <span className="finance-eyebrow">EXCEL → Y FINANCE</span>
          <h2>Do planejamento à atualização, com revisão.</h2>
          <p>
            Atualize receitas, despesas, orçamentos, metas e recorrências usando
            uma planilha exportada por esta conta. Primeiro confira a prévia. Só
            depois confirme.
          </p>
        </div>
        <span className="import-safe">
          <ShieldCheck size={16} />
          Sem exclusões automáticas
        </span>
      </section>
      <div className="import-steps">
        <span>
          <b>1</b> Exporte e edite
        </span>
        <span>
          <b>2</b> Analise e revise
        </span>
        <span>
          <b>3</b> Confirme no site
        </span>
      </div>
      <details className="card import-guide">
        <summary>Como preparar a planilha e quais campos posso editar?</summary>
        <div>
          <p>
            <strong>Use uma exportação nova desta versão.</strong> Arquivos
            antigos, de outra conta ou de outra instalação são rejeitados. Não
            remova a aba técnica, os cabeçalhos da linha 5 ou os
            identificadores.
          </p>
          <ul>
            <li>
              <strong>Receitas e despesas:</strong> data, descrição, categoria
              pelo nome, pagamento, valor e observações. A origem recorrente é
              preservada.
            </li>
            <li>
              <strong>Metas:</strong> nome, categoria, objetivo, acumulado
              absoluto, prazo e cor. O acumulado substitui o valor, não
              acrescenta um aporte.
            </li>
            <li>
              <strong>Orçamentos:</strong> limite do mês atual, preservando
              meses anteriores da categoria. Se a categoria aparece em vários
              meses, basta alterar um deles; limites diferentes entre linhas
              editadas são rejeitados.
            </li>
            <li>
              <strong>Recorrências:</strong> descrição, categoria, valor, fim,
              limite, pagamento, observações e pausa/encerramento. Novas regras
              entram pausadas. Ativação, retomada e mudança do calendário de uma
              regra existente são feitas no aplicativo.
            </li>
            <li>
              <strong>Novas linhas:</strong> preserve as colunas e deixe
              Identificador vazio. Use categorias já cadastradas no site; para
              novos lançamentos, Origem deve ser Manual ou vazia. IDs nunca
              devem ser renumerados.
            </li>
          </ul>
          <p>
            Resumo, gráficos, fórmulas de totais e colunas calculadas não são
            importados. Nos campos editáveis, use valores diretos: números do
            Excel ou texto brasileiro (1.234,56), e datas DD/MM/AAAA ou
            AAAA-MM-DD. Linhas apagadas do Excel não apagam dados do site.
          </p>
          <p>
            <strong>Uma exportação, uma rodada de alterações.</strong> Depois de
            importar, exporte uma nova planilha antes de editar novamente.
            Reenviar o mesmo arquivo não duplica a importação.
          </p>
          <p>
            Limites: .xlsx, até 8 MB, 20 mil linhas e 64 MB descompactados. Sem
            macros, senhas, links externos ou fórmulas em campos editáveis.
          </p>
        </div>
      </details>
      {error && (
        <div className="import-message error" role="alert">
          <AlertTriangle size={20} />
          <p>{error}</p>
        </div>
      )}
      {message && (
        <div className="import-message success" role="status">
          <CheckCircle2 size={20} />
          <p>{message}</p>
        </div>
      )}
      {!preview && (
        <section className="card import-upload">
          <FileSpreadsheet size={37} />
          <h3>Selecione sua planilha Y Finance</h3>
          <p>
            O arquivo é analisado em memória. Escolher ou analisar não altera
            seus registros.
          </p>
          <label className="import-file-label">
            Arquivo .xlsx
            <input
              ref={picker}
              aria-label="Planilha para importar"
              type="file"
              accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              disabled={working}
              onChange={(e) => {
                reset();
                const selected = e.target.files?.[0];
                setFile(null);
                if (!selected) return;
                if (
                  !selected.name.toLowerCase().endsWith(".xlsx") ||
                  selected.size > 8 * 1024 * 1024 ||
                  !selected.size
                ) {
                  setError("Escolha uma planilha .xlsx não vazia de até 8 MB.");
                  e.target.value = "";
                  return;
                }
                setFile(selected);
              }}
            />
          </label>
          {file && (
            <p className="import-file-name">
              {file.name} · {(file.size / 1024).toFixed(0)} KB
            </p>
          )}
          <button
            className="primary"
            disabled={!file || working}
            onClick={analyze}
          >
            {working ? (
              <LoaderCircle className="spin" size={17} />
            ) : (
              <ShieldCheck size={17} />
            )}
            Analisar sem salvar
          </button>
        </section>
      )}
      {preview && (
        <section className="card import-review">
          <div className="import-review-heading">
            <div>
              <span className="finance-eyebrow">PRÉVIA · AINDA NÃO SALVO</span>
              <h2>
                {preview.alreadyImported
                  ? "Arquivo já processado"
                  : "Confira antes de confirmar"}
              </h2>
              <p>
                {preview.rows} linha(s) analisada(s). Prévia válida até{" "}
                {new Date(preview.expiresAt).toLocaleTimeString("pt-BR", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
                .
              </p>
            </div>
            <button className="secondary" disabled={working} onClick={cancel}>
              <X size={16} />
              Cancelar prévia
            </button>
          </div>
          <div className="import-counts">
            <div>
              <strong>{preview.counts.add}</strong>
              <span>Novos registros</span>
            </div>
            <div>
              <strong>{preview.counts.update}</strong>
              <span>Atualizações</span>
            </div>
            <div>
              <strong>0</strong>
              <span>Exclusões</span>
            </div>
            <div>
              <strong>{preview.errors.length}</strong>
              <span>Erros a corrigir</span>
            </div>
          </div>
          {preview.errors.length > 0 && (
            <div className="import-problems" role="alert">
              <h3>Nada será importado enquanto houver erros</h3>
              <p>
                São exibidos até 100 erros. Corrija o arquivo e faça uma nova
                análise.
              </p>
              <ul>
                {preview.errors.map((e, i) => (
                  <li key={i}>
                    <strong>
                      {e.sheet}, linha {e.row}:
                    </strong>{" "}
                    {e.message}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="import-notices">
            <h3>
              <Info size={16} />O que esta importação faz
            </h3>
            <ul>
              {preview.warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          </div>
          {preview.counts.total === 0 && !preview.errors.length && (
            <p className="import-empty">
              Não há alterações novas para confirmar. Os dados do aplicativo
              foram preservados.
            </p>
          )}
          {preview.counts.total > 0 && (
            <>
              <div className="import-filter">
                <label>
                  Filtrar alterações
                  <select
                    value={filter}
                    onChange={(e) => {
                      setFilter(e.target.value);
                      setPage(0);
                    }}
                  >
                    <option value="all">Todas as áreas</option>
                    <option value="transactions">Receitas e despesas</option>
                    <option value="categories">Orçamentos</option>
                    <option value="goals">Metas</option>
                    <option value="recurring">Recorrências</option>
                  </select>
                </label>
                <span>
                  {changes.length} alteração(ões) · Página {page + 1} de {pages}
                </span>
              </div>
              <div className="import-changes">
                {changes.slice(page * 25, page * 25 + 25).map((change, i) => (
                  <article
                    className="import-change"
                    key={`${change.entity}:${change.id}:${i}`}
                  >
                    <header>
                      <span
                        className={`badge ${change.action === "add" ? "green" : "blue"}`}
                      >
                        {change.action === "add" ? "Acrescentar" : "Atualizar"}
                      </span>
                      <h3>{change.after.description || change.after.name}</h3>
                      <small>
                        {change.sheet} · linha {change.row}
                      </small>
                    </header>
                    <div
                      className="import-diff"
                      role="region"
                      tabIndex={0}
                      aria-label={`Alterações em ${change.after.description || change.after.name}`}
                    >
                      <table>
                        <thead>
                          <tr>
                            <th>Campo</th>
                            <th>No site agora</th>
                            <th>Depois de confirmar</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Object.keys(change.after)
                            .filter(
                              (k) =>
                                k !== "id" &&
                                (!change.before ||
                                  change.before[k] !== change.after[k]),
                            )
                            .map((k) => (
                              <tr key={k}>
                                <th>{fieldNames[k] || k}</th>
                                <td>
                                  {change.before
                                    ? value(k, change.before[k])
                                    : "Novo registro"}
                                </td>
                                <td>{value(k, change.after[k])}</td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </article>
                ))}
              </div>
              <div className="import-pagination">
                <button
                  className="secondary"
                  aria-label="Página anterior de alterações"
                  disabled={page === 0}
                  onClick={() => setPage((p) => p - 1)}
                >
                  <ChevronLeft size={16} />
                  Anterior
                </button>
                <span>
                  {page + 1} / {pages}
                </span>
                <button
                  className="secondary"
                  aria-label="Próxima página de alterações"
                  disabled={page + 1 >= pages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Próxima
                  <ChevronRight size={16} />
                </button>
              </div>
            </>
          )}
          <div className="import-confirm">
            <label>
              <input
                type="checkbox"
                checked={confirmed}
                disabled={
                  working || !!preview.errors.length || !preview.counts.total
                }
                onChange={(e) => setConfirmed(e.target.checked)}
              />
              <span>
                Revisei as alterações e os avisos. Autorizo atualizar e
                acrescentar os registros exibidos, sem excluir dados.
              </span>
            </label>
            <p>
              Um backup financeiro anterior será preservado. Se os dados mudarem
              antes da confirmação, a prévia será bloqueada para nova análise.
            </p>
            <button
              className="primary"
              disabled={
                !confirmed ||
                working ||
                !!preview.errors.length ||
                !preview.counts.total
              }
              onClick={commit}
            >
              {working ? (
                <LoaderCircle className="spin" size={17} />
              ) : (
                <CheckCircle2 size={17} />
              )}
              Confirmar importação
            </button>
          </div>
        </section>
      )}
      {info && (
        <section className="card import-backup">
          <div>
            <h2>Última importação</h2>
            <p>
              {new Date(info.at).toLocaleString("pt-BR")} · {info.counts.add}{" "}
              novo(s), {info.counts.update} atualização(ões).
              {info.undone ? " Importação desfeita." : ""}
            </p>
            <p>
              O backup JSON preserva os dados financeiros anteriores, sem
              senhas, chat ou reflexões. Ele não é aceito pelo importador XLSX.
              Apenas o backup da última importação é mantido.
            </p>
          </div>
          <div className="import-backup-actions">
            <button
              className="secondary"
              disabled={working}
              onClick={downloadBackup}
            >
              <Download size={16} />
              Baixar backup anterior
            </button>
            {info.canUndo && !undoConfirm && (
              <button
                className="secondary"
                disabled={working}
                onClick={() => setUndoConfirm(true)}
              >
                <Undo2 size={16} />
                Desfazer última importação
              </button>
            )}
          </div>
          {!info.canUndo && !info.undone && (
            <p className="import-undo-note">
              Desfazer não está disponível: houve alteração financeira posterior
              ou mudou o dia. O backup continua disponível.
            </p>
          )}
          {undoConfirm && info.canUndo && (
            <div className="import-undo-confirm">
              <p>
                Restaurar os dados financeiros anteriores a esta importação?
                Apenas esta última operação será desfeita; perfil, estudos e
                conversa serão preservados.
              </p>
              <button
                className="secondary"
                disabled={working}
                onClick={() => setUndoConfirm(false)}
              >
                Não desfazer
              </button>
              <button className="danger-btn" disabled={working} onClick={undo}>
                Sim, desfazer importação
              </button>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
