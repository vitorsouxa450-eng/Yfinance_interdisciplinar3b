import React, { useState, useEffect } from "react";
import { api } from "./account-api.js";
import "./security.css";
const stamp = (v) => (v ? new Date(v).toLocaleString("pt-BR") : "Não definido");
const Field = ({ label, ...props }) => (
  <label className="field">
    <span>{label}</span>
    <input {...props} />
  </label>
);
export function LegalPage({ go }) {
  const [d, set] = useState(null),
    [error, err] = useState("");
  useEffect(() => {
    api("legal")
      .then(set)
      .catch((e) => err(e.message));
  }, []);
  return (
    <main className="legal-page secure-page">
      <button className="secondary" onClick={() => go("login")}>
        Voltar ao acesso
      </button>
      <h1>Termos e privacidade</h1>
      {error && <p role="alert">{error}</p>}
      {!d && !error && <p role="status">Carregando documentos…</p>}
      {d && (
        <>
          <p className="security-note">{d.notice}</p>
          <p>Versão: {d.version}</p>
          {[
            ["Política de privacidade", d.privacy],
            ["Termos de uso", d.terms],
          ].map(([title, sections]) => (
            <section key={title}>
              <h2>{title}</h2>
              {sections.map((x) => (
                <article key={x.title}>
                  <h3>{x.title}</h3>
                  <p>{x.text}</p>
                </article>
              ))}
            </section>
          ))}
        </>
      )}
    </main>
  );
}
export function RecoveryPage({ go }) {
  const [token] = useState(
      () => new URLSearchParams(location.hash.slice(1)).get("token") || "",
    ),
    [busy, b] = useState(false),
    [msg, m] = useState("");
  useEffect(() => {
    if (token) history.replaceState({}, "", "/redefinir");
  }, []);
  return (
    <main className="legal-page secure-page">
      <h1>{token ? "Redefinir senha" : "Recuperar acesso"}</h1>
      <p>
        Links são temporários e de uso único. O segundo fator continua
        obrigatório quando ativo.
      </p>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          b(true);
          m("");
          const f = Object.fromEntries(new FormData(e.currentTarget));
          try {
            const d = await api(
              token ? "auth/reset-password" : "auth/request-reset",
              { ...f, token },
            );
            m(d.message);
            if (token) location.assign("/login?senha=redefinida");
          } catch (e) {
            m(e.message);
          } finally {
            b(false);
          }
        }}
      >
        {token ? (
          <>
            <Field
              label="Nova senha"
              name="newPassword"
              type="password"
              autoComplete="new-password"
              minLength={8}
              maxLength={72}
              required
            />
            <Field
              label="Código 2FA ou de recuperação (se ativo)"
              name="code"
              autoComplete="one-time-code"
            />
          </>
        ) : (
          <Field label="E-mail" name="email" type="email" required />
        )}
        <button className="primary" disabled={busy}>
          {busy ? "Processando…" : token ? "Redefinir senha" : "Solicitar link"}
        </button>
      </form>
      {msg && <p role="status">{msg}</p>}
      <button className="text-btn" onClick={() => go("login")}>
        Voltar ao login
      </button>
    </main>
  );
}
export function LibraryPage() {
  const [items, set] = useState([]),
    [article, a] = useState(null),
    [query, q] = useState(""),
    [category, c] = useState("Todas"),
    [error, err] = useState(""),
    [busy, b] = useState(false);
  useEffect(() => {
    api("library")
      .then((d) => set(d.items))
      .catch((e) => err(e.message));
  }, []);
  async function open(id) {
    b(true);
    err("");
    try {
      a(await api("library/" + id));
    } catch (e) {
      err(e.message);
    } finally {
      b(false);
    }
  }
  return (
    <div className="secure-page">
      <span className="badge">BIBLIOTECA EDUCACIONAL</span>
      <h1>{article ? article.title : "Conhecimento para ir além"}</h1>
      {error && <p role="alert">{error}</p>}
      {article ? (
        <article className="card secure-card">
          <button className="text-btn" onClick={() => a(null)}>
            ← Voltar à biblioteca
          </button>
          <p>{article.description}</p>
          {article.sections.map((s) => (
            <section key={s.title}>
              <h2>{s.title}</h2>
              {s.paragraphs.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </section>
          ))}
          <h2>Referências</h2>
          {article.references.length ? (
            article.references.map((r) => (
              <p key={r.id}>
                <a href={r.url} target="_blank" rel="noopener noreferrer">
                  {r.organization} — {r.title}
                </a>
              </p>
            ))
          ) : (
            <p>
              Material institucional autoral do projeto. Não representa
              certificação ou endosso.
            </p>
          )}
        </article>
      ) : (
        <>
          <div className="library-search">
            <Field
              label="Buscar materiais"
              value={query}
              onChange={(e) => q(e.target.value)}
              type="search"
            />
            <label className="field">
              <span>Assunto</span>
              <select value={category} onChange={(e) => c(e.target.value)}>
                {["Todas", ...new Set(items.map((x) => x.category))].map(
                  (x) => (
                    <option key={x}>{x}</option>
                  ),
                )}
              </select>
            </label>
          </div>
          <div className="library-grid">
            {items
              .filter(
                (x) =>
                  (category === "Todas" || x.category === category) &&
                  [x.title, x.description, x.category]
                    .join(" ")
                    .toLocaleLowerCase("pt-BR")
                    .includes(query.toLocaleLowerCase("pt-BR")),
              )
              .map((x) => (
                <section className="card secure-card" key={x.id}>
                  <span className="badge">{x.category}</span>
                  <h2>{x.title}</h2>
                  <p>{x.description}</p>
                  <button
                    className="secondary"
                    disabled={busy}
                    onClick={() => open(x.id)}
                  >
                    Ler material
                  </button>
                </section>
              ))}
          </div>
          {!!items.length &&
            !items.some(
              (x) =>
                (category === "Todas" || x.category === category) &&
                [x.title, x.description, x.category]
                  .join(" ")
                  .toLowerCase()
                  .includes(query.toLowerCase()),
            ) && <p>Nenhum material encontrado.</p>}
        </>
      )}
    </div>
  );
}
export default function AccountCenter({ onChange, go }) {
  const [d, set] = useState(null),
    [busy, b] = useState(false),
    [msg, m] = useState(""),
    [setup, su] = useState(null),
    [codes, sc] = useState(null);
  const load = () => api("account").then(set);
  useEffect(() => {
    load().catch((e) => m(e.message));
  }, []);
  async function run(url, body, exit = false) {
    b(true);
    m("");
    const previous = d;
    if (url === "account/preferences")
      set({ ...d, preferences: { ...d.preferences, ...body } });
    try {
      const r = await api(url, body);
      m(r.message || "Alterações salvas.");
      if (r.qr) su(r);
      if (r.recoveryCodes) {
        sc(r.recoveryCodes);
        su(null);
      }
      if (exit) {
        location.assign("/login");
        return;
      }
      await load();
      await onChange();
    } catch (e) {
      set(previous);
      m(e.message);
    } finally {
      b(false);
    }
  }
  const submit =
    (url, exit = false) =>
    (e) => {
      e.preventDefault();
      run(url, Object.fromEntries(new FormData(e.currentTarget)), exit);
    };
  const authFields = (
    <>
      <Field
        label="Senha atual"
        name="password"
        type="password"
        autoComplete="current-password"
        required
      />
      <Field
        label="Código 2FA ou recuperação (se ativo)"
        name="code"
        autoComplete="one-time-code"
      />
    </>
  );
  if (!d)
    return (
      <section className="secure-page">
        <h2>Conta e segurança</h2>
        <p role="status">{msg || "Carregando configurações…"}</p>
      </section>
    );
  return (
    <div className="secure-page account-center">
      {msg && (
        <p className="security-note" role="status">
          {msg}
        </p>
      )}
      {!d.legal || d.legal.version !== d.legalVersion ? (
        <section className="card secure-card">
          <h2>Revisão dos termos</h2>
          <p>
            Leia a versão {d.legalVersion}. O aceite não autoriza IA externa ou
            mensagens opcionais.
          </p>
          <a href="/termos" target="_blank" rel="noopener">
            Ler termos e privacidade
          </a>
          <button
            className="primary"
            disabled={busy || d.publicTest}
            onClick={() =>
              run("legal/accept", { version: d.legalVersion, accept: true })
            }
          >
            Li e aceito os termos
          </button>
        </section>
      ) : null}
      <section className="card secure-card">
        <h2>Preferências e privacidade</h2>
        <p>
          As preferências ficam na sua conta, inclusive após sair e entrar
          novamente.
        </p>
        {[
          ["budgetAlerts", "Alertas internos de orçamento"],
          ["reducedMotion", "Reduzir animações"],
          ["productUpdates", "Autorizar avisos opcionais sobre atualizações"],
        ].map(([k, label]) => (
          <label className="check-row" key={k}>
            <input
              type="checkbox"
              checked={!!d.preferences[k]}
              disabled={busy}
              onChange={(e) =>
                run("account/preferences", { [k]: e.target.checked })
              }
            />
            {label}
          </label>
        ))}
        <h3>IA externa opcional</h3>
        <p>
          {d.externalAI.available
            ? `${d.externalAI.name}: ${d.externalAI.description}`
            : "Nenhum provedor externo identificado e configurado. O chatbot local continua disponível gratuitamente."}
        </p>
        {d.externalAI.privacyUrl && (
          <a
            href={d.externalAI.privacyUrl}
            target="_blank"
            rel="noopener noreferrer"
          >
            Política do provedor
          </a>
        )}
        <label className="check-row">
          <input
            type="checkbox"
            checked={!!d.preferences.externalAI}
            disabled={busy || d.publicTest || !d.externalAI.available}
            onChange={(e) =>
              run("account/preferences", { externalAI: e.target.checked })
            }
          />
          Autorizar os envios descritos ao provedor externo
        </label>
        <details>
          <summary>
            Histórico de autorizações opcionais ({d.consents.length})
          </summary>
          {d.consents.map((x, i) => (
            <p key={i}>
              {stamp(x.at)} ·{" "}
              {x.purpose === "externalAI" ? "IA externa" : "Atualizações"} ·{" "}
              {x.granted ? "Autorizado" : "Revogado"} · {x.version}
            </p>
          ))}
        </details>
        <p>
          <a href="/termos" target="_blank" rel="noopener">
            Termos, privacidade e cookies essenciais
          </a>
        </p>
        <button
          className="secondary"
          onClick={async () => {
            try {
              const value = await api("privacy/export"),
                blob = new Blob([JSON.stringify(value, null, 2)], {
                  type: "application/json",
                }),
                url = URL.createObjectURL(blob),
                a = document.createElement("a");
              a.href = url;
              a.download = "yfinance-meus-dados.json";
              a.click();
              setTimeout(() => URL.revokeObjectURL(url), 1000);
            } catch (e) {
              m(e.message);
            }
          }}
        >
          Exportar dados e consentimentos
        </button>
      </section>
      <section className="card secure-card">
        <h2>Segurança da conta</h2>
        <p>
          2FA: <strong>{d.security.twoFactor ? "Ativo" : "Desativado"}</strong>{" "}
          · Códigos restantes: {d.security.recoveryRemaining}
        </p>
        {d.publicTest ? (
          <p>
            Credenciais, 2FA e exclusão protegidos na conta compartilhada.
            Cadastre uma conta própria para testar esses recursos.
          </p>
        ) : (
          <>
            <details>
              <summary>Alterar senha</summary>
              <form onSubmit={submit("account/password", true)}>
                {authFields}
                <Field
                  label="Nova senha"
                  name="newPassword"
                  type="password"
                  autoComplete="new-password"
                  minLength={8}
                  maxLength={72}
                  required
                />
                <p>Todas as sessões serão encerradas.</p>
                <button className="primary" disabled={busy}>
                  Salvar nova senha
                </button>
              </form>
            </details>
            {!d.security.twoFactor ? (
              <details>
                <summary>Ativar autenticação em duas etapas</summary>
                <p>
                  Use um aplicativo autenticador TOTP. Guarde os códigos de
                  recuperação fora deste dispositivo.
                </p>
                <form onSubmit={submit("account/2fa/setup")}>
                  {authFields}
                  <button className="primary" disabled={busy}>
                    Preparar autenticador
                  </button>
                </form>
                {setup && (
                  <div className="totp-enrollment">
                    <img
                      src={setup.qr}
                      width="240"
                      height="240"
                      alt="QR Code para configurar seu aplicativo autenticador"
                    />
                    <p>
                      Chave manual (confidencial): <code>{setup.secret}</code>
                    </p>
                    <p>Configuração válida por 10 minutos.</p>
                    <form onSubmit={submit("account/2fa/enable")}>
                      <Field
                        label="Código do autenticador"
                        name="code"
                        inputMode="numeric"
                        pattern="[0-9]{6}"
                        autoComplete="one-time-code"
                        required
                      />
                      <button className="primary" disabled={busy}>
                        Confirmar e ativar 2FA
                      </button>
                    </form>
                  </div>
                )}
              </details>
            ) : (
              <>
                <details>
                  <summary>Renovar códigos de recuperação</summary>
                  <form onSubmit={submit("account/2fa/recovery")}>
                    {authFields}
                    <p>Os códigos antigos deixam de funcionar.</p>
                    <button className="secondary" disabled={busy}>
                      Gerar novos códigos
                    </button>
                  </form>
                </details>
                <details>
                  <summary>Desativar 2FA</summary>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (
                        window.confirm(
                          "Desativar 2FA e encerrar todas as sessões?",
                        )
                      )
                        run(
                          "account/2fa/disable",
                          Object.fromEntries(new FormData(e.currentTarget)),
                          true,
                        );
                    }}
                  >
                    {authFields}
                    <button className="secondary" disabled={busy}>
                      Desativar e sair
                    </button>
                  </form>
                </details>
              </>
            )}
            {codes && (
              <div className="security-note">
                <h3>Guarde agora seus códigos de recuperação</h3>
                <p>
                  Mostrados apenas nesta resposta. Cada código funciona uma vez.
                  Não os compartilhe.
                </p>
                <pre>{codes.join("\n")}</pre>
                <button className="secondary" onClick={() => sc(null)}>
                  Já guardei os códigos
                </button>
              </div>
            )}
            <details>
              <summary>
                Sessões e dispositivos ({d.security.sessions.length})
              </summary>
              {d.security.sessions.map((x) => (
                <p key={x.id}>
                  {x.current ? "Esta sessão" : "Outra sessão"} · último uso:{" "}
                  {stamp(x.lastSeenAt)} · expira: {stamp(x.expiresAt)}
                </p>
              ))}
              <form onSubmit={submit("account/sessions/revoke")}>
                {authFields}
                <button className="secondary" disabled={busy}>
                  Encerrar outras sessões
                </button>
              </form>
            </details>
            <details>
              <summary>Excluir definitivamente minha conta</summary>
              <p>
                Remove registros, estudos, conversas e sessões do banco ativo.
                Exporte antes. Backups e downloads externos precisam ser
                tratados pelo responsável. Esta ação não pode ser desfeita.
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (
                    window.confirm(
                      "Excluir a conta e todos os registros do banco ativo?",
                    )
                  )
                    run(
                      "account/delete",
                      Object.fromEntries(new FormData(e.currentTarget)),
                      true,
                    );
                }}
              >
                {authFields}
                <Field
                  label="Digite EXCLUIR MINHA CONTA"
                  name="confirm"
                  required
                />
                <button className="secondary" disabled={busy}>
                  Excluir conta permanentemente
                </button>
              </form>
            </details>
          </>
        )}
      </section>
    </div>
  );
}
