import { curriculum } from "./curriculum.js";
import { lessons } from "./lessons.js";
export const studyGoals = [
  {
    id: "all",
    label: "Todos os assuntos",
    lessons: lessons.map((_, id) => id),
  },
  {
    id: "budget",
    label: "Organizar meu orçamento",
    lessons: [0, 1, 2, 3, 5, 6, 10],
  },
  { id: "debt", label: "Entender dívidas e juros", lessons: [3, 7, 13] },
  { id: "reserve", label: "Planejar reserva e metas", lessons: [4, 8, 9] },
  {
    id: "invest",
    label: "Aprender sobre investimentos",
    lessons: [11, 12, 13, 14, 15, 16],
  },
];
export function studyRecommendations(state, focus = "all") {
  const goal = studyGoals.find((g) => g.id === focus) || studyGoals[0];
  return goal.lessons
    .map((id) => {
      const quiz = state.learning?.[id]?.quiz,
        last = quiz?.last;
      const attempted =
        !!last &&
        Array.isArray(last.answers) &&
        last.answers.length === curriculum[id].quiz.length;
      const mistakes = attempted
        ? curriculum[id].quiz.flatMap((q, index) =>
            last.answers[index] !== q.answer
              ? [
                  {
                    index,
                    prompt: q.prompt,
                    explanation: q.explanation,
                    correct: q.options[q.answer],
                  },
                ]
              : [],
          )
        : [];
      const kind = mistakes.length
        ? "review"
        : !attempted
          ? "start"
          : "practice";
      const reason =
        kind === "review"
          ? `${mistakes.length} ponto(s) para retomar na última tentativa concluída. Melhor nota preservada: ${quiz.bestScore ?? last.score}/${last.total}.`
          : kind === "start"
            ? "Ainda não há quiz concluído nesta aula. Comece pela leitura e, quando quiser, teste o que aprendeu."
            : "Última tentativa sem erros. Você pode consolidar o aprendizado com a prática opcional.";
      return {
        id,
        title: lessons[id][0],
        duration: lessons[id][1],
        kind,
        mistakes,
        reason,
        attempt: last?.attempt || null,
        submittedAt: last?.submittedAt || null,
      };
    })
    .sort(
      (a, b) =>
        ({ review: 0, start: 1, practice: 2 })[a.kind] -
          { review: 0, start: 1, practice: 2 }[b.kind] ||
        b.mistakes.length - a.mistakes.length ||
        a.id - b.id,
    );
}
