// Educational scenarios only; no state mutations, market data, tax assumptions or payments.
const fail = (message) => {
  throw new Error(message);
};
function number(value, label, min, max, integer = false) {
  if (value === "" || value == null) return fail(`Preencha ${label}.`);
  const n = Number(value);
  if (
    !Number.isFinite(n) ||
    n < min ||
    n > max ||
    (integer && !Number.isInteger(n))
  )
    return fail(
      `${label}: use ${integer ? "um inteiro" : "um número"} entre ${min.toLocaleString("pt-BR")} e ${max.toLocaleString("pt-BR")}.`,
    );
  return n;
}
const round = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
export function compound({ initial, monthly, rate, months, unit }) {
  initial = number(initial, "capital inicial", 0, 1e9);
  monthly = number(monthly, "aporte mensal", 0, 1e9);
  rate = number(rate, "taxa", 0, 100);
  months = number(months, "prazo em meses", 1, 600, true);
  if (!["month", "year"].includes(unit))
    return fail("Escolha a unidade da taxa.");
  const r = unit === "year" ? Math.pow(1 + rate / 100, 1 / 12) - 1 : rate / 100;
  let balance = initial;
  const rows = [
    { month: 0, invested: round(initial), interest: 0, total: round(initial) },
  ];
  for (let month = 1; month <= months; month++) {
    balance = balance * (1 + r) + monthly;
    if (!Number.isFinite(balance) || balance > 1e15)
      return fail(
        "O cenário excedeu o limite de cálculo. Reduza taxa, prazo ou valores.",
      );
    const invested = initial + monthly * month;
    rows.push({
      month,
      invested: round(invested),
      interest: round(balance - invested),
      total: round(balance),
    });
  }
  return { ...rows.at(-1), monthlyRate: r, rows };
}
export function installments({ cash, down, payment, count }) {
  cash = number(cash, "preço à vista", 0.01, 1e9);
  down = number(down, "entrada", 0, 1e9);
  payment = number(payment, "valor da parcela", 0.01, 1e9);
  count = number(count, "número de parcelas", 1, 360, true);
  const total = round(down + payment * count),
    difference = round(total - cash),
    loan = cash - down;
  let implied = null;
  if (loan > 0) {
    const pv = (rate) => {
      let sum = 0;
      for (let i = 1; i <= count; i++) sum += payment / Math.pow(1 + rate, i);
      return sum;
    };
    let lo = -0.999,
      hi = 1;
    while (pv(hi) > loan && hi < 1e9) hi *= 2;
    if (pv(lo) >= loan && pv(hi) <= loan) {
      for (let i = 0; i < 120; i++) {
        const mid = (lo + hi) / 2;
        if (pv(mid) > loan) lo = mid;
        else hi = mid;
      }
      implied = (lo + hi) / 2;
      if (Math.abs(implied) < 1e-12) implied = 0;
    }
  }
  return {
    cash,
    down,
    payment,
    count,
    total,
    difference,
    percentage: (difference / cash) * 100,
    implied,
  };
}
export function reserve({ expenses, coverage, current, monthly }) {
  expenses = number(expenses, "despesas mensais", 0.01, 1e9);
  coverage = number(coverage, "meses de cobertura", 1, 24, true);
  current = number(current, "valor já reservado", 0, 1e9);
  monthly = number(monthly, "aporte mensal", 0, 1e9);
  const target = round(expenses * coverage),
    remaining = round(Math.max(0, target - current));
  return {
    target,
    remaining,
    months:
      remaining === 0 ? 0 : monthly > 0 ? Math.ceil(remaining / monthly) : null,
    coverage,
    current,
    monthly,
  };
}
