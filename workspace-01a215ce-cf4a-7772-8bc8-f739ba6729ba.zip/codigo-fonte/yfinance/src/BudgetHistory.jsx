import React, { useState } from "react";
import {
  CalendarDays,
  ShieldCheck,
  Eye,
  Save,
  History,
  ArrowUpRight,
} from "lucide-react";
import { budgetRows, budgetEntries } from "./budget-model.js";
import "./planning.css";
const brl = (n) =>
  Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export default function BudgetHistory({
  state,
  mutate,
  busy,
  hidden,
  onReveal,
}) {
  const current =
    Object.keys(state.budgetHistory || {})
      .sort()
      .at(-1) || "";
  const [selected, setSelected] = useState(current),
    [notice, setNotice] = useState("");
  const month = selected || current,
    rows = budgetRows(state, month),
    snapshot = budgetEntries(state, month),
    editable = month === current;
  const limited = rows.filter((r) => r.limit > 0),
    limit = limited.reduce((n, r) => n + Math.round(r.limit * 100), 0) / 100,
    spent = limited.reduce((n, r) => n + Math.round(r.spent * 100), 0) / 100;
  return (
    <section className="card setting-card budget-history">
      <div className="planning-heading">
        <span className="planning-icon">
          <CalendarDays size={24} />
        </span>
        <div>
          <h2>Orçamento mensal</h2>
          <p>Planeje o presente. Preserve os limites do passado.</p>
        </div>
      </div>
      <label className="planning-month">
        Mês para consultar
        <input
          aria-label="Mês do histórico de orçamento"
          type="month"
          min="1900-01"
          max={current}
          value={month}
          onChange={(e) => {
            setSelected(e.target.value);
            setNotice("");
          }}
        />
      </label>
      <div className="planning-status">
        <History size={16} />
        {editable
          ? "Mês atual · limites editáveis"
          : "Consulta histórica · limites preservados"}
      </div>
      <p className="planning-note">
        Ao virar o mês, os limites são copiados para o novo período. Editar o
        mês atual não modifica os anteriores. Gastos continuam refletindo os
        lançamentos cadastrados, inclusive edições posteriores.
      </p>
      {hidden ? (
        <div className="planning-private">
          <ShieldCheck size={27} />
          <p>Revele os valores para consultar ou editar seu orçamento.</p>
          <button className="secondary" onClick={onReveal}>
            <Eye size={16} />
            Mostrar valores
          </button>
        </div>
      ) : (
        <>
          {!snapshot && (
            <div className="planning-info" role="status">
              Sem histórico de limites neste mês. O histórico começa na ativação
              desta versão; não reconstruímos limites antigos. Os gastos abaixo
              vêm dos registros existentes.
            </div>
          )}
          {snapshot && (
            <div className="planning-metrics">
              <div>
                <span>Limites registrados</span>
                <strong>{brl(limit)}</strong>
              </div>
              <div>
                <span>Gasto nas categorias com limite</span>
                <strong>{brl(spent)}</strong>
              </div>
              <div>
                <span>
                  {limit - spent < 0
                    ? "Acima dos limites"
                    : "Margem nesses limites"}
                </span>
                <strong>{brl(Math.abs(limit - spent))}</strong>
              </div>
            </div>
          )}
          <p className="planning-note">
            Os totais consideram apenas categorias com limite maior que zero.
            Zero significa sem limite; ausência de histórico é indicada
            separadamente.
          </p>
          <div className="planning-budget-list">
            {rows.map((r) => (
              <form
                className="planning-budget-row"
                key={`${month}:${r.id}:${r.limit}`}
                onSubmit={async (e) => {
                  e.preventDefault();
                  const budget = new FormData(e.currentTarget).get("budget");
                  if (
                    await mutate(
                      "budget.save",
                      { id: r.id, month, budget },
                      "Limite do mês atualizado. Meses anteriores preservados.",
                    )
                  )
                    setNotice(
                      `Limite de ${r.name} salvo em ${month.split("-").reverse().join("/")}.`,
                    );
                }}
              >
                <div className="planning-category">
                  <span aria-hidden="true" style={{ background: r.color }} />
                  <div>
                    <label htmlFor={`monthly-${r.id}`}>{r.name}</label>
                    <small>
                      Gasto: {brl(r.spent)}
                      {r.limit > 0
                        ? ` · ${((r.spent / r.limit) * 100).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}% do limite`
                        : ""}
                    </small>
                  </div>
                </div>
                {editable ? (
                  <div className="planning-budget-input">
                    <span>R$</span>
                    <input
                      id={`monthly-${r.id}`}
                      name="budget"
                      aria-label={`Limite mensal de ${r.name}`}
                      type="number"
                      min="0"
                      max="1000000000000"
                      step="0.01"
                      required
                      defaultValue={r.limit ?? 0}
                      disabled={busy}
                    />
                    <button
                      className="secondary"
                      disabled={busy}
                      aria-label={`Salvar limite de ${r.name}`}
                    >
                      <Save size={15} />
                      Salvar
                    </button>
                  </div>
                ) : (
                  <strong>
                    {r.limit === null
                      ? "Sem histórico"
                      : r.limit === 0
                        ? "Sem limite"
                        : brl(r.limit)}
                  </strong>
                )}
                {r.limit > 0 && (
                  <div
                    className="planning-meter"
                    role="img"
                    aria-label={`Uso do limite de ${r.name}: ${Math.round((r.spent / r.limit) * 100)}%`}
                  >
                    <span
                      className={r.spent >= r.limit ? "over" : ""}
                      style={{
                        width: Math.min(100, (r.spent / r.limit) * 100) + "%",
                      }}
                    />
                  </div>
                )}
              </form>
            ))}
          </div>
          {!rows.length && (
            <p className="planning-info">
              Não há categorias ou gastos registrados neste período.
            </p>
          )}
          {notice && (
            <p className="planning-success" role="status">
              {notice}
            </p>
          )}
        </>
      )}
      <p className="planning-note">
        <ArrowUpRight size={14} />O Excel e o assistente também usam os limites
        do mês consultado. A importação só pode alterar o mês atual.
      </p>
    </section>
  );
}
