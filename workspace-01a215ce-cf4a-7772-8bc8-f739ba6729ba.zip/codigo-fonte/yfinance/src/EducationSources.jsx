import React, { useState } from "react";
import { BookOpen, ExternalLink, ArrowLeft, LibraryBig } from "lucide-react";
import {
  educationSources,
  sourcesForLesson,
  sourceDisclosure,
} from "./education-sources.js";
import { lessons } from "./lessons.js";
import "./knowledge.css";
export function SourceCards({ sources }) {
  return (
    <div className="source-cards">
      {sources.map((s) => (
        <article key={s.id} className="source-card">
          <span className="source-institution">{s.organization}</span>
          <h3>
            <a href={s.url} target="_blank" rel="noopener noreferrer">
              {s.title}
              <ExternalLink size={14} aria-label="Abre em nova aba" />
            </a>
          </h3>
          <p>{s.section || s.scope}</p>
          <small>
            {s.edition} · {s.format}
          </small>
        </article>
      ))}
    </div>
  );
}
export function LessonSources({ lessonId }) {
  return (
    <section
      className="card lesson-sources"
      id="lesson-fontes"
      aria-label="Fontes e referências desta aula"
    >
      <h2>
        <BookOpen size={22} />
        Fontes e referências desta aula
      </h2>
      <p className="sources-disclosure">{sourceDisclosure}</p>
      <SourceCards sources={sourcesForLesson(lessonId)} />
      <p className="sources-footnote">
        Links externos abrem em nova aba e precisam de internet. Conceitos não
        substituem documentos atuais do produto ou orientação profissional. Os
        cenários numéricos da aula são fictícios.
      </p>
    </section>
  );
}
export default function EducationSources({ onBack, openLesson }) {
  const [selected, setSelected] = useState("all");
  const sources =
    selected === "all"
      ? Object.values(educationSources)
      : sourcesForLesson(Number(selected));
  return (
    <section className="education-sources">
      {onBack && (
        <button className="back-btn" onClick={onBack}>
          <ArrowLeft size={16} />
          Voltar à educação
        </button>
      )}
      {onBack && (
        <header className="page-header">
          <div>
            <h1>Fontes educacionais</h1>
            <p>
              Publicações oficiais para conferir conceitos e aprofundar o
              estudo.
            </p>
          </div>
        </header>
      )}
      <div className="card sources-hero">
        <LibraryBig size={30} />
        <div>
          <span className="source-institution">
            CONHECIMENTO COM REFERÊNCIAS
          </span>
          <h2>Confira de onde vêm os conceitos.</h2>
          <p>{sourceDisclosure}</p>
        </div>
      </div>
      <label className="source-filter">
        Consultar referências
        <select
          aria-label="Filtrar fontes por aula"
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
        >
          <option value="all">Todas as publicações</option>
          {lessons.map((l, i) => (
            <option key={i} value={i}>
              {String(i + 1).padStart(2, "0")} · {l[0]}
            </option>
          ))}
        </select>
      </label>
      {selected !== "all" && (
        <div className="source-lesson">
          <h3>{lessons[Number(selected)][0]}</h3>
          <button
            className="secondary"
            onClick={() => openLesson(Number(selected), "fontes")}
          >
            <BookOpen size={16} />
            Abrir aula e referências
          </button>
        </div>
      )}
      <SourceCards sources={sources} />
      <p className="sources-footnote">
        {sources.length} publicação(ões) neste recorte · referências conferidas
        na revisão 1.7.0. As datas indicadas são das publicações, não uma
        promessa de atualização automática. Links externos exigem internet; o
        conteúdo das aulas continua local. Publicações e marcas pertencem às
        instituições responsáveis; não foram incorporados PDFs completos ao
        projeto.
      </p>
    </section>
  );
}
