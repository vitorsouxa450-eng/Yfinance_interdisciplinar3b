// Public references reviewed for this release. They support concepts, not product behavior.
export const educationSources = {
  "fgc-garantia": {
    id: "fgc-garantia",
    organization: "Fundo Garantidor de Créditos (FGC)",
    title: "Sobre a garantia FGC",
    edition: "Página institucional; consulte as condições vigentes",
    format: "Página web",
    url: "https://fgc.org.br/sobre-garantia-fgc",
    scope:
      "Produtos elegíveis e não cobertos, limites e condições da garantia.",
  },
  "bcb-caderno": {
    id: "bcb-caderno",
    organization: "Banco Central do Brasil",
    title: "Caderno de Educação Financeira — Conteúdo Básico",
    edition: "2ª edição revisada, 2026",
    format: "PDF",
    url: "https://www.bcb.gov.br/content/cidadaniafinanceira/documentos_cidadania/Cuidando_do_seu_dinheiro_Gestao_de_Financas_Pessoais/caderno_cidadania_financeira.pdf",
    scope:
      "Relação com dinheiro, orçamento, crédito, dívidas, consumo, poupança e planejamento.",
  },
  "bcb-glossario": {
    id: "bcb-glossario",
    organization: "Banco Central do Brasil",
    title: "Glossário Simplificado de Termos Financeiros",
    edition: "Publicação institucional; consulte a edição disponível no link",
    format: "PDF",
    url: "https://www.bcb.gov.br/content/cidadaniafinanceira/documentos_cidadania/Informacoes_gerais/glossario_cidadania_financeira.pdf",
    scope:
      "Definições de crédito, CET, juros, investimentos e outros termos financeiros.",
  },
  "cvm-introducao": {
    id: "cvm-introducao",
    organization: "Comissão de Valores Mobiliários (CVM)",
    title:
      "Programa Bem-Estar Financeiro — Módulo 06: Introdução aos Investimentos",
    edition: "2018",
    format: "PDF",
    url: "https://www.gov.br/investidor/pt-br/educacional/programa-bem-estar-financeiro/programa-bem-estar-financeiro-arquivos/apostila-06.pdf/@@display-file/file",
    scope:
      "Objetivos, perfil de risco, retorno, liquidez, diversificação e prevenção de fraudes.",
  },
  "cvm-caracteristicas": {
    id: "cvm-caracteristicas",
    organization: "CVM — Portal do Investidor",
    title: "Entenda as características dos investimentos",
    edition: "Publicado em 2022",
    format: "Página web",
    url: "https://www.gov.br/investidor/pt-br/investir/antes-de-investir/entenda-as-caracteristicas-dos-investimentos",
    scope: "Renda fixa e variável, formas de remuneração, emissores e riscos.",
  },
  "cvm-liquidez": {
    id: "cvm-liquidez",
    organization: "CVM — Portal do Investidor",
    title: "Liquidez",
    edition: "Publicado em 2022",
    format: "Página web",
    url: "https://www.gov.br/investidor/pt-br/investir/antes-de-investir/entenda-as-caracteristicas-dos-investimentos/liquidez",
    scope:
      "Conversão em dinheiro, adequação ao objetivo e diferença entre liquidez e ausência de risco.",
  },
};
// One mapping per lesson, in the same stable order as lessons.js. Section labels are from the publications.
export const lessonSourceMap = [
  [["bcb-caderno", "Introdução; módulo 1 — Nossa relação com o dinheiro"]],
  [
    [
      "bcb-caderno",
      "Módulo 2 — Orçamento pessoal ou familiar; registro e gestão",
    ],
  ],
  [
    [
      "bcb-caderno",
      "Módulo 1, seções 1.3, 1.5 e 1.6 — escolhas, necessidades/desejos e custo de oportunidade",
    ],
  ],
  [
    [
      "bcb-caderno",
      "Módulo 2, seções 2.1 a 2.4 — elaboração e gestão do orçamento",
    ],
  ],
  [
    [
      "bcb-caderno",
      "Módulo 5, seções 5.1 e 5.2 — por que poupar; poupança e investimento",
    ],
  ],
  [
    [
      "bcb-caderno",
      "Módulo 2 — levantamento de receitas, despesas e planejamento",
    ],
  ],
  [
    [
      "bcb-caderno",
      "Módulo 2, seções 2.3 e 2.4 — registro, agrupamento, avaliação e gestão",
    ],
  ],
  [
    ["bcb-caderno", "Módulo 3 — Uso do crédito e administração das dívidas"],
    [
      "bcb-glossario",
      "Verbetes Crédito, Custo Efetivo Total (CET), Juros e Juros compostos",
    ],
  ],
  [
    [
      "cvm-caracteristicas",
      "Objetivos da reserva para emergências: risco e liquidez",
    ],
    ["cvm-liquidez", "Liquidez e adequação aos objetivos"],
  ],
  [
    ["bcb-caderno", "Módulo 1, seção 1.2 — Sonhos e projetos"],
    [
      "cvm-introducao",
      "Objetivo do investimento e adequação ao objetivo, p. 14–17",
    ],
  ],
  [["bcb-caderno", "Módulo 4 — Consumo planejado e consciente"]],
  [
    ["cvm-introducao", "Objetivos, adequação e perfil de risco, p. 14–21"],
    [
      "bcb-caderno",
      "Módulo 5, seção 5.4 — O que você precisa saber antes de investir",
    ],
  ],
  [
    ["cvm-introducao", "As dimensões dos investimentos, p. 6–13"],
    ["cvm-liquidez", "Liquidez não elimina risco de crédito ou de mercado"],
  ],
  [
    [
      "bcb-caderno",
      "Módulo 3, seções 3.2 e 3.3 — valor do dinheiro no tempo e juros",
    ],
    ["bcb-glossario", "Verbetes Juros e Juros compostos"],
  ],
  [
    [
      "cvm-caracteristicas",
      "Renda fixa: formas de remuneração, emissores e riscos",
    ],
    ["cvm-introducao", "Retorno e risco, p. 6–10"],
    ["fgc-garantia", "Elegibilidade, limites e condições da garantia"],
  ],
  [
    [
      "cvm-introducao",
      "A importância da diversificação, p. 22; objetivos e prazo, p. 14–17",
    ],
  ],
  [
    [
      "cvm-introducao",
      "Cuidados ao investir: promessas, ofertas não autorizadas e fraudes, p. 23–24",
    ],
  ],
];
export const sourceDisclosure =
  "Textos, exemplos, práticas e quizzes são autorais do Y Finance. Estas referências foram acrescentadas nesta revisão para conferir os conceitos e aprofundar o estudo; não representam citações literais, endosso institucional ou prova de consulta na criação original das aulas. Regras, taxas e condições podem mudar: confira a publicação oficial antes de decidir.";
export function sourcesForLesson(id) {
  return (lessonSourceMap[id] || []).map(([key, section]) => ({
    ...educationSources[key],
    section,
  }));
}
export function safeEducationSource(source) {
  return (
    !!source &&
    Object.values(educationSources).some(
      (s) => s.id === source.id && s.url === source.url,
    )
  );
}
export function uniqueSources(items) {
  return [...new Map(items.map((item) => [item.id, item])).values()];
}
