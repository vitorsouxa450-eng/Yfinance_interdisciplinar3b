import ScenarioComparison from "./ScenarioComparison.jsx";
import React, { useState, useId } from "react";
import {
  Calculator,
  TrendingUp,
  CreditCard,
  ShieldCheck,
  BookOpen,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { compound, installments, reserve } from "./simulation-model.js";
import { lessons } from "./lessons.js";
import "./planning.css";
const money = (n) =>
  Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const defaults = {
  compound: {
    initial: 1000,
    monthly: 200,
    rate: 0.8,
    months: 24,
    unit: "month",
  },
  installments: { cash: 1000, down: 0, payment: 95, count: 12 },
  reserve: { expenses: 1500, coverage: 6, current: 500, monthly: 300 },
};
const kinds = [
  ["compound", "Juros e aportes", TrendingUp],
  ["installments", "À vista ou parcelado", CreditCard],
  ["reserve", "Reserva de emergência", ShieldCheck],
];
function Field({
  label,
  name,
  values,
  setValues,
  min = 0,
  max = 1e9,
  step = "0.01",
  help,
}) {
  const id = useId();
  return (
    <label className="sim-field" htmlFor={id}>
      <span id={id + "-label"}>{label}</span>
      <input
        id={id}
        aria-labelledby={id + "-label"}
        name={name}
        type="number"
        min={min}
        max={max}
        step={step}
        required
        value={values[name]}
        onChange={(e) => setValues((v) => ({ ...v, [name]: e.target.value }))}
        aria-describedby={help ? id + "-help" : undefined}
      />
      {help && <small id={id + "-help"}>{help}</small>}
    </label>
  );
}
function Metric({ label, value }) {
  return (
    <div>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
function CompoundChart({ rows }) {
  const max = Math.max(1, rows.at(-1).total),
    w = 620,
    h = 170;
  const path = (key) =>
    rows
      .map(
        (r, i) =>
          `${i === 0 ? "M" : "L"}${20 + (i / (rows.length - 1)) * (w - 40)},${h - 15 - (r[key] / max) * (h - 35)}`,
      )
      .join(" ");
  return (
    <div className="sim-chart">
      <svg
        viewBox={`0 0 ${w} ${h}`}
        role="img"
        aria-label="Evolução hipotética: comparação entre valor aportado e saldo com juros. Os valores exatos estão na tabela."
      >
        <path
          d={`M20 ${h - 15} H${w - 20}`}
          stroke="currentColor"
          opacity=".3"
        />
        <path
          d={path("total")}
          fill="none"
          stroke="var(--accent)"
          strokeWidth="3"
        />
        <path
          d={path("invested")}
          fill="none"
          stroke="var(--muted)"
          strokeWidth="2"
          strokeDasharray="5 4"
        />
      </svg>
      <div>
        <span>━ Saldo com juros</span>
        <span>┄ Total investido</span>
      </div>
    </div>
  );
}
export default function Simulators({ openLesson }) {
  const [kind, setKind] = useState("compound"),
    [scenarios, setScenarios] = useState(() => structuredClone(defaults)),
    [result, setResult] = useState(null),
    [lastInputs, setLastInputs] = useState(null),
    [error, setError] = useState(""),
    [dirty, setDirty] = useState(false),
    [page, setPage] = useState(0);
  const values = scenarios[kind],
    update = (fn) => {
      setScenarios((s) => ({ ...s, [kind]: fn(s[kind]) }));
      setDirty(true);
    };
  const select = (k) => {
    setKind(k);
    setResult(null);
    setError("");
    setPage(0);
    setDirty(false);
  };
  function calculate(e) {
    e.preventDefault();
    try {
      const value = { compound, installments, reserve }[kind](values);
      setResult(value);
      setLastInputs(structuredClone(values));
      setError("");
      setDirty(false);
      setPage(0);
    } catch (e) {
      setResult(null);
      setError(e.message);
    }
  }
  const lessonName =
    kind === "compound"
      ? "juros"
      : kind === "installments"
        ? "crédito"
        : "reserva";
  const lessonId = lessons.findIndex((l) =>
    l[0].toLowerCase().includes(lessonName),
  );
  return (
    <section className="simulators">
      <div className="card sim-hero">
        <span className="planning-icon">
          <Calculator size={27} />
        </span>
        <div>
          <span className="sim-eyebrow">APRENDA EXPERIMENTANDO</span>
          <h2>Teste uma decisão antes de tomar.</h2>
          <p>
            Simulações locais com hipóteses escolhidas por você. Os exemplos
            iniciais são fictícios e não alteram receitas, despesas ou metas.
          </p>
        </div>
      </div>
      <div className="sim-switch" role="group" aria-label="Escolher simulador">
        {kinds.map(([k, label, Icon]) => (
          <button
            key={k}
            className={kind === k ? "active" : ""}
            aria-pressed={kind === k}
            onClick={() => select(k)}
          >
            <Icon size={18} />
            {label}
          </button>
        ))}
      </div>
      <div className="sim-layout">
        <form className="card sim-form" onSubmit={calculate}>
          <h3>{kinds.find((k) => k[0] === kind)[1]}</h3>
          <p className="planning-note">
            Altere os campos e clique em Calcular cenário.
          </p>
          {kind === "compound" && (
            <>
              <Field
                label="Capital inicial (R$)"
                name="initial"
                {...{ values, setValues: update }}
              />
              <Field
                label="Aporte mensal (R$)"
                name="monthly"
                {...{ values, setValues: update }}
                help="Aportes ao final de cada mês."
              />
              <div className="sim-pair">
                <Field
                  label="Taxa hipotética (%)"
                  name="rate"
                  max={100}
                  step="0.0001"
                  {...{ values, setValues: update }}
                />
                <label className="sim-field">
                  <span>Unidade da taxa</span>
                  <select
                    value={values.unit}
                    onChange={(e) =>
                      update((v) => ({ ...v, unit: e.target.value }))
                    }
                  >
                    <option value="month">Ao mês</option>
                    <option value="year">Ao ano (efetiva)</option>
                  </select>
                </label>
              </div>
              <Field
                label="Prazo (meses)"
                name="months"
                min={1}
                max={600}
                step="1"
                {...{ values, setValues: update }}
              />
            </>
          )}
          {kind === "installments" && (
            <>
              <Field
                label="Preço à vista (R$)"
                name="cash"
                min={0.01}
                {...{ values, setValues: update }}
              />
              <Field
                label="Entrada (R$)"
                name="down"
                {...{ values, setValues: update }}
              />
              <Field
                label="Valor de cada parcela (R$)"
                name="payment"
                min={0.01}
                {...{ values, setValues: update }}
              />
              <Field
                label="Quantidade de parcelas"
                name="count"
                min={1}
                max={360}
                step="1"
                {...{ values, setValues: update }}
                help="Parcelas iguais; primeira parcela após um mês."
              />
            </>
          )}
          {kind === "reserve" && (
            <>
              <Field
                label="Despesas mensais estimadas (R$)"
                name="expenses"
                min={0.01}
                {...{ values, setValues: update }}
              />
              <Field
                label="Meses de cobertura desejados"
                name="coverage"
                min={1}
                max={24}
                step="1"
                {...{ values, setValues: update }}
              />
              <Field
                label="Valor já reservado (R$)"
                name="current"
                {...{ values, setValues: update }}
              />
              <Field
                label="Aporte mensal possível (R$)"
                name="monthly"
                {...{ values, setValues: update }}
              />
            </>
          )}
          <div className="sim-actions">
            <button className="primary" type="submit">
              <Calculator size={16} />
              Calcular cenário
            </button>
            <button
              className="secondary"
              type="button"
              onClick={() => {
                setScenarios((s) => ({ ...s, [kind]: { ...defaults[kind] } }));
                setResult(null);
                setError("");
                setDirty(false);
                setPage(0);
              }}
            >
              <RotateCcw size={15} />
              Exemplo inicial
            </button>
          </div>
          {error && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
        </form>
        <div className="card sim-result" aria-live="polite" aria-atomic="false">
          {!result ? (
            <div className="sim-empty">
              <TrendingUp size={38} />
              <h3>Uma hipótese. Mais clareza.</h3>
              <p>
                Preencha seu cenário para ver os valores, as hipóteses e o
                raciocínio — sem consultar bancos ou fornecedores de IA.
              </p>
            </div>
          ) : (
            <>
              <div className="sim-result-title">
                <h3>Resultado da simulação</h3>
                <span>Não é uma promessa</span>
              </div>
              {dirty && (
                <p className="planning-info" role="status">
                  Os campos mudaram. Recalcule para atualizar os resultados
                  abaixo.
                </p>
              )}
              {kind === "compound" && (
                <>
                  <div className="planning-metrics">
                    <Metric
                      label="Total investido"
                      value={money(result.invested)}
                    />
                    <Metric
                      label="Juros estimados"
                      value={money(result.interest)}
                    />
                    <Metric
                      label="Saldo hipotético"
                      value={money(result.total)}
                    />
                  </div>
                  <CompoundChart rows={result.rows} />
                  <p className="planning-note">
                    A cada mês: saldo anterior × (1 + taxa mensal) + aporte.
                    Taxa anual efetiva é convertida por (1 + taxa anual)^(1/12)
                    − 1, não dividida por 12. Taxa mensal usada:{" "}
                    {(result.monthlyRate * 100).toLocaleString("pt-BR", {
                      maximumFractionDigits: 4,
                    })}
                    %.
                  </p>
                  <div
                    className="planning-table"
                    tabIndex={0}
                    role="region"
                    aria-label="Detalhamento mensal dos juros"
                  >
                    <table>
                      <thead>
                        <tr>
                          <th>Mês</th>
                          <th>Investido</th>
                          <th>Juros</th>
                          <th>Saldo</th>
                        </tr>
                      </thead>
                      <tbody>
                        {result.rows
                          .slice(page * 12, page * 12 + 12)
                          .map((r) => (
                            <tr key={r.month}>
                              <th>{r.month}</th>
                              <td>{money(r.invested)}</td>
                              <td>{money(r.interest)}</td>
                              <td>{money(r.total)}</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="sim-pagination">
                    <button
                      className="secondary"
                      disabled={page === 0}
                      onClick={() => setPage((p) => p - 1)}
                      aria-label="Meses anteriores"
                    >
                      <ChevronLeft size={15} />
                    </button>
                    <span>
                      Página {page + 1} de {Math.ceil(result.rows.length / 12)}
                    </span>
                    <button
                      className="secondary"
                      disabled={(page + 1) * 12 >= result.rows.length}
                      onClick={() => setPage((p) => p + 1)}
                      aria-label="Próximos meses"
                    >
                      <ChevronRight size={15} />
                    </button>
                  </div>
                </>
              )}
              {kind === "installments" && (
                <>
                  <div className="planning-metrics">
                    <Metric label="À vista" value={money(result.cash)} />
                    <Metric label="Total a prazo" value={money(result.total)} />
                    <Metric
                      label={
                        result.difference >= 0
                          ? "Custo adicional"
                          : "Diferença a favor do parcelado"
                      }
                      value={money(Math.abs(result.difference))}
                    />
                  </div>
                  <div
                    className="sim-comparison"
                    role="img"
                    aria-label={`Comparação do custo total: à vista ${money(result.cash)}; a prazo ${money(result.total)}`}
                  >
                    <div>
                      <span>À vista</span>
                      <div>
                        <i
                          style={{
                            width:
                              (result.cash /
                                Math.max(result.cash, result.total)) *
                                100 +
                              "%",
                          }}
                        />
                      </div>
                    </div>
                    <div>
                      <span>A prazo</span>
                      <div>
                        <i
                          style={{
                            width:
                              (result.total /
                                Math.max(result.cash, result.total)) *
                                100 +
                              "%",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="sim-explanation">
                    <h4>Olhe além do valor da parcela</h4>
                    <p>
                      Entrada de {money(result.down)} + {result.count} parcelas
                      de {money(result.payment)} = {money(result.total)}. A
                      diferença corresponde a{" "}
                      {Math.abs(result.percentage).toLocaleString("pt-BR", {
                        maximumFractionDigits: 2,
                      })}
                      % do preço à vista.
                    </p>
                    <p>
                      {result.implied === null
                        ? "Não há taxa implícita calculável neste cenário: a entrada já cobre o preço à vista."
                        : `Taxa mensal implícita estimada: ${(result.implied * 100).toLocaleString("pt-BR", { maximumFractionDigits: 4 })}%. Ela compara os fluxos informados, não é o CET do contrato.`}
                    </p>
                    <p>
                      Compare o custo total e quanto as parcelas comprometem dos
                      próximos meses. Uma parcela menor não significa que a
                      compra cabe no orçamento.
                    </p>
                  </div>
                </>
              )}
              {kind === "reserve" && (
                <>
                  <div className="planning-metrics">
                    <Metric
                      label="Reserva desejada"
                      value={money(result.target)}
                    />
                    <Metric
                      label="Ainda falta"
                      value={money(result.remaining)}
                    />
                    <Metric
                      label="Aportes necessários"
                      value={
                        result.months === null
                          ? "Sem prazo estimável"
                          : `${result.months} mês(es)`
                      }
                    />
                  </div>
                  <div className="sim-reserve-visual">
                    <div
                      className="planning-meter"
                      role="img"
                      aria-label={`Reserva informada cobre ${((result.current / result.target) * 100).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}% do objetivo`}
                    >
                      <span
                        style={{
                          width:
                            Math.min(
                              100,
                              (result.current / result.target) * 100,
                            ) + "%",
                        }}
                      />
                    </div>
                    <p>
                      {money(result.current)} já reservados de{" "}
                      {money(result.target)} desejados.
                    </p>
                  </div>
                  <div className="sim-explanation">
                    <h4>Uma referência, não uma regra universal</h4>
                    <p>
                      Despesas estimadas × {result.coverage} meses de cobertura.
                      O prazo divide o restante pelo aporte mensal e arredonda
                      para cima.
                    </p>
                    <p>
                      {result.remaining === 0
                        ? "O valor informado já alcança o objetivo deste cenário."
                        : result.monthly === 0
                          ? "Com aporte zero e sem rendimentos considerados, não há prazo para alcançar a reserva."
                          : "O prazo pressupõe aportes regulares e despesas estáveis, sem rendimentos."}
                    </p>
                    <p>
                      Escolha a cobertura considerando estabilidade de renda,
                      dependentes e suas despesas essenciais. O simulador não
                      avalia seu perfil nem movimenta dinheiro.
                    </p>
                  </div>
                </>
              )}
            </>
          )}
          <div className="sim-disclaimer">
            <ShieldCheck size={18} />
            <p>
              Cenários educativos. Não incluem impostos, tarifas, inflação,
              mudanças de taxa ou eventos imprevistos. No cálculo de juros,
              arredondamos apenas a exibição, não cada período. Use as condições
              reais dos contratos para decidir.
            </p>
          </div>
          {lessonId >= 0 && (
            <button className="text-btn" onClick={() => openLesson(lessonId)}>
              <BookOpen size={16} />
              Continuar na aula: {lessons[lessonId][0]}
            </button>
          )}
        </div>
      </div>
      <ScenarioComparison
        kind={kind}
        inputs={lastInputs}
        result={result}
        dirty={dirty}
      />
    </section>
  );
}
