// Deliberately public, synthetic-only credentials. Never reuse this password elsewhere.
export const publicTestAccount = Object.freeze({
  email: "professor@yfinance.test",
  password: "YFinance@Teste2026!",
  name: "Conta pública de testes",
  period: "Janeiro a novembro de 2026",
});
export const publicTestWarning =
  "Conta pública compartilhada, com dados fictícios de janeiro a novembro de 2026. Qualquer visitante com estas credenciais pode ver e alterar os registros, conversas e progresso. Não insira dados pessoais ou senhas. Datas futuras fazem parte do cenário de teste. Crie uma conta própria para testar do zero com dados separados.";
