import React, { useState, useEffect } from "react";
import {
  ArrowRight,
  ShieldCheck,
  LoaderCircle,
  ArrowLeft,
  User,
  Lock,
  TrendingUp,
} from "lucide-react";
import { publicTestAccount, publicTestWarning } from "./public-test-account.js";
import "./accounts.css";
export default function AuthPage({
  register,
  legacy,
  publicAvailable,
  authenticated,
  go,
  api,
  onAuthenticated,
  Logo,
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [challenge, setChallenge] = useState(null),
    [config, setConfig] = useState(null);
  useEffect(() => {
    api("access")
      .then(setConfig)
      .catch((e) => setError(e.message));
  }, []);
  return (
    <main className="auth-screen">
      <section className="auth-brand" aria-label="Y Finance">
        <Logo />
        <h2>
          Seu dinheiro.
          <br />
          Seus planos.
          <br />
          <span>Seu futuro.</span>
        </h2>
        <p>
          Organize suas finanças com uma conta própria.
          <br />
          Você decide o que registrar e quando começar.
        </p>
        <div className="auth-decoration">
          <div />
          <div />
          <div />
          <TrendingUp size={100} />
        </div>
        <small>
          Organização e educação financeira, sem chave de IA obrigatória.
        </small>
      </section>
      <section className="auth-content">
        {authenticated && (
          <button className="back-btn" onClick={() => go("dashboard")}>
            <ArrowLeft size={16} />
            Voltar à minha conta
          </button>
        )}
        <div className="auth-form-wrap">
          <span className="icon-tile large red">
            {register ? <User size={25} /> : <Lock size={25} />}
          </span>
          <h1>{register ? "Crie sua conta" : "Bem-vindo de volta"}</h1>
          {!register &&
            new URLSearchParams(location.search).get("senha") ===
              "redefinida" && (
              <p role="status">
                Senha redefinida. Entre novamente; o 2FA permanece ativo, se
                configurado.
              </p>
            )}
          <p>
            {register
              ? "Comece do zero: sem lançamentos, metas ou progresso pré-preenchidos. As categorias iniciais são editáveis e não têm limites definidos."
              : publicAvailable
                ? "Entre na sua conta ou use as credenciais públicas de teste abaixo."
                : "Entre com seu e-mail e senha ou crie uma conta para começar."}
          </p>
          {!register && publicAvailable && (
            <a className="auth-public-shortcut" href="#public-access">
              Ver e-mail e senha públicos de teste ↓
            </a>
          )}
          {challenge ? (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setBusy(true);
                setError("");
                try {
                  onAuthenticated(
                    await api("auth/verify-2fa", {
                      challenge,
                      code: new FormData(e.currentTarget).get("code"),
                    }),
                  );
                } catch (e) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              <h2>Confirme seu segundo fator</h2>
              <label className="field">
                <span>Código do autenticador ou de recuperação</span>
                <input
                  name="code"
                  autoComplete="one-time-code"
                  required
                  autoFocus
                />
              </label>
              <p>
                Cada código funciona uma vez. A verificação expira em 5 minutos.
              </p>
              {error && (
                <p role="alert" className="form-error">
                  {error}
                </p>
              )}
              <button className="primary" disabled={busy}>
                Verificar e entrar
              </button>
              <button
                type="button"
                className="text-btn"
                onClick={() => {
                  setChallenge(null);
                  setError("");
                }}
              >
                Voltar ao login
              </button>
            </form>
          ) : (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setError("");
                const f = Object.fromEntries(new FormData(e.currentTarget));
                if (register && f.password !== f.confirm) {
                  setError("As senhas não coincidem.");
                  return;
                }
                setBusy(true);
                try {
                  const preserving = register && legacy && f.preserve === "on";
                  const d = await api(
                    preserving
                      ? "auth/claim-legacy"
                      : "auth/" + (register ? "register" : "login"),
                    {
                      ...f,
                      preserve: preserving,
                      acceptLegal: f.acceptLegal === "on",
                      legalVersion: config?.legalVersion,
                      publicAcknowledged: f.publicAcknowledged === "on",
                    },
                  );
                  if (d.requires2FA) setChallenge(d.challenge);
                  else onAuthenticated(d);
                } catch (e) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              {register && (
                <label className="field">
                  <span>Nome</span>
                  <input
                    name="name"
                    autoComplete="name"
                    maxLength={80}
                    required
                    placeholder="Como podemos chamar você?"
                    disabled={busy}
                  />
                </label>
              )}
              <label className="field">
                <span>E-mail</span>
                <input
                  name="email"
                  type="email"
                  autoComplete="email"
                  maxLength={150}
                  required
                  placeholder="voce@exemplo.com"
                  disabled={busy}
                />
              </label>
              <label className="field">
                <span>Senha</span>
                <input
                  name="password"
                  type="password"
                  autoComplete={register ? "new-password" : "current-password"}
                  minLength={8}
                  maxLength={72}
                  required
                  placeholder={
                    register ? "Pelo menos 8 caracteres" : "Sua senha"
                  }
                  disabled={busy}
                />
              </label>
              {register && (
                <label className="field">
                  <span>Confirmar senha</span>
                  <input
                    name="confirm"
                    type="password"
                    autoComplete="new-password"
                    minLength={8}
                    maxLength={72}
                    required
                    placeholder="Repita sua senha"
                    disabled={busy}
                  />
                </label>
              )}
              {legacy && register && (
                <div className="legacy-access">
                  <strong>Encontramos uma sessão da versão anterior.</strong>
                  <p>
                    Se você registrou dados nela, pode vinculá-los ao novo
                    acesso. Sem marcar esta opção, a conta nova começa vazia; os
                    dados antigos não serão apagados.
                  </p>
                  <label>
                    <input name="preserve" type="checkbox" disabled={busy} />
                    Quero preservar os registros da minha sessão antiga
                  </label>
                </div>
              )}
              {register && (
                <label className="check-row">
                  <input type="checkbox" name="acceptLegal" required />
                  Li a política de privacidade e aceito os termos (versão{" "}
                  {config?.legalVersion || "carregando"}). As autorizações
                  opcionais ficam desativadas.
                </label>
              )}
              {!register && publicAvailable && (
                <label className="check-row">
                  <input type="checkbox" name="publicAcknowledged" />
                  Se usar a conta pública, entendo que seus dados e conversas
                  são compartilhados. Não inserirei dados pessoais.
                </label>
              )}
              {error && (
                <p className="form-error" role="alert">
                  {error}
                </p>
              )}
              <button className="primary full" disabled={busy}>
                {busy && <LoaderCircle size={18} className="spin" />}
                {register ? "Criar conta" : "Entrar"}
                <ArrowRight size={17} />
              </button>
            </form>
          )}
          <div className="auth-legal-links">
            <button className="text-btn" onClick={() => go("redefinir")}>
              Esqueci minha senha
            </button>
            <a href="/termos" target="_blank" rel="noopener">
              Termos e privacidade
            </a>
          </div>
          <p className="auth-switch">
            {register ? "Já tem uma conta?" : "Não tem uma conta?"}{" "}
            <button
              className="text-btn"
              disabled={busy}
              onClick={() => {
                setError("");
                go(register ? "login" : "register");
              }}
            >
              {register ? "Entrar" : "Criar conta"}
            </button>
          </p>
          {legacy && !register && (
            <button className="text-btn" onClick={() => go("register")}>
              Vincular minha sessão antiga a um cadastro
            </button>
          )}
          <p className="auth-note">
            <ShieldCheck size={15} />
            <span>
              Cadastro próprio desta instalação, sem login Google ou confirmação
              de e-mail. Use senha exclusiva e ative 2FA.{" "}
              {config?.passwordResetAvailable
                ? "Recuperação por e-mail configurada."
                : "Recuperação por e-mail indisponível: SMTP não configurado."}
            </span>
          </p>
          {publicAvailable && (
            <aside
              className="public-access"
              id="public-access"
              aria-label="Credenciais públicas para testes"
            >
              <span className="public-kicker">
                ACESSO PÚBLICO PARA AVALIAÇÃO
              </span>
              <h2>Explore um histórico completo.</h2>
              <p>{publicTestWarning}</p>
              <dl>
                <dt>E-mail</dt>
                <dd>
                  <code>{publicTestAccount.email}</code>
                </dd>
                <dt>Senha pública</dt>
                <dd>
                  <code>{publicTestAccount.password}</code>
                </dd>
              </dl>
              <small>
                O endereço .test é apenas um identificador de login, não uma
                caixa de e-mail. Entre pelo formulário acima. A conta é real e
                editável, mas seu conteúdo é fictício.
              </small>
            </aside>
          )}
        </div>
      </section>
    </main>
  );
}
