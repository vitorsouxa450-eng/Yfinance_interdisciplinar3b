// Pure scheduling rules shared by the calendar and the server. No payments.
export const todayBR = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(
    new Date(),
  );
const iso = (d) => d.toISOString().slice(0, 10);
export function validDate(value) {
  return (
    typeof value === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    Number.isFinite(Date.parse(value)) &&
    iso(new Date(value)) === value
  );
}
export function dueDate(rule, index = rule.nextIndex || 0) {
  const [year, month, day] = rule.startDate.split("-").map(Number);
  if (rule.frequency === "daily" || rule.frequency === "weekly")
    return iso(
      new Date(
        Date.UTC(
          year,
          month - 1,
          day + index * (rule.frequency === "weekly" ? 7 : 1),
        ),
      ),
    );
  const target = new Date(
    Date.UTC(
      year + (rule.frequency === "yearly" ? index : 0),
      month - 1 + (rule.frequency === "monthly" ? index : 0),
      1,
    ),
  );
  const last = new Date(
    Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0),
  ).getUTCDate();
  return iso(
    new Date(
      Date.UTC(
        target.getUTCFullYear(),
        target.getUTCMonth(),
        Math.min(day, last),
      ),
    ),
  );
}
export function nextOccurrence(rule) {
  if (rule.status === "ended") return null;
  const date = dueDate(rule);
  return (rule.endDate && date > rule.endDate) ||
    (rule.limit && rule.nextIndex >= rule.limit)
    ? null
    : date;
}
