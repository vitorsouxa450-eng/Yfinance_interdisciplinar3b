import React, { useState } from "react";
import { Copy, GitCompareArrows, Trash2 } from "lucide-react";
import {
  scenarioFields,
  comparisonRows,
  formatScenario,
} from "./comparison-model.js";
import "./release.css";
export default function ScenarioComparison({ kind, result, inputs, dirty }) {
  const [saved, setSaved] = useState({}),
    [notice, setNotice] = useState("");
  const base = saved[kind],
    ready = !!result && !dirty;
  const rows = base && ready ? comparisonRows(kind, base.result, result) : [];
  const metric = rows.find(
    (r) =>
      r.key ===
      (kind === "compound"
        ? "total"
        : kind === "installments"
          ? "total"
          : "target"),
  );
  return (
    <section
      className="card scenario-comparison"
      aria-label="Comparação de cenários"
    >
      <div className="release-section-title">
        <div>
          <span className="release-kicker">COMPARE ANTES DE ESCOLHER</span>
          <h2>
            <GitCompareArrows size={21} />
            Uma mudança. Dois cenários.
          </h2>
        </div>
        <button
          className="secondary"
          disabled={!ready}
          onClick={() => {
            setSaved((s) => ({
              ...s,
              [kind]: {
                inputs: structuredClone(inputs),
                result: structuredClone(result),
              },
            }));
            setNotice(
              "Cenário A guardado nesta tela. Altere os campos e calcule o cenário B.",
            );
          }}
        >
          <Copy size={16} />
          {base ? "Substituir cenário A" : "Guardar cenário A"}
        </button>
      </div>
      <p className="planning-note">
        Calcule um cenário e guarde-o como A. Depois altere os campos e calcule
        novamente: o resultado atual será B. Cada simulador tem seu próprio A,
        mantido somente enquanto esta tela estiver aberta.
      </p>
      {notice && (
        <p className="release-note" role="status">
          {notice}
        </p>
      )}
      {!base ? (
        <div className="release-empty">
          <p>
            Seu primeiro cenário será a referência para comparar aportes, custos
            ou prazos.
          </p>
        </div>
      ) : (
        <>
          <div className="scenario-base">
            <strong>Cenário A preservado</strong>
            <button
              className="text-btn"
              onClick={() => {
                setSaved((s) => {
                  const n = { ...s };
                  delete n[kind];
                  return n;
                });
                setNotice("Cenário A removido deste simulador.");
              }}
            >
              <Trash2 size={15} />
              Remover A
            </button>
          </div>
          {!ready ? (
            <p className="planning-info">
              Calcule o cenário atual para comparar. Se os campos mudaram, é
              necessário recalcular; não mostramos diferenças com dados
              desatualizados.
            </p>
          ) : (
            <>
              <p className="planning-info">
                A diferença é <strong>B − A</strong>, não uma indicação de qual
                cenário é melhor. Confira os valores, prazos e hipóteses:
                cenários com objetivos ou durações diferentes não são
                equivalentes.
              </p>
              {metric && (
                <div
                  className="scenario-bars"
                  role="img"
                  aria-label={`${metric.label}: A ${formatScenario(metric.a, metric.format)}; B ${formatScenario(metric.b, metric.format)}`}
                >
                  {[
                    ["A", metric.a],
                    ["B", metric.b],
                  ].map(([label, n]) => (
                    <div key={label}>
                      <span>{label}</span>
                      <div>
                        <i
                          style={{
                            width:
                              (Math.max(0, n) /
                                Math.max(1, metric.a, metric.b)) *
                                100 +
                              "%",
                          }}
                        />
                      </div>
                      <strong>{formatScenario(n, metric.format)}</strong>
                    </div>
                  ))}
                </div>
              )}
              <div
                className="planning-table"
                tabIndex={0}
                role="region"
                aria-label="Resultados dos cenários A e B"
              >
                <table>
                  <caption>Resultados · diferença B − A</caption>
                  <thead>
                    <tr>
                      <th>Indicador</th>
                      <th>Cenário A</th>
                      <th>Cenário B</th>
                      <th>Diferença</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.key}>
                        <th>{r.label}</th>
                        <td>{formatScenario(r.a, r.format)}</td>
                        <td>{formatScenario(r.b, r.format)}</td>
                        <td>
                          {r.format === "rate" && r.difference !== null
                            ? `${(r.difference * 100).toLocaleString("pt-BR", { maximumFractionDigits: 4 })} p.p.`
                            : formatScenario(r.difference, r.format)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <details className="scenario-inputs">
                <summary>Conferir as hipóteses de A e B</summary>
                <div
                  className="planning-table"
                  role="region"
                  aria-label="Hipóteses dos cenários A e B"
                  tabIndex={0}
                >
                  <table>
                    <thead>
                      <tr>
                        <th>Campo</th>
                        <th>A</th>
                        <th>B</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scenarioFields[kind].map(([key, label, format]) => (
                        <tr key={key}>
                          <th>{label}</th>
                          <td>{formatScenario(base.inputs[key], format)}</td>
                          <td>{formatScenario(inputs[key], format)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </details>
            </>
          )}
        </>
      )}
    </section>
  );
}
