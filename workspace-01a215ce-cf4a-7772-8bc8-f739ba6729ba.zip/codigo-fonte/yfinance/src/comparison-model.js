export const scenarioFields = {
  compound: [
    ["initial", "Capital inicial", "money"],
    ["monthly", "Aporte mensal", "money"],
    ["rate", "Taxa informada", "percent"],
    ["unit", "Unidade da taxa", "unit"],
    ["months", "Prazo em meses", "number"],
  ],
  installments: [
    ["cash", "Preço à vista", "money"],
    ["down", "Entrada", "money"],
    ["payment", "Parcela", "money"],
    ["count", "Número de parcelas", "number"],
  ],
  reserve: [
    ["expenses", "Despesas mensais", "money"],
    ["coverage", "Meses de cobertura", "number"],
    ["current", "Já reservado", "money"],
    ["monthly", "Aporte mensal", "money"],
  ],
};
const metrics = {
  compound: [
    ["invested", "Total investido", "money"],
    ["interest", "Juros estimados", "money"],
    ["total", "Saldo hipotético", "money"],
  ],
  installments: [
    ["total", "Total a prazo", "money"],
    ["difference", "Diferença para o preço à vista", "money"],
    ["implied", "Taxa mensal implícita", "rate"],
  ],
  reserve: [
    ["target", "Reserva desejada", "money"],
    ["remaining", "Falta guardar", "money"],
    ["months", "Prazo estimado (meses)", "number"],
  ],
};
export function comparisonRows(kind, a, b) {
  if (!metrics[kind]) throw new Error("Tipo de comparação inválido.");
  return metrics[kind].map(([key, label, format]) => ({
    key,
    label,
    format,
    a: a[key],
    b: b[key],
    difference: a[key] === null || b[key] === null ? null : b[key] - a[key],
  }));
}
export function formatScenario(value, format) {
  if (value === null || value === undefined) return "Não estimável";
  if (format === "unit")
    return value === "year" ? "Ao ano (efetiva)" : "Ao mês";
  if (format === "money")
    return Number(value).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  if (format === "percent" || format === "rate")
    return (
      (Number(value) * (format === "rate" ? 100 : 1)).toLocaleString("pt-BR", {
        maximumFractionDigits: 4,
      }) + "%"
    );
  return Number(value).toLocaleString("pt-BR", { maximumFractionDigits: 2 });
}
