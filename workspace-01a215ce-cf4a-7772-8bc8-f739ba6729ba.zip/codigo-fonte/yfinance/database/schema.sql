-- MySQL 8.4 LTS. Run db:setup, or import this file into an empty selected database.
-- No passwords or private records are shipped here. Seed is separate and idempotent.
CREATE TABLE IF NOT EXISTS schema_versions (
  version INT NOT NULL PRIMARY KEY,
  applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL PRIMARY KEY,
  email VARCHAR(254) NULL UNIQUE,
  password_hash VARCHAR(255) NULL,
  legacy_demo BOOLEAN NULL,
  public_test BOOLEAN NULL,
  account_data JSON NOT NULL,
  state_data JSON NOT NULL,
  position INT NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS categories (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  name VARCHAR(120) NOT NULL, kind ENUM('income','expense') NOT NULL,
 color VARCHAR(32) NOT NULL, budget DECIMAL(16,2) NOT NULL CHECK (budget >= 0),
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_categories_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS recurring_rules (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  description VARCHAR(255) NOT NULL, kind ENUM('income','expense') NOT NULL,
 amount DECIMAL(16,2) NOT NULL CHECK (amount > 0), category_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_recurring_rules_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_recurring_rules_category FOREIGN KEY (user_id, category_id) REFERENCES categories(user_id, id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS transactions (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  description VARCHAR(255) NOT NULL, kind ENUM('income','expense') NOT NULL,
 amount DECIMAL(16,2) NOT NULL CHECK (amount > 0), category_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
 transaction_date DATE NOT NULL,
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_transactions_category FOREIGN KEY (user_id, category_id) REFERENCES categories(user_id, id),
  INDEX idx_transactions_period (user_id, transaction_date)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS goals (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  name VARCHAR(120) NOT NULL, target_amount DECIMAL(16,2) NOT NULL CHECK (target_amount > 0),
 current_amount DECIMAL(16,2) NOT NULL CHECK (current_amount >= 0),
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_goals_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS notifications (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS chat_messages (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_chat_messages_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS learning_progress (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_learning_progress_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS budget_months (
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  
  details JSON NOT NULL,
  position INT NOT NULL,
  PRIMARY KEY (user_id, id),
  CONSTRAINT fk_budget_months_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS sessions (
  hash VARCHAR(128) COLLATE utf8mb4_bin NOT NULL PRIMARY KEY,
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  expires_at_ms BIGINT NOT NULL,
  details JSON NOT NULL,
  position INT NOT NULL,
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_sessions_expiry (expires_at_ms)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS login_challenges (
  hash VARCHAR(128) COLLATE utf8mb4_bin NOT NULL PRIMARY KEY,
  user_id VARCHAR(128) COLLATE utf8mb4_bin NOT NULL,
  expires_at_ms BIGINT NOT NULL,
  details JSON NOT NULL,
  position INT NOT NULL,
  CONSTRAINT fk_login_challenges_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_login_challenges_expiry (expires_at_ms)
) ENGINE=InnoDB;
INSERT IGNORE INTO schema_versions(version) VALUES (1);
