import { defineConfig, loadEnv } from "vite";
import { fileURLToPath } from "node:url";
import { localPorts } from "./scripts/local-ports.js";

const project = fileURLToPath(new URL("./", import.meta.url));
const landing = fileURLToPath(new URL("../yfinance-landing/", import.meta.url));

export default defineConfig(({ mode }) => {
  const isLanding = mode === "landing";
  const ports = localPorts({ ...loadEnv(mode, project, "LOCAL_"), ...process.env });
  return {
    root: isLanding ? landing : project,
    // Do not load installation secrets into either browser-facing dev server.
    envDir: project,
    envPrefix: "YF_PUBLIC_UNUSED_",
    server: {
      host: "0.0.0.0",
      port: isLanding ? ports.LOCAL_LANDING_PORT : ports.LOCAL_SITE_PORT,
      strictPort: true,
      allowedHosts: [".e2b.app"],
      cors: false,
      fs: {
        strict: true,
        allow: [isLanding ? landing : project],
        deny: [
          "**/.env*", "**/data/**", "**/server.js", "**/lib/**",
          "**/scripts/**", "**/database/**", "**/tests/**",
          "**/tests*.mjs", "**/vite*.config.*", "**/*.pem", "**/*.key",
        ],
      },
      // The browser always calls /api on its own origin. Preserve Host/Origin
      // for the existing session and CSRF checks; do not enable API CORS.
      ...(!isLanding && {
        proxy: {
          "/api": {
            target: `http://127.0.0.1:${ports.LOCAL_API_PORT}`,
            changeOrigin: false,
          },
        },
      }),
    },
  };
});
