import { LEGAL_VERSION } from "../lib/legal-documents.js";
import { publicTestAccount } from "../src/public-test-account.js";
// Runs a separate server with synthetic data only. Never opens the installation's data/.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import realFs from "node:fs/promises";
import { mysqlTestFilesystem } from "./support/mysql-filesystem.js";
const fs =
  process.env.TEST_MYSQL === "1" ? mysqlTestFilesystem(realFs) : realFs;
process.env.DB_DRIVER = process.env.TEST_MYSQL === "1" ? "mysql" : "json-test";
process.env.NODE_ENV = "test";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { once } from "node:events";
import net from "node:net";
import ExcelJS from "exceljs";
import { todayBR } from "../src/schedule-model.js";
import { curriculum } from "../src/curriculum.js";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let runtime,
  child,
  base,
  token,
  initial,
  logs = "";
async function start() {
  const probe = net.createServer();
  await new Promise((resolve) => probe.listen(0, "127.0.0.1", resolve));
  const port = probe.address().port;
  await new Promise((resolve) => probe.close(resolve));
  base = `http://127.0.0.1:${port}/api/`;
  child = spawn(process.execPath, ["server.js", "--production"], {
    cwd: runtime,
    env: {
      ...process.env,
      PORT: String(port),
      AI_API_KEY: "",
      SMTP_HOST: "",
      SMTP_USER: "",
      SMTP_PASS: "",
      SMTP_FROM: "",
      APP_PUBLIC_URL: "",
      COOKIE_SECURE: "false",
      TRUST_PROXY_HOPS: "0",
      NODE_ENV: "test",
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stderr.on("data", (d) => {
    logs += d.toString();
  });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error("Servidor de teste não iniciou: " + logs)),
      15000,
    );
    child.once("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.once("exit", (code) => {
      clearTimeout(timer);
      reject(new Error(`Servidor encerrou (${code}): ${logs}`));
    });
    child.stdout.on("data", (d) => {
      logs += d.toString();
      if (logs.includes("disponível na porta " + port)) {
        clearTimeout(timer);
        resolve();
      }
    });
  });
}
async function stop() {
  if (child && child.exitCode === null) {
    const exited = once(child, "exit");
    child.kill();
    await exited;
  }
  child = null;
}
async function request(endpoint, body, status = 200, auth = token) {
  if (["auth/register", "auth/claim-legacy"].includes(endpoint))
    body = { ...body, acceptLegal: true, legalVersion: LEGAL_VERSION };
  if (endpoint === "auth/login" && body.email === publicTestAccount.email)
    body = { ...body, publicAcknowledged: true };
  const r = await fetch(base + endpoint, {
    signal: AbortSignal.timeout(15000),
    method: body === undefined ? "GET" : "POST",
    headers: {
      ...(auth?.cookie
        ? { Cookie: auth.cookie, "X-CSRF-Token": auth.csrf }
        : { Authorization: `Bearer ${auth || ""}` }),
      ...(body === undefined
        ? {}
        : {
            "Content-Type": Buffer.isBuffer(body)
              ? "application/octet-stream"
              : "application/json",
          }),
    },
    ...(body === undefined
      ? {}
      : { body: Buffer.isBuffer(body) ? body : JSON.stringify(body) }),
  });
  assert.equal(
    r.status,
    status,
    endpoint + ": " + (r.status === status ? "" : await r.text()),
  );
  return r;
}
// Test-only session handle, not an API bearer token.
const json = async (...args) => {
  const r = await request(...args),
    d = await r.json();
  if (r.headers.get("set-cookie"))
    d.token = {
      cookie: r.headers.get("set-cookie").split(";")[0],
      csrf: r.headers.get("x-csrf-token"),
    };
  return d;
};
const action = (a, p) => json("action", { action: a, payload: p });
before(async () => {
  runtime = await fs.mkdtemp(path.join(os.tmpdir(), "yfinance-tests-"));
  for (const name of ["src", "lib", "scripts", "server.js", "package.json"])
    await fs.cp(path.join(root, name), path.join(runtime, name), {
      recursive: true,
    });
  await fs.symlink(
    path.join(root, "node_modules"),
    path.join(runtime, "node_modules"),
    process.platform === "win32" ? "junction" : "dir",
  );
  const seed = spawn(process.execPath, ["scripts/create-public-account.js"], {
    cwd: runtime,
    stdio: "ignore",
  });
  assert.equal((await once(seed, "exit"))[0], 0);
  const seeded = await fs.readFile(
    path.join(runtime, "data/database.json"),
    "utf8",
  );
  const seedAgain = spawn(
    process.execPath,
    ["scripts/create-public-account.js"],
    { cwd: runtime, stdio: "ignore" },
  );
  assert.equal((await once(seedAgain, "exit"))[0], 0);
  assert.equal(
    await fs.readFile(path.join(runtime, "data/database.json"), "utf8"),
    seeded,
  );
  await start();
  const boot = await json(
    "auth/login",
    { email: publicTestAccount.email, password: publicTestAccount.password },
    200,
    "",
  );
  token = boot.token;
  initial = boot.state;
});
after(async () => {
  await stop();
  if (runtime) await fs.rm(runtime, { recursive: true, force: true });
});
test("API: sessão, histórico inicial e isolamento por conta", async () => {
  assert.ok(initial.budgetHistory[todayBR().slice(0, 7)]);
  await request("state", undefined, 401, "invalid");
  const other = await json(
    "auth/register",
    {
      name: "Teste",
      email: "synthetic@example.test",
      password: "SenhaSintetica123",
    },
    200,
    "",
  );
  assert.equal(other.state.transactions.length, 0);
  await request(
    "action",
    {
      action: "goal.deposit",
      payload: { id: initial.goals[0].id, amount: 10 },
    },
    404,
    other.token,
  );
});
test("API: falha de gravação reverte ações, chat e logout", async () => {
  const temp = path.join(runtime, "data", "database.json.tmp");
  for (const [a, p] of [
    ["profile.save", { name: "Não salvar" }],
    ["goal.deposit", { id: initial.goals[0].id, amount: 1 }],
    ["budget.save", { id: initial.categories[0].id, budget: 1 }],
  ]) {
    const before = await json("state");
    await fs.mkdir(temp);
    try {
      await request("action", { action: a, payload: p }, 500);
      assert.deepEqual(await json("state"), before);
    } finally {
      await fs.rmdir(temp);
    }
  }
  const before = await json("state");
  await fs.mkdir(temp);
  try {
    await request("chat", { message: "Analise meus gastos" }, 500);
    await request("logout", {}, 500);
    assert.deepEqual(await json("state"), before);
  } finally {
    await fs.rmdir(temp);
  }
});
test("API: cadastro falho não deixa conta órfã", async () => {
  const temp = path.join(runtime, "data", "database.json.tmp"),
    body = {
      name: "Teste",
      email: "failed@example.test",
      password: "SenhaSintetica123",
    };
  await fs.mkdir(temp);
  try {
    await request("auth/register", body, 500, "");
  } finally {
    await fs.rmdir(temp);
  }
  await request("auth/login", body, 401, "");
  await request("auth/register", body, 200, "");
});
test("API: limite atual salvo, mês passado recusado", async () => {
  const month = todayBR().slice(0, 7),
    c = initial.categories[0];
  await request(
    "action",
    {
      action: "budget.save",
      payload: { id: c.id, month: "2000-01", budget: 17 },
    },
    409,
  );
  const r = await action("budget.save", { id: c.id, month, budget: 911 });
  assert.equal(r.state.budgetHistory[month].entries[c.id].limit, 911);
});
test("API: 17 quizzes mantêm a melhor nota e atualizam última tentativa", async () => {
  for (let id = 0; id < curriculum.length; id++) {
    await action("learning.quiz.retry", { id });
    for (let question = 0; question < 3; question++)
      await action("learning.quiz.answer", {
        id,
        question,
        answer: curriculum[id].quiz[question].answer,
      });
    const r = await action("learning.quiz.submit", { id });
    assert.equal(r.state.learning[id].quiz.bestScore, 3);
  }
  await action("learning.quiz.retry", { id: 0 });
  for (let question = 0; question < 3; question++)
    await action("learning.quiz.answer", {
      id: 0,
      question,
      answer:
        (curriculum[0].quiz[question].answer + 1) %
        curriculum[0].quiz[question].options.length,
    });
  const r = await action("learning.quiz.submit", { id: 0 });
  assert.equal(r.state.learning[0].quiz.bestScore, 3);
  assert.equal(r.state.learning[0].quiz.last.score, 0);
});
test("API: Excel preview/commit/backup/undo preservam orçamento histórico", async () => {
  const before = (await json("state")).state;
  const r = await request("reports", {
    kind: "completo",
    start: todayBR().slice(0, 7) + "-01",
    end: todayBR(),
  });
  const w = new ExcelJS.Workbook();
  await w.xlsx.load(Buffer.from(await r.arrayBuffer()));
  w.getWorksheet("Orçamentos").getCell("C6").value += 5;
  w.getWorksheet("Metas").getCell("D6").value += 5;
  const bytes = Buffer.from(await w.xlsx.writeBuffer());
  const p = (await json("imports/preview", bytes)).preview;
  assert.deepEqual(p.errors, []);
  assert.equal(p.counts.total, 2);
  await request("imports/commit", { previewId: p.previewId }, 400);
  const temp = path.join(runtime, "data", "database.json.tmp");
  await fs.mkdir(temp);
  try {
    await request(
      "imports/commit",
      { previewId: p.previewId, confirm: true },
      500,
    );
    assert.deepEqual((await json("state")).state, before);
  } finally {
    await fs.rmdir(temp);
  }
  await request("imports/commit", { previewId: p.previewId, confirm: true });
  assert.equal(
    (await json("imports/preview", bytes)).preview.alreadyImported,
    true,
  );
  const backup = await request("imports/backup/" + p.previewId);
  assert.match(backup.headers.get("content-type"), /json/);
  const undone = await json("imports/undo", {
    backupId: p.previewId,
    confirm: true,
  });
  assert.deepEqual(undone.state.budgetHistory, before.budgetHistory);
  assert.deepEqual(undone.state.goals, before.goals);
});
test("API: reinício preserva estado, sessão e backup", async () => {
  const before = await json("state");
  await stop();
  await start();
  assert.deepEqual(await json("state"), before);
});

test("API: backup integral restaurado em cópia isolada recupera a sessão e o estado", async () => {
  const before = await json("state");
  await stop();
  const database = await fs.readFile(path.join(runtime, "data/database.json"));
  const key = await fs.readFile(path.join(runtime, "data/import-signing-key"));
  await start();
  await action("profile.save", { name: "Alteração depois do backup" });
  assert.notEqual(
    (await json("state")).state.profile.name,
    before.state.profile.name,
  );
  await stop();
  await fs.writeFile(path.join(runtime, "data/database.json"), database, {
    mode: 0o600,
  });
  await fs.writeFile(path.join(runtime, "data/import-signing-key"), key, {
    mode: 0o600,
  });
  await start();
  assert.deepEqual(await json("state"), before);
});

test("API: chatbot BETA persiste contexto e fontes sem alterar finanças ou progresso", async () => {
  const before = (await json("state")).state;
  await json("chat", { message: "Explique a aula 14" });
  await json("chat", { message: "Quais são as fontes dessa aula?" });
  const after = (await json("state")).state,
    last = after.chat.at(-1);
  assert.equal(last.mode, "local-project");
  assert.equal(last.insight.project.lessonId, 13);
  assert.ok(last.insight.references.length);
  assert.match(last.insight.note, /BETA/);
  for (const key of [
    "transactions",
    "goals",
    "categories",
    "recurring",
    "budgetHistory",
    "learning",
    "completed",
    "profile",
    "settings",
  ])
    assert.deepEqual(after[key], before[key], key);
  await stop();
  await start();
  assert.deepEqual((await json("state")).state.chat.at(-1), last);
});

test("API: visitante não recebe conta anônima nem dados, e semeador recusa servidor ativo", async () => {
  const before = await fs.readFile(
    path.join(runtime, "data/database.json"),
    "utf8",
  );
  for (const auth of ["", "token-invalido"]) {
    const boot = await json("bootstrap", {}, 200, auth);
    assert.equal(boot.authenticated, false);
    assert.equal(boot.state, undefined);
    assert.equal(boot.token, undefined);
    assert.equal(boot.publicTestAvailable, true);
    await request("state", undefined, 401, auth);
  }
  assert.equal(
    await fs.readFile(path.join(runtime, "data/database.json"), "utf8"),
    before,
  );
  const seed = spawn(process.execPath, ["scripts/create-public-account.js"], {
    cwd: runtime,
    stdio: "ignore",
  });
  assert.equal((await once(seed, "exit"))[0], 1);
  assert.equal(
    await fs.readFile(path.join(runtime, "data/database.json"), "utf8"),
    before,
  );
});
test("API: validações de cadastro, endereço público reservado e login inválido", async () => {
  const baseUser = {
    name: "Novo usuário",
    email: "novo-validacao@example.test",
    password: "TesteNovo123!",
  };
  for (const extra of [
    { name: "" },
    { email: "invalido" },
    { password: "curta" },
    { password: "é".repeat(40) },
    { email: publicTestAccount.email },
  ])
    await request("auth/register", { ...baseUser, ...extra }, 400, "");
  const r = await json("auth/register", baseUser, 200, "");
  assert.ok(r.token);
  assert.equal(r.publicTest, false);
  await request(
    "auth/register",
    { ...baseUser, email: baseUser.email.toUpperCase() },
    400,
    "",
  );
  await request(
    "auth/login",
    { email: baseUser.email, password: "Incorreta123" },
    401,
    "",
  );
  const db = JSON.parse(
    await fs.readFile(path.join(runtime, "data/database.json"), "utf8"),
  );
  const user = db.users.find((u) => u.email === baseUser.email);
  assert.ok(user.password.startsWith("$2"));
  assert.notEqual(user.password, baseUser.password);
  assert.equal(r.password, undefined);
  assert.equal(r.state.password, undefined);
});
test("API: conta do zero utiliza finanças, alertas, recorrências, educação, chat e Excel", async () => {
  const credentials = {
    name: "Professor novo",
    email: "professor-novo@example.test",
    password: "ProfessorNovo2026!",
  };
  const registered = await json("auth/register", credentials, 200, "");
  const t = registered.token;
  const act = (action, payload) => json("action", { action, payload }, 200, t);
  for (const key of ["transactions", "goals", "recurring", "completed", "chat"])
    assert.deepEqual(registered.state[key], []);
  assert.ok(registered.state.categories.every((c) => c.budget === 0));
  assert.deepEqual(registered.state.learning, {});
  let state = (
    await act("category.save", {
      name: "Teste próprio",
      type: "expense",
      budget: 50,
      color: "#2563eb",
    })
  ).state;
  const c = state.categories.find((c) => c.name === "Teste próprio");
  const income = state.categories.find((c) => c.type === "income");
  state = (
    await act("transaction.save", {
      description: "Primeira receita",
      amount: 1000,
      type: "income",
      categoryId: income.id,
      date: todayBR(),
      payment: "Pix",
    })
  ).state;
  state = (
    await act("transaction.save", {
      description: "Primeira despesa",
      amount: 80,
      type: "expense",
      categoryId: c.id,
      date: todayBR(),
      payment: "Pix",
    })
  ).state;
  assert.equal(state.transactions.length, 2);
  assert.ok(
    state.notifications.some(
      (n) => n.categoryId === c.id && n.threshold === 100,
    ),
  );
  state = (
    await act("goal.save", {
      name: "Meta nova",
      category: "Reserva",
      target: 2000,
      current: 0,
      date: "",
      color: "#2563eb",
    })
  ).state;
  const g = state.goals[0];
  state = (await act("goal.deposit", { id: g.id, amount: 100 })).state;
  assert.equal(state.goals[0].current, 100);
  state = (
    await act("recurring.save", {
      description: "Recorrência nova",
      amount: 10,
      type: "expense",
      categoryId: c.id,
      startDate: todayBR(),
      frequency: "monthly",
      payment: "Pix",
      limit: 3,
    })
  ).state;
  const rule = state.recurring[0];
  assert.equal(
    state.transactions.filter((x) => x.recurringId === rule.id).length,
    1,
  );
  await act("recurring.pause", { id: rule.id });
  await act("recurring.resume", { id: rule.id });
  state = (await json("state", undefined, 200, t)).state;
  assert.equal(
    state.transactions.filter((x) => x.recurringId === rule.id).length,
    1,
  );
  await act("lesson.toggle", { id: 0 });
  await act("learning.visit", { id: 0 });
  await act("learning.challenge.start", { id: 0 });
  for (let step = 0; step < 3; step++)
    await act("learning.challenge.step", { id: 0, step, done: true });
  await act("learning.challenge.complete", {
    id: 0,
    reflection:
      "Planejamento feito no teste sintético de uma conta nova, sem dados predefinidos.",
  });
  for (let question = 0; question < 3; question++)
    await act("learning.quiz.answer", {
      id: 0,
      question,
      answer: curriculum[0].quiz[question].answer,
    });
  state = (await act("learning.quiz.submit", { id: 0 })).state;
  assert.equal(state.learning[0].quiz.bestScore, 3);
  assert.ok(state.learning[0].challenge.completedAt);
  await json("chat", { message: "Analise meus gastos deste mês" }, 200, t);
  const chatted = (
    await json(
      "chat",
      { message: "Gere uma planilha completa deste mês" },
      200,
      t,
    )
  ).state;
  assert.ok(chatted.chat.at(-1).report);
  const spec = {
    kind: "completo",
    start: todayBR().slice(0, 7) + "-01",
    end: todayBR(),
  };
  const report = await request("reports", spec, 200, t),
    w = new ExcelJS.Workbook();
  await w.xlsx.load(Buffer.from(await report.arrayBuffer()));
  w.getWorksheet("Metas").getCell("D6").value += 25;
  const bytes = Buffer.from(await w.xlsx.writeBuffer()),
    preview = (await json("imports/preview", bytes, 200, t)).preview;
  assert.deepEqual(preview.errors, []);
  assert.equal(preview.counts.total, 1);
  const imported = await json(
    "imports/commit",
    { previewId: preview.previewId, confirm: true },
    200,
    t,
  );
  assert.equal(imported.state.goals[0].current, 125);
  const undone = await json(
    "imports/undo",
    { backupId: preview.previewId, confirm: true },
    200,
    t,
  );
  assert.equal(undone.state.goals[0].current, 100);
  await request("imports/preview", bytes, 403, token);
  await request(
    "action",
    { action: "goal.deposit", payload: { id: g.id, amount: 1 } },
    404,
    token,
  );
  await act("profile.save", { name: "Professor teste concluído" });
  await act("settings.save", { dark: false, hide: true });
  await request("logout", {}, 200, t);
  await request("state", undefined, 401, t);
  const login = await json("auth/login", credentials, 200, "");
  assert.equal(login.state.profile.name, "Professor teste concluído");
  assert.equal(login.state.settings.hide, true);
  assert.equal(login.state.goals[0].current, 100);
});
test("API: sessão antiga só migra com consentimento, preserva registros e revoga token antigo", async () => {
  const { randomUUID, createHash } = await import("node:crypto");
  const { initialAccount } = await import("../lib/account-state.js");
  await stop();
  const file = path.join(runtime, "data/database.json"),
    db = JSON.parse(await fs.readFile(file, "utf8"));
  const legacyToken = "synthetic-legacy-session",
    id = randomUUID(),
    s = initialAccount();
  s.profile.name = "Sessão antiga sintética";
  s.goals = [
    {
      id: randomUUID(),
      name: "Meta preservada",
      target: 100,
      current: 25,
      date: "",
      color: "#2563eb",
      category: "Reserva",
    },
  ];
  db.users.push({ id, demo: true, state: s });
  db.sessions.push({
    hash: createHash("sha256").update(legacyToken).digest("hex"),
    userId: id,
    expires: Date.now() + 86400000,
  });
  await fs.writeFile(file, JSON.stringify(db));
  await start();
  const boot = await json("bootstrap", {}, 200, legacyToken);
  assert.equal(boot.legacy, true);
  assert.equal(boot.state, undefined);
  await request("state", undefined, 401, legacyToken);
  const c = {
    name: "Conta migrada",
    email: "migracao@example.test",
    password: "Migracao2026!",
  };
  await request("auth/claim-legacy", c, 400, legacyToken);
  await request("auth/claim-legacy", { ...c, preserve: true }, 401, "");
  const result = await json(
    "auth/claim-legacy",
    { ...c, preserve: true },
    200,
    legacyToken,
  );
  assert.deepEqual(result.state.goals, s.goals);
  assert.equal(result.state.profile.email, c.email);
  assert.equal(result.publicTest, false);
  await request("state", undefined, 401, legacyToken);
  await request("state", undefined, 200, result.token);
  const login = await json("auth/login", c, 200, "");
  assert.deepEqual(login.state.goals, s.goals);
});

test("Segurança: cookie HttpOnly, CSRF e origem; sem token de sessão na resposta", async () => {
  const r = await request(
    "auth/login",
    { email: publicTestAccount.email, password: publicTestAccount.password },
    200,
    "",
  );
  assert.match(r.headers.get("set-cookie"), /HttpOnly/);
  assert.match(r.headers.get("set-cookie"), /SameSite=Lax/);
  const d = await r.json();
  assert.equal(d.token, undefined);
  assert.ok(d.csrfToken);
  const cookie = r.headers.get("set-cookie").split(";")[0];
  for (const headers of [
    { Cookie: cookie },
    {
      Cookie: cookie,
      "X-CSRF-Token": d.csrfToken,
      Origin: "https://attacker.invalid",
    },
  ]) {
    const r = await fetch(base + "action", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify({
        action: "profile.save",
        payload: { name: "CSRF" },
      }),
    });
    assert.equal(r.status, 403);
  }
  const secure = await fetch(base + "auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Forwarded-Proto": "https",
    },
    body: JSON.stringify({
      email: publicTestAccount.email,
      password: publicTestAccount.password,
      publicAcknowledged: true,
    }),
  });
  assert.match(secure.headers.get("set-cookie"), /Secure/);
  assert.match(secure.headers.get("set-cookie"), /Partitioned/);
});

test("Segurança: acesso gratuito, preferências, consentimentos, notificações e proteção de conteúdo", async () => {
  const c = {
    name: "Privacidade",
    email: "private-features@example.test",
    password: "PrivateTeste2026!",
  };
  const a = await json("auth/register", c, 200, "");
  const t = a.token;
  assert.equal(a.subscription, undefined);
  assert.equal(a.state.notifications[0].type, "account");
  await request("library", undefined, 200, t);
  await request("library/renda-irregular", undefined, 200, t);
  await request("chat", { message: "Olá" }, 200, t);
  await request(
    "account/preferences",
    { subscription: { status: "active" } },
    400,
    t,
  );
  await request(
    "action",
    { action: "subscription.save", payload: { status: "active" } },
    400,
    t,
  );
  await request("account/preferences", { externalAI: true }, 403, t);
  await request(
    "account/preferences",
    {
      name: "<script>alert(1)</script>",
      budgetAlerts: false,
      productUpdates: true,
      reducedMotion: true,
      dark: false,
      hide: true,
    },
    200,
    t,
  );
  await request("account/preferences", { productUpdates: false }, 200, t);
  await request("subscription/request", {}, 404, t);
  await request("subscription/request", {}, 404, t);
  const state = await json("state", undefined, 200, t);
  assert.equal(
    state.state.notifications.filter((n) => n.type === "subscription").length,
    0,
  );
  await request(
    "action",
    {
      action: "notification.read",
      payload: { id: state.state.notifications[0].id },
    },
    404,
    token,
  );
  await request(
    "action",
    {
      action: "notification.archive",
      payload: { id: state.state.notifications[0].id },
    },
    200,
    t,
  );
  const exported = await json("privacy/export", undefined, 200, t);
  assert.ok(exported.consents.some((c) => c.granted === false));
  assert.equal(exported.password, undefined);
  assert.equal(exported.state._importReceipts, undefined);
  await request("logout", {}, 200, t);
  await request("state", undefined, 401, t);
  const login = await json("auth/login", c, 200, "");
  const account = await json("account", undefined, 200, login.token);
  assert.equal(account.preferences.budgetAlerts, false);
  assert.equal(account.preferences.reducedMotion, true);
  assert.equal(account.preferences.hide, true);
  assert.equal(account.profile.name, "<script>alert(1)</script>");
  assert.equal(account.consents.length, 2);
  const library = await json("library", undefined, 200, token);
  assert.equal(library.items.length, 6);
  assert.equal(library.items[0].sections, undefined);
  for (const item of library.items) {
    const article = await json("library/" + item.id, undefined, 200, token);
    assert.ok(article.sections.length);
    assert.ok(article.references.every(Boolean));
  }
  for (const endpoint of [
    "account/password",
    "account/delete",
    "account/2fa/setup",
  ])
    await request(
      endpoint,
      { password: publicTestAccount.password, confirm: true },
      403,
      token,
    );
  for (const file of [
    "/data/database.json",
    "/data/security-key",
    "/.env",
    "/lib/educational-library.js",
    "/server.js",
  ]) {
    const r = await fetch(base.replace(/\/api\/$/, "") + file);
    const text = await r.text();
    assert.ok(
      !text.includes("recoveryHashes") &&
        !text.includes('"users":') &&
        !text.includes("export const educationalLibrary"),
    );
  }
});

test("Segurança: 2FA real, replay, recuperação de uso único, sessões, senha e exclusão", async () => {
  const { otp } = await import("../lib/security-core.js");
  const c = {
    name: "Segundo fator",
    email: "two-factor@example.test",
    password: "TwoFactor2026!",
  };
  let a = await json("auth/register", c, 200, "");
  let t = a.token;
  const second = await json("auth/login", c, 200, "");
  await request("account/2fa/setup", { password: "errada" }, 401, t);
  const setup = await json(
    "account/2fa/setup",
    { password: c.password },
    200,
    t,
  );
  assert.ok(setup.qr.startsWith("data:image/png;base64,"));
  const code = otp(setup.secret, Math.floor(Date.now() / 30000));
  await request("account/2fa/enable", { code: "xxxxxx" }, 400, t);
  const enabled = await json("account/2fa/enable", { code }, 200, t);
  assert.equal(enabled.recoveryCodes.length, 8);
  await request("state", undefined, 401, second.token);
  await request("logout", {}, 200, t);
  const challenge = await json("auth/login", c, 200, "");
  assert.equal(challenge.requires2FA, true);
  assert.equal(challenge.state, undefined);
  assert.equal(challenge.token, undefined);
  await request(
    "auth/verify-2fa",
    { challenge: challenge.challenge, code },
    401,
    "",
  );
  a = await json(
    "auth/verify-2fa",
    { challenge: challenge.challenge, code: enabled.recoveryCodes[0] },
    200,
    "",
  );
  t = a.token;
  await request(
    "auth/verify-2fa",
    { challenge: challenge.challenge, code: enabled.recoveryCodes[1] },
    401,
    "",
  );
  await request(
    "account/2fa/recovery",
    { password: c.password, code: enabled.recoveryCodes[0] },
    401,
    t,
  );
  const renewed = await json(
    "account/2fa/recovery",
    { password: c.password, code: enabled.recoveryCodes[1] },
    200,
    t,
  );
  assert.equal(renewed.recoveryCodes.length, 8);
  await request(
    "account/sessions/revoke",
    { password: c.password, code: enabled.recoveryCodes[2] },
    401,
    t,
  );
  await request(
    "account/sessions/revoke",
    { password: c.password, code: renewed.recoveryCodes[0] },
    200,
    t,
  );
  await request(
    "account/password",
    {
      password: c.password,
      newPassword: "NewFactor2026!",
      code: renewed.recoveryCodes[1],
    },
    200,
    t,
  );
  await request("state", undefined, 401, t);
  await request("auth/login", c, 401, "");
  c.password = "NewFactor2026!";
  const ch = await json("auth/login", c, 200, "");
  a = await json(
    "auth/verify-2fa",
    { challenge: ch.challenge, code: renewed.recoveryCodes[2] },
    200,
    "",
  );
  t = a.token;
  await request(
    "account/2fa/disable",
    { password: c.password, code: renewed.recoveryCodes[3] },
    200,
    t,
  );
  await request("state", undefined, 401, t);
  a = await json("auth/login", c, 200, "");
  assert.equal(a.requires2FA, undefined);
  t = a.token;
  await request(
    "account/delete",
    { password: c.password, confirm: "sim" },
    400,
    t,
  );
  await request(
    "account/delete",
    { password: c.password, confirm: "EXCLUIR MINHA CONTA" },
    200,
    t,
  );
  await request("state", undefined, 401, t);
  await request("auth/login", c, 401, "");
  const db = JSON.parse(
    await fs.readFile(path.join(runtime, "data/database.json"), "utf8"),
  );
  assert.ok(!db.users.some((u) => u.email === c.email));
});

test("Segurança: recuperação offline entregue ao teste, uso único e preservação de 2FA", async () => {
  const { otp } = await import("../lib/security-core.js");
  const c = {
    name: "Reset",
    email: "reset@example.test",
    password: "ResetOld2026!",
  };
  const reg = await json("auth/register", c, 200, "");
  const t = reg.token;
  await request("auth/request-reset", { email: c.email }, 503, "");
  const setup = await json(
      "account/2fa/setup",
      { password: c.password },
      200,
      t,
    ),
    enabled = await json(
      "account/2fa/enable",
      { code: otp(setup.secret, Math.floor(Date.now() / 30000)) },
      200,
      t,
    );
  await stop();
  let link = "";
  const op = spawn(
    process.execPath,
    [
      "scripts/admin-account.js",
      "issue-reset",
      "--email",
      c.email,
      "--base-url",
      "https://example.test",
    ],
    { cwd: runtime, stdio: ["ignore", "pipe", "pipe"] },
  );
  op.stdout.on("data", (d) => (link += d));
  assert.equal((await once(op, "exit"))[0], 0);
  const resetToken = link.match(/token=([a-f0-9]{64})/)[1];
  const db = JSON.parse(
    await fs.readFile(path.join(runtime, "data/database.json"), "utf8"),
  );
  const u = db.users.find((u) => u.email === c.email);
  assert.notEqual(u.passwordReset.hash, resetToken);
  assert.notEqual(u.twoFactor.secret.body, setup.secret);
  assert.ok(!JSON.stringify(u).includes(setup.secret));
  await start();
  await request(
    "auth/reset-password",
    { token: resetToken, newPassword: "ResetNew2026!" },
    401,
    "",
  );
  await request(
    "auth/reset-password",
    {
      token: resetToken,
      newPassword: "ResetNew2026!",
      code: enabled.recoveryCodes[0],
    },
    200,
    "",
  );
  await request(
    "auth/reset-password",
    {
      token: resetToken,
      newPassword: "Another2026!",
      code: enabled.recoveryCodes[1],
    },
    400,
    "",
  );
  await request("state", undefined, 401, t);
  const ch = await json(
    "auth/login",
    { email: c.email, password: "ResetNew2026!" },
    200,
    "",
  );
  assert.equal(ch.requires2FA, true);
  const auth = await json(
    "auth/verify-2fa",
    { challenge: ch.challenge, code: enabled.recoveryCodes[1] },
    200,
    "",
  );
  assert.ok(auth.state);
});

test("Acesso gratuito: migra planos antigos sem alterar dados e remove APIs comerciais", async () => {
  const c = {
    name: "Acesso universal",
    email: "universal@example.test",
    password: "UniversalTest2026!",
  };
  const a = await json("auth/register", c, 200, "");
  const t = a.token;
  await request("chat", { message: "O que é orçamento?" }, 200, t);
  const before = await json("state", undefined, 200, t);
  await stop();
  const file = path.join(runtime, "data/database.json"),
    db = JSON.parse(await fs.readFile(file, "utf8")),
    u = db.users.find((u) => u.email === c.email);
  u.subscription = { status: "canceled", endsAt: "2000-01-01" };
  u.subscriptionEvents = [{ type: "canceled" }];
  u.upgradeRequest = { status: "pending" };
  u.state.notifications.push({
    id: "legacy-plan",
    type: "subscription",
    link: "premium",
    createdAt: new Date().toISOString(),
  });
  await fs.writeFile(file, JSON.stringify(db));
  await start();
  const after = await json("state", undefined, 200, t);
  assert.deepEqual(after.state, before.state);
  assert.equal(after.subscription, undefined);
  const account = await json("account", undefined, 200, t);
  assert.equal(account.subscription, undefined);
  assert.equal(account.billing, undefined);
  const persisted = JSON.parse(await fs.readFile(file, "utf8")).users.find(
    (u) => u.email === c.email,
  );
  for (const key of ["subscription", "subscriptionEvents", "upgradeRequest"])
    assert.equal(Object.hasOwn(persisted, key), false);
  await request("library", undefined, 200, t);
  await request("chat", { message: "Olá" }, 200, t);
  await request("library", undefined, 401, "");
  await request("chat", { message: "Olá" }, 401, "");
  await request("library/id-inexistente", undefined, 404, t);
  for (const path of ["subscription", "premium/library"])
    await request(path, undefined, 404, t);
  for (const path of [
    "subscription/request",
    "subscription/cancel-request",
    "subscription/cancel",
  ])
    await request(path, {}, 404, t);
  await stop();
  const op = spawn(
    process.execPath,
    ["scripts/admin-account.js", "grant-premium", "--email", c.email],
    { cwd: runtime, stdio: "ignore" },
  );
  assert.equal((await once(op, "exit"))[0], 1);
  await start();
});

test("Segurança: expiração ociosa de sessão e limitação de tentativas", async () => {
  const c = {
    name: "Limites",
    email: "limits@example.test",
    password: "LimitTest2026!",
  };
  const a = await json("auth/register", c, 200, "");
  await stop();
  const file = path.join(runtime, "data/database.json"),
    db = JSON.parse(await fs.readFile(file, "utf8")),
    u = db.users.find((u) => u.email === c.email);
  for (const s of db.sessions.filter((s) => s.userId === u.id))
    s.lastSeenAt = Date.now() - 31 * 60000;
  await fs.writeFile(file, JSON.stringify(db));
  await start();
  await request("state", undefined, 401, a.token);
  for (let i = 0; i < 12; i++)
    await request("auth/login", { email: c.email, password: "wrong" }, 401, "");
  await request("auth/login", c, 429, "");
});

test("Segurança: cadastro exige aceite versionado e contexto de conta impede troca de aba", async () => {
  const r = await fetch(base + "auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Sem aceite",
      email: "no-consent@example.test",
      password: "ConsentTest2026!",
    }),
  });
  assert.equal(r.status, 400);
  const a = await json(
    "auth/register",
    {
      name: "Contexto",
      email: "context@example.test",
      password: "ContextTest2026!",
    },
    200,
    "",
  );
  const changed = await fetch(base + "action", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Cookie: a.token.cookie,
      "X-CSRF-Token": a.token.csrf,
      "X-Account-Context": "other-account",
    },
    body: JSON.stringify({
      action: "profile.save",
      payload: { name: "Não salvar" },
    }),
  });
  assert.equal(changed.status, 401);
  assert.equal(
    (await json("state", undefined, 200, a.token)).state.profile.name,
    "Contexto",
  );
});

test("Segurança: sessão Bearer antiga migra uma única vez para cookie sem perder dados", async () => {
  const { digest } = await import("../lib/security-core.js");
  const c = {
    name: "Migração privada",
    email: "old-private@example.test",
    password: "MigrateTest2026!",
  };
  const a = await json("auth/register", c, 200, "");
  await stop();
  const file = path.join(runtime, "data/database.json"),
    db = JSON.parse(await fs.readFile(file, "utf8")),
    u = db.users.find((u) => u.email === c.email);
  db.sessions.push({
    hash: digest("old-private-token"),
    userId: u.id,
    expires: Date.now() + 3600000,
  });
  await fs.writeFile(file, JSON.stringify(db));
  await start();
  const migrated = await json("bootstrap", {}, 200, "old-private-token");
  assert.equal(migrated.authenticated, true);
  assert.equal(migrated.state.profile.name, c.name);
  assert.ok(migrated.token.cookie);
  await request("state", undefined, 401, "old-private-token");
  assert.equal(
    (await json("bootstrap", {}, 200, "old-private-token")).authenticated,
    false,
  );
  await request("state", undefined, 200, migrated.token);
  await request("state", undefined, 401, a.token);
});

test("Segurança: reset expirado, desafio 2FA com cinco erros, retenção de avisos", async () => {
  const { otp, digest } = await import("../lib/security-core.js");
  const c = {
    name: "Validades",
    email: "expirations@example.test",
    password: "ExpireTest2026!",
  };
  const a = await json("auth/register", c, 200, "");
  const setup = await json(
    "account/2fa/setup",
    { password: c.password },
    200,
    a.token,
  );
  const enabled = await json(
    "account/2fa/enable",
    { code: otp(setup.secret, Math.floor(Date.now() / 30000)) },
    200,
    a.token,
  );
  const ch = await json("auth/login", c, 200, "");
  for (let i = 0; i < 5; i++)
    await request(
      "auth/verify-2fa",
      { challenge: ch.challenge, code: "invalid" },
      401,
      "",
    );
  await request(
    "auth/verify-2fa",
    { challenge: ch.challenge, code: enabled.recoveryCodes[0] },
    401,
    "",
  );
  await stop();
  const file = path.join(runtime, "data/database.json"),
    db = JSON.parse(await fs.readFile(file, "utf8")),
    u = db.users.find((u) => u.email === c.email);
  u.passwordReset = {
    hash: digest("expired-token"),
    expires: Date.now() - 1,
    passwordHashAtIssue: digest(u.password),
  };
  u.state.notifications.push({
    id: "expired-notice",
    createdAt: "2000-01-01T00:00:00Z",
    type: "account",
  });
  await fs.writeFile(file, JSON.stringify(db));
  await start();
  await request(
    "auth/reset-password",
    {
      token: "expired-token",
      newPassword: "OtherPassword2026!",
      code: enabled.recoveryCodes[0],
    },
    400,
    "",
  );
  const state = await json("state", undefined, 200, a.token);
  assert.ok(!state.state.notifications.some((n) => n.id === "expired-notice"));
});

test("Auditoria: corpo ausente, arrays e payload inválido retornam 400 sem escrita", async () => {
  const credentials = {
    name: "Contrato HTTP",
    email: "http-contract@example.test",
    password: "ContractTest2026!",
  };
  const a = await json("auth/register", credentials, 200, "");
  const before = (await json("state", undefined, 200, a.token)).state;
  for (const body of [
    undefined,
    "[]",
    "null",
    "{",
    JSON.stringify("invalid"),
  ]) {
    const r = await fetch(base + "auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      ...(body === undefined ? {} : { body }),
    });
    assert.equal(r.status, 400, String(body));
    assert.equal(typeof (await r.json()).error, "string");
  }
  for (const payload of [null, [], "invalid", 42, true])
    await request(
      "action",
      { action: "transaction.save", payload },
      400,
      a.token,
    );
  const wrongType = await fetch(base + "auth/login", {
    method: "POST",
    headers: { "Content-Type": "text/plain" },
    body: "not JSON",
  });
  assert.equal(wrongType.status, 400);
  const tooLarge = await fetch(base + "auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: "x".repeat(210000) }),
  });
  assert.equal(tooLarge.status, 413);
  assert.deepEqual(
    (await json("state", undefined, 200, a.token)).state,
    before,
  );
});

test("Auditoria: configuração pública, documentos, aceite, cancelamento e seis relatórios HTTP", async () => {
  for (const route of ["access", "legal"]) {
    const r = await request(route, undefined, 200, "");
    assert.match(r.headers.get("content-type"), /application\/json/);
    assert.ok(Object.keys(await r.json()).length);
  }
  const a = await json(
    "auth/register",
    {
      name: "Matriz de endpoints",
      email: "matrix@example.test",
      password: "MatrixTest2026!",
    },
    200,
    "",
  );
  await request(
    "legal/accept",
    { version: "invalid", accept: true },
    400,
    a.token,
  );
  await request(
    "legal/accept",
    { version: LEGAL_VERSION, accept: true },
    200,
    a.token,
  );
  const before = (await json("state", undefined, 200, a.token)).state;
  for (const kind of [
    "completo",
    "despesas",
    "receitas",
    "orcamentos",
    "metas",
    "recorrencias",
  ]) {
    const r = await request("reports", { kind }, 200, a.token);
    const bytes = Buffer.from(await r.arrayBuffer());
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes);
    assert.ok(workbook.worksheets.length);
    if (kind === "completo") {
      const preview = await json("imports/preview", bytes, 200, a.token);
      await request(
        "imports/cancel",
        { previewId: preview.preview.previewId },
        200,
        a.token,
      );
      await request(
        "imports/commit",
        { previewId: preview.preview.previewId, confirm: true },
        409,
        a.token,
      );
    }
  }
  await request("reports", { kind: "nonexistent" }, 400, a.token);
  await request("imports/backup/nonexistent", undefined, 404, a.token);
  await request("imports/preview", Buffer.from("not an xlsx"), 400, a.token);
  await request("imports/undo", {}, 400, a.token);
  await request("library/nonexistent", undefined, 404, a.token);
  await request("unknown-endpoint", undefined, 404, a.token);
  const wrongMethod = await fetch(base + "reports", {
    method: "DELETE",
    headers: { Cookie: a.token.cookie, "X-CSRF-Token": a.token.csrf },
  });
  assert.equal(wrongMethod.status, 404);
  assert.deepEqual(
    (await json("state", undefined, 200, a.token)).state,
    before,
  );
});

test("Auditoria: endpoints privados recusam visitantes e não expõem arquivos do servidor", async () => {
  for (const route of [
    "state",
    "account",
    "privacy/export",
    "library",
    "library/not-found",
    "imports/backup/not-found",
  ])
    await request(route, undefined, 401, "");
  for (const route of [
    "logout",
    "action",
    "imports/preview",
    "imports/cancel",
    "imports/commit",
    "imports/undo",
    "reports",
    "chat",
    "legal/accept",
    "account/preferences",
    "account/password",
    "account/sessions/revoke",
    "account/2fa/setup",
    "account/2fa/enable",
    "account/2fa/disable",
    "account/2fa/recovery",
    "account/delete",
  ])
    await request(route, {}, 401, "");
  for (const name of [
    "data/database.json",
    "data/security-key",
    "data/import-signing-key",
    ".env",
    "server.js",
    "lib/account-security.js",
  ]) {
    const r = await fetch(new URL("../" + name, base));
    const text = await r.text();
    assert.ok(
      !text.includes('"users"') &&
        !text.includes("installAccountSecurity") &&
        !text.includes("SMTP_PASS="),
    );
  }
});

test("API: aportes concorrentes preservam todas as gravações", async () => {
  const account = await json(
    "auth/register",
    {
      name: "Concorrência sintética",
      email: "concurrency@example.test",
      password: "Concorrencia2026!",
    },
    200,
    "",
  );
  const t = account.token;
  const created = await json(
    "action",
    {
      action: "goal.save",
      payload: {
        name: "Meta concorrente",
        target: 1000,
        current: 0,
        date: "2027-12-31",
        color: "#2563eb",
        category: "Reserva",
      },
    },
    200,
    t,
  );
  const id = created.state.goals[0].id;
  await Promise.all(
    Array.from({ length: 12 }, () =>
      request(
        "action",
        { action: "goal.deposit", payload: { id, amount: 10 } },
        200,
        t,
      ),
    ),
  );
  assert.equal(
    (await json("state", undefined, 200, t)).state.goals[0].current,
    120,
  );
  await stop();
  await start();
  assert.equal(
    (await json("state", undefined, 200, t)).state.goals[0].current,
    120,
  );
});
