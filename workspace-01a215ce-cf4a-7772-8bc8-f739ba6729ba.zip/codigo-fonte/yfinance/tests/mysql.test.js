import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import mysql from "mysql2/promise";
import { randomBytes, randomUUID, createHash } from "node:crypto";
import { openMysqlStore, mysqlConfig } from "../lib/mysql-store.js";
import { publicTestState } from "../lib/public-test-data.js";
import { financialHash } from "../lib/excel-import.js";

test(
  "MySQL: tabelas relacionais, isolamento, rollback, hash estável e trava",
  { skip: process.env.TEST_MYSQL !== "1" },
  async () => {
    const name = "yfinance_test_" + randomBytes(8).toString("hex"),
      config = { ...mysqlConfig(), database: name };
    const admin = await mysql.createConnection({
      ...config,
      database: undefined,
    });
    let store,
      created = false;
    try {
      await admin.query(
        `CREATE DATABASE ${name} CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci`,
      );
      created = true;
      await admin.query(`USE ${name}`);
      const ddl = await fs.readFile(
        new URL("../database/schema.sql", import.meta.url),
        "utf8",
      );
      for (const stmt of ddl
        .split(";")
        .map((s) => s.trim())
        .filter(Boolean))
        await admin.query(stmt);
      store = await openMysqlStore({ config });
      const user = {
          id: randomUUID(),
          email: "sql@example.test",
          password: "$2b$synthetic-hash",
          state: publicTestState(),
        },
        db = { users: [user], sessions: [], loginChallenges: [] };
      user.state.transactions[0].description =
        "Texto literal: '); DROP TABLE users; --";
      await store.load();
      await store.save(db);
      assert.deepEqual(await store.load(), db);
      const [[row]] = await admin.execute(
        "SELECT COUNT(*) AS total, SUM(amount) AS amount FROM transactions WHERE user_id=?",
        [user.id],
      );
      assert.equal(row.total, 198);
      assert.ok(Number(row.amount) > 0);
      assert.equal(
        financialHash((await store.load()).users[0].state),
        financialHash(user.state),
      );
      await assert.rejects(openMysqlStore({ config }), /Já existe/);
      const duplicate = { ...structuredClone(user), id: randomUUID() };
      await assert.rejects(store.save({ ...db, users: [user, duplicate] }), {
        code: "ER_DUP_ENTRY",
      });
      assert.deepEqual(await store.load(), db);
      // Invalid ownership fails AFTER user update and child deletes: every change rolls back.
      const invalid = structuredClone(db);
      invalid.users[0].state.profile.name = "Must roll back";
      invalid.users[0].state.transactions[0].categoryId =
        "category-from-another-account";
      await assert.rejects(store.save(invalid), {
        code: "ER_NO_REFERENCED_ROW_2",
      });
      assert.deepEqual(await store.load(), db);
      await store.save({ users: [], sessions: [], loginChallenges: [] });
      const [[empty]] = await admin.query(
        "SELECT COUNT(*) AS total FROM transactions",
      );
      assert.equal(empty.total, 0);
      await store.close();
      store = null;
      const reopened = await openMysqlStore({ config });
      await reopened.close();
      // Version metadata alone must not hide a missing required table.
      await admin.query("DROP TABLE chat_messages");
      await assert.rejects(
        openMysqlStore({ config }),
        /incompleto.*chat_messages/,
      );
      // Failed startup must also release the MySQL advisory lock.
      // Recreate only the removed table in this disposable test schema and reopen.
      const statement = ddl
        .split(";")
        .find((s) => s.includes("CREATE TABLE IF NOT EXISTS chat_messages"));
      await admin.query(statement);
      const recovered = await openMysqlStore({ config });
      await recovered.close();
    } finally {
      if (store) await store.close();
      if (created) await admin.query(`DROP DATABASE ${name}`);
      await admin.end();
    }
  },
);


test("MySQL: encerramento após perda de conexão libera recursos e permite reabrir", { skip: process.env.TEST_MYSQL !== "1" }, async () => {
  const name = "yfinance_test_shutdown_" + randomBytes(8).toString("hex");
  const config = { ...mysqlConfig(), database: name };
  const admin = await mysql.createConnection({ ...config, database: undefined });
  let store, created = false;
  try {
    await admin.query(`CREATE DATABASE ${name} CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci`);
    created = true;
    await admin.query(`USE ${name}`);
    const ddl = await fs.readFile(new URL("../database/schema.sql", import.meta.url), "utf8");
    for (const sql of ddl.split(";").map(s => s.trim()).filter(Boolean)) await admin.query(sql);
    store = await openMysqlStore({ config });
    const lockName = "yfinance:" + createHash("sha256").update(name).digest("hex").slice(0, 48);
    const [[held]] = await admin.execute("SELECT IS_USED_LOCK(?) AS connection_id", [lockName]);
    assert.ok(Number.isInteger(held.connection_id) && held.connection_id > 0);
    // Kill only this test store's connection, never the MySQL server or another database.
    await admin.query(`KILL CONNECTION ${held.connection_id}`);
    await assert.rejects(store.load());
    await assert.doesNotReject(store.close());
    await assert.doesNotReject(store.close());
    store = await openMysqlStore({ config });
    assert.equal((await store.load()).users.length, 0);
  } finally {
    if (store) await store.close();
    if (created) await admin.query(`DROP DATABASE ${name}`);
    await admin.end();
  }
});
