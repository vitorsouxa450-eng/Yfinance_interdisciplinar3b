import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { parseEnv } from "node:util";
import { randomBytes } from "node:crypto";
import mysql from "mysql2/promise";
import { configureLocal, envValue, updateEnv } from "../lib/local-setup.js";
import { mysqlConfig } from "../lib/mysql-store.js";

test("Configuração por Prompt: senha é preservada no formato .env", () => {
  for (const value of ["Senha#ComEspaco !", "Aspa'2026\\teste", 'Aspa"2026#teste', "Ambas'\"2026\\n", "crase`2026"])
    assert.equal(parseEnv("PASSWORD=" + envValue(value)).PASSWORD, value);
  assert.throws(() => envValue("linha\nsegunda"));
  assert.throws(() => envValue("todas'\"`"));
});
test("Configuração por Prompt: mantém opções extras e remove chaves duplicadas", () => {
  const result = updateEnv('# instalação\nSMTP_HOST=privado.example\nDB_PORT=1\nDB_PORT=2\nPORT=3000\n', { DB_PORT: "3307", DB_PASSWORD: "Teste#2026!" });
  const parsed = parseEnv(result);
  assert.equal(parsed.SMTP_HOST, "privado.example");
  assert.equal(parsed.PORT, "3000");
  assert.equal(parsed.DB_PORT, "3307");
  assert.equal(parsed.DB_PASSWORD, "Teste#2026!");
  assert.equal((result.match(/^DB_PORT=/gm) || []).length, 1);
});
test("Configuração por Prompt: recusa root antes de acessar banco ou disco", async () => {
  await assert.rejects(configureLocal({ root: "/nao-usar", values: { DB_NAME: "yfinance", DB_USER: "root", DB_PASSWORD: "x", DB_HOST: "127.0.0.1" } }), /não use root/);
});
test("Configuração por Prompt: valida MySQL, respeita cancelamento e preserva dados", { skip: process.env.TEST_MYSQL !== "1" }, async () => {
  const database = "yfinance_test_setup_" + randomBytes(5).toString("hex");
  const config = { ...mysqlConfig(), database: undefined };
  const c = await mysql.createConnection(config);
  const root = await fs.mkdtemp(path.join(os.tmpdir(), "yf-configure-"));
  const file = path.join(root, ".env");
  const old = "SMTP_HOST=private.example\nPORT=3000\n";
  const values = { DB_HOST: "127.0.0.1", DB_PORT: String(config.port), DB_NAME: database, DB_USER: config.user, DB_PASSWORD: config.password };
  try {
    await c.query(`CREATE DATABASE \`${database}\``);
    await fs.writeFile(file, old);
    await assert.rejects(configureLocal({ root, values, confirm: async () => false }), /cancelada/);
    assert.equal(await fs.readFile(file, "utf8"), old);
    await configureLocal({ root, values, confirm: async () => true });
    const saved = await fs.readFile(file, "utf8");
    assert.equal(parseEnv(saved).DB_NAME, database);
    assert.equal(parseEnv(saved).DB_PASSWORD, config.password);
    assert.equal(parseEnv(saved).SMTP_HOST, "private.example");
    assert.equal(parseEnv(saved).LOCAL_SITE_PORT, "5173");
    await assert.rejects(configureLocal({ root, values: { ...values, DB_PASSWORD: "wrong-password-only" }, confirm: async () => true }));
    assert.equal(await fs.readFile(file, "utf8"), saved);
    await c.query(`CREATE TABLE \`${database}\`.unrelated_data (id INT PRIMARY KEY)`);
    await c.query(`INSERT INTO \`${database}\`.unrelated_data VALUES (42)`);
    await assert.rejects(configureLocal({ root, values, confirm: async () => true }), /incompleto|incompatível/);
    assert.equal(await fs.readFile(file, "utf8"), saved);
    const [[row]] = await c.query(`SELECT id FROM \`${database}\`.unrelated_data`);
    assert.equal(row.id, 42);
  } finally {
    await c.query(`DROP DATABASE IF EXISTS \`${database}\``);
    await c.end();
    await fs.rm(root, { recursive: true, force: true });
  }
});
