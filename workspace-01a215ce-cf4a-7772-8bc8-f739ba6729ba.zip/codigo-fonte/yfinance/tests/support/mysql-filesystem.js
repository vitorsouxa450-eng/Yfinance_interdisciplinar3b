// Test-only compatibility harness: the existing 68-case suite runs unchanged
// against real SQL. No fixture or failure injector is exposed by the API.
import mysql from "mysql2/promise";
import { openMysqlStore, mysqlConfig } from "../../lib/mysql-store.js";
const isDb = (p) => String(p).replaceAll("\\", "/").endsWith("/data/database.json");
const isFailure = (p) => String(p).replaceAll("\\", "/").endsWith("/data/database.json.tmp");
const canonical = (value) =>
  Array.isArray(value)
    ? value.map(canonical)
    : value && typeof value === "object"
      ? Object.fromEntries(
          Object.keys(value)
            .sort()
            .map((k) => [k, canonical(value[k])]),
        )
      : value;
export function mysqlTestFilesystem(fs) {
  async function readOnlyTables(on) {
    const c = await mysql.createConnection(mysqlConfig());
    try {
      for (const table of ["users", "sessions", "login_challenges"]) {
        if (on) {
          await c.query(`RENAME TABLE ${table} TO test_readonly_${table}`);
          // UNION views are non-updatable, while SELECT and foreign keys keep working.
          await c.query(
            `CREATE VIEW ${table} AS SELECT * FROM test_readonly_${table} UNION ALL SELECT * FROM test_readonly_${table} WHERE FALSE`,
          );
        } else {
          await c.query(`DROP VIEW ${table}`);
          await c.query(`RENAME TABLE test_readonly_${table} TO ${table}`);
        }
      }
    } finally {
      await c.end();
    }
  }
  return {
    ...fs,
    async readFile(file, encoding) {
      if (!isDb(file)) return fs.readFile(file, encoding);
      const store = await openMysqlStore({ lock: false });
      try {
        const text = JSON.stringify(canonical(await store.load()));
        return encoding ? text : Buffer.from(text);
      } finally {
        await store.close();
      }
    },
    async writeFile(file, data, options) {
      if (!isDb(file)) return fs.writeFile(file, data, options);
      const store = await openMysqlStore();
      try {
        await store.load();
        await store.save(JSON.parse(data.toString()));
      } finally {
        await store.close();
      }
    },
    async mkdir(file, ...args) {
      if (isFailure(file)) return readOnlyTables(true);
      return fs.mkdir(file, ...args);
    },
    async rmdir(file, ...args) {
      if (isFailure(file)) return readOnlyTables(false);
      return fs.rmdir(file, ...args);
    },
  };
}
