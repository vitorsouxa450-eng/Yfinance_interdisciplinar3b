import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { base32, otp, verifyOtp, seal, unseal } from "../lib/security-core.js";
test("TOTP: vetor RFC 6238 SHA1 e proteção contra replay", () => {
  const secret = base32(Buffer.from("12345678901234567890"));
  assert.equal(otp(secret, 1, 8), "94287082");
  assert.equal(verifyOtp(secret, "287082", -1, 59000), 1);
  assert.equal(verifyOtp(secret, "287082", 1, 59000), null);
  assert.equal(verifyOtp(secret, "000000", -1, 59000), null);
});
test("AES-GCM: segredo cifrado e alteração rejeitada", () => {
  const key = randomBytes(32),
    data = seal("confidencial", key);
  assert.equal(unseal(data, key), "confidencial");
  data.tag = "00".repeat(16);
  assert.throws(() => unseal(data, key));
});
test("Migração gratuita é idempotente e preserva dados e credenciais", async () => {
  const { removeLegacyPlans } = await import("../lib/access-migration.js");
  const u = {
    id: "example",
    password: "hash",
    twoFactor: { enabled: true },
    legal: { version: "old" },
    subscription: { status: "active" },
    subscriptionEvents: [],
    upgradeRequest: null,
    state: {
      transactions: [{ amount: 25 }],
      chat: [{ content: "histórico" }],
      notifications: [
        { id: "budget", type: "budget" },
        { id: "plan", type: "subscription" },
        { id: "release:2.0", type: "update" },
      ],
    },
  };
  const v = removeLegacyPlans(u);
  assert.equal(v.password, u.password);
  assert.equal(v.twoFactor, u.twoFactor);
  assert.equal(v.legal, u.legal);
  assert.equal(v.state.transactions, u.state.transactions);
  assert.equal(v.state.chat, u.state.chat);
  assert.equal(v.state.notifications.length, 2);
  assert.equal(v.subscription, undefined);
  assert.equal(removeLegacyPlans(v), v);
  assert.ok(u.subscription);
});
