import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes, createHash } from "node:crypto";
import mysql from "mysql2/promise";
import { localDatabaseConfig, prepareLocalDatabase } from "../lib/local-database.js";

const env = { DB_HOST: "127.0.0.1", DB_PORT: "3307", DB_USER: "root", DB_PASSWORD: "root", DB_NAME: "yfinance" };
test("Abertura sem demonstração: aceita conexão local informada sem usuário adicional", () => {
  const config = localDatabaseConfig(env);
  assert.equal(config.user, "root");
  assert.equal(config.database, "yfinance");
  assert.equal(config.port, 3307);
});
test("Abertura sem demonstração: exige valores reais e banco válido", () => {
  for (const key of Object.keys(env)) {
    const missing = { ...env }; delete missing[key];
    assert.throws(() => localDatabaseConfig(missing), new RegExp(key));
  }
  assert.throws(() => localDatabaseConfig({ ...env, DB_PORT: "PORTA_REAL_DO_MYSQL" }), /DB_PORT/);
  assert.throws(() => localDatabaseConfig({ ...env, DB_NAME: "db; DROP DATABASE x" }), /DB_NAME/);
  assert.throws(() => localDatabaseConfig({ ...env, DB_PORT: "65536" }), /DB_PORT/);
});
test("Abertura sem demonstração: não prepara MySQL remoto nem outro driver", () => {
  assert.throws(() => localDatabaseConfig({ ...env, DB_HOST: "example.test" }), /local/);
  assert.throws(() => localDatabaseConfig({ ...env, DB_DRIVER: "json-test" }), /mysql/);
});

test("Abertura sem demonstração MySQL: cria vazio, repete, bloqueia concorrência e preserva schema incompatível", { skip: process.env.TEST_MYSQL !== "1" }, async () => {
  // Only a freshly generated test schema is ever created or dropped here.
  const db = "yfinance_test_optional_" + randomBytes(8).toString("hex");
  const values = { ...process.env, DB_DRIVER: "mysql", DB_HOST: "127.0.0.1", DB_PORT: process.env.DB_PORT || "3306", DB_NAME: db };
  const config = localDatabaseConfig(values);
  const c = await mysql.createConnection({ ...config, database: undefined });
  const lock = "yfinance:" + createHash("sha256").update(db).digest("hex").slice(0, 48);
  try {
    assert.deepEqual(await prepareLocalDatabase(values), { created: true, schemaCreated: true });
    await c.query(`USE \`${db}\``);
    const [tables] = await c.query("SHOW TABLES");
    assert.equal(tables.length, 12);
    const [[users]] = await c.query("SELECT COUNT(*) AS n FROM users");
    const [[transactions]] = await c.query("SELECT COUNT(*) AS n FROM transactions");
    assert.equal(users.n, 0);
    assert.equal(transactions.n, 0);
    assert.deepEqual(await prepareLocalDatabase(values), { created: false, schemaCreated: false });
    await c.execute("SELECT GET_LOCK(?, 0)", [lock]);
    await assert.rejects(prepareLocalDatabase(values), /Pare a API/);
    await c.execute("SELECT RELEASE_LOCK(?)", [lock]);
    await assert.rejects(prepareLocalDatabase({ ...values, DB_PASSWORD: "invalid-test-" + randomBytes(12).toString("hex") }), /Não foi possível/);
    await c.query("CREATE TABLE incompatible_marker (id INT PRIMARY KEY, note VARCHAR(40))");
    await c.query("INSERT INTO incompatible_marker VALUES (1, 'preserve-test-marker')");
    await c.query("UPDATE schema_versions SET version=999");
    await assert.rejects(prepareLocalDatabase(values), /Não foi possível/);
    const [[marker]] = await c.query("SELECT note FROM incompatible_marker WHERE id=1");
    assert.equal(marker.note, "preserve-test-marker");
  } finally {
    await c.execute("SELECT RELEASE_LOCK(?)", [lock]);
    await c.query(`DROP DATABASE IF EXISTS \`${db}\``);
    await c.end();
  }
});
