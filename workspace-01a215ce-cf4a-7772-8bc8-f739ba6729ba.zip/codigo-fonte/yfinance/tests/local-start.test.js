import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import net from "node:net";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { fileURLToPath } from "node:url";
import { localPorts } from "../scripts/local-ports.js";
import { LEGAL_VERSION } from "../lib/legal-documents.js";
import { projectTopics } from "../lib/project-knowledge.js";

test("Localhost: assistente orienta os três comandos de abertura", () => {
  const help = projectTopics.find(topic => topic.id === "project-install").text;
  for (const command of ["npm run dev:api", "npm run dev:site", "npm run dev:landing"])
    assert.ok(help.includes(command));
  assert.match(help, /localhost:5173/);
  assert.match(help, /localhost:5175/);
});

const root = fileURLToPath(new URL("../", import.meta.url));
test("Localhost: portas padrão independem da porta MySQL e do modo integrado", () => {
  assert.deepEqual(localPorts({ DB_PORT: "3307", PORT: "3000" }), {
    LOCAL_API_PORT: 5174, LOCAL_SITE_PORT: 5173, LOCAL_LANDING_PORT: 5175,
  });
});
test("Localhost: recusa portas inválidas e repetidas", () => {
  for (const value of ["", "0", "65536", "abc", "5173.5"])
    assert.throws(() => localPorts({ LOCAL_API_PORT: value }), /inválida/);
  assert.throws(() => localPorts({ LOCAL_API_PORT: "5173" }), /diferentes/);
});
async function freePort() {
  const probe = net.createServer();
  await new Promise(resolve => probe.listen(0, "127.0.0.1", resolve));
  const port = probe.address().port;
  await new Promise(resolve => probe.close(resolve));
  return port;
}

test("Localhost: três servidores, sessão por proxy, CSRF e arquivos privados", { timeout: 60000 }, async () => {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), "yf-local-start-"));
  const runtime = path.join(temp, "yfinance");
  const children = [];
  try {
    await fs.mkdir(runtime);
    for (const name of ["server.js", "package.json", "index.html", "vite.local.config.js", "lib", "src", "public", "scripts"])
      await fs.cp(path.join(root, name), path.join(runtime, name), { recursive: true });
    await fs.mkdir(path.join(temp, "yfinance-landing"));
    await fs.writeFile(path.join(temp, "yfinance-landing/index.html"), "<h1>Landing de teste</h1>");
    await fs.symlink(path.join(root, "node_modules"), path.join(runtime, "node_modules"), "junction");
    const apiPort = await freePort(), sitePort = await freePort(), landingPort = await freePort();
    const env = {
      ...process.env, NODE_ENV: "test", DB_DRIVER: "json-test",
      LOCAL_API_PORT: String(apiPort), LOCAL_SITE_PORT: String(sitePort), LOCAL_LANDING_PORT: String(landingPort),
      COOKIE_SECURE: "false", APP_PUBLIC_URL: "", TRUST_PROXY_HOPS: "0",
      SMTP_HOST: "", AI_API_KEY: "",
    };
    await fs.writeFile(path.join(runtime, ".env"), "DB_PASSWORD=private-fixture-never-expose\n");
    async function start(args, ready) {
      const child = spawn(process.execPath, args, { cwd: runtime, env, stdio: ["ignore", "pipe", "pipe"] });
      children.push(child);
      await new Promise((resolve, reject) => {
        let logs = "";
        const timer = setTimeout(() => reject(Error("Inicialização: " + logs)), 25000);
        const output = chunk => {
          logs += chunk.toString();
          if (ready.test(logs)) { clearTimeout(timer); resolve(); }
        };
        child.stdout.on("data", output); child.stderr.on("data", output);
        child.once("error", e => { clearTimeout(timer); reject(e); });
        child.once("exit", code => { clearTimeout(timer); reject(Error(`Servidor encerrou (${code}): ${logs}`)); });
      });
    }
    await start(["scripts/start-local-api.js"], /Y Finance API ouvindo/);
    const vite = path.join(root, "node_modules/vite/bin/vite.js");
    await start([vite, "--config", "vite.local.config.js"], /Local:/);
    await start([vite, "--config", "vite.local.config.js", "--mode", "landing"], /Local:/);
    const base = `http://127.0.0.1:${sitePort}`;
    assert.equal((await (await fetch(`http://127.0.0.1:${apiPort}/`)).json()).service, "Y Finance API");
    assert.match(await (await fetch(base + "/metas")).text(), /src\/main.jsx/);
    assert.match(await (await fetch(`http://127.0.0.1:${landingPort}/`)).text(), /Landing de teste/);
    const register = await fetch(base + "/api/auth/register", {
      method: "POST", headers: { "Content-Type": "application/json", Origin: base },
      body: JSON.stringify({ name: "Teste local", email: "local@example.test", password: "LocalTeste@2026!", acceptLegal: true, legalVersion: LEGAL_VERSION }),
    });
    assert.equal(register.status, 200, await register.clone().text());
    const body = await register.json();
    const cookie = register.headers.get("set-cookie").split(";")[0];
    assert.match(register.headers.get("set-cookie"), /HttpOnly/);
    assert.ok(body.csrfToken);
    const state = await fetch(base + "/api/state", { headers: { Cookie: cookie } });
    assert.equal(state.status, 200);
    assert.equal((await state.json()).state.transactions.length, 0);
    const missingCsrf = await fetch(base + "/api/logout", { method: "POST", headers: { Cookie: cookie, Origin: base } });
    assert.equal(missingCsrf.status, 403);
    const badOrigin = await fetch(base + "/api/logout", {
      method: "POST", headers: { Cookie: cookie, Origin: "https://untrusted.example", "X-CSRF-Token": body.csrfToken },
    });
    assert.equal(badOrigin.status, 403);
    for (const resource of ["/.env", "/server.js", "/lib/database.js", "/data/security-key", "/scripts/start-local-api.js", "/vite.local.config.js"]) {
      const response = await fetch(base + resource);
      assert.ok([403, 404].includes(response.status), `${resource}: ${response.status}`);
      assert.doesNotMatch(await response.text(), /private-fixture-never-expose/);
    }
    const logout = await fetch(base + "/api/logout", {
      method: "POST", headers: { Cookie: cookie, Origin: base, "X-CSRF-Token": body.csrfToken, "Content-Type": "application/json" },
      body: "{}",
    });
    assert.equal(logout.status, 200);
    assert.equal((await fetch(base + "/api/state", { headers: { Cookie: cookie } })).status, 401);
  } finally {
    await Promise.all(children.map(async child => {
      if (child.exitCode !== null) return;
      const ended = once(child, "exit");
      child.kill("SIGTERM");
      const timer = setTimeout(() => child.kill("SIGKILL"), 6000);
      await ended;
      clearTimeout(timer);
    }));
    await fs.rm(temp, { recursive: true, force: true });
  }
});
