import test from "node:test";
import assert from "node:assert/strict";
import { dueDate, nextOccurrence, validDate } from "../src/schedule-model.js";
import {
  calendarEvents,
  calendarSummary,
  monthDays,
  shiftMonth,
} from "../src/calendar-model.js";
import { studyRecommendations } from "../src/study-model.js";
import { curriculum } from "../src/curriculum.js";
import { compound, installments, reserve } from "../src/simulation-model.js";
import { comparisonRows, formatScenario } from "../src/comparison-model.js";
import {
  ensureBudgetHistory,
  syncCurrentBudgets,
  budgetLimit,
  budgetRows,
} from "../src/budget-model.js";
import { processDue } from "../lib/automation.js";
import { localReply } from "../lib/local-assistant.js";
const state = () => ({
  categories: [
    { id: "c", name: "Casa", type: "expense", color: "#2563eb", budget: 100 },
  ],
  transactions: [],
  goals: [],
  recurring: [],
  learning: {},
  completed: [],
  chat: [],
});
const rule = (extra = {}) => ({
  id: "r",
  type: "expense",
  categoryId: "c",
  description: "Assinatura fictícia",
  amount: 10,
  frequency: "monthly",
  startDate: "2026-01-31",
  nextIndex: 0,
  status: "active",
  limit: null,
  endDate: "",
  ...extra,
});
test("Calendário compartilhado: meses curtos, bissexto e fim de regra", () => {
  assert.equal(dueDate(rule(), 1), "2026-02-28");
  assert.equal(
    dueDate(rule({ startDate: "2024-02-29", frequency: "yearly" }), 1),
    "2025-02-28",
  );
  assert.equal(nextOccurrence(rule({ nextIndex: 1, limit: 1 })), null);
  assert.equal(validDate("2026-02-30"), false);
});
test("Grade: segunda-feira primeiro, fevereiro bissexto e navegação anual", () => {
  assert.equal(monthDays("2024-02").days.length, 29);
  assert.equal(monthDays("2026-06").offset, 0);
  assert.equal(shiftMonth("2026-12", 1), "2027-01");
  assert.equal(shiftMonth("1900-01", -1), "1900-01");
  assert.throws(() => monthDays("2026-99"));
});
test("Agenda não duplica um registro e separa realizado de previsão", () => {
  const s = state();
  s.recurring = [rule({ nextIndex: 1 })];
  s.transactions = [
    {
      id: "t",
      recurringId: "r",
      date: "2026-01-31",
      description: "Registrado",
      amount: 10,
      type: "expense",
    },
  ];
  assert.equal(calendarEvents(s, "2026-01", "2026-01-31").length, 1);
  const feb = calendarEvents(s, "2026-02", "2026-01-31");
  assert.equal(feb[0].date, "2026-02-28");
  assert.equal(feb[0].status, "forecast");
  assert.equal(calendarSummary(feb).expense, 10);
  assert.equal(
    calendarSummary(calendarEvents(s, "2026-01", "2026-01-31")).expense,
    0,
  );
});
test("Agenda: regras pausadas/encerradas/fim/limite não geram previsão", () => {
  for (const extra of [
    { status: "paused" },
    { status: "ended" },
    { endDate: "2026-02-01" },
    { nextIndex: 1, limit: 1 },
  ]) {
    const s = state();
    s.recurring = [rule(extra)];
    assert.equal(calendarEvents(s, "2026-02").length, 0);
  }
});
test("Agenda: salto direto de regra diária antiga e nenhuma escrita", () => {
  const s = state();
  s.recurring = [rule({ startDate: "1900-01-01", frequency: "daily" })];
  const before = structuredClone(s);
  assert.equal(calendarEvents(s, "2099-12", "2026-01-01").length, 31);
  assert.deepEqual(s, before);
});
test("Agenda: metas atrasadas/concluídas não são somadas a despesas", () => {
  const s = state();
  s.goals = [
    { id: "g", date: "2026-02-10", name: "Reserva", current: 50, target: 100 },
    {
      id: "g2",
      date: "2026-02-11",
      name: "Completa",
      current: 100,
      target: 100,
    },
  ];
  const e = calendarEvents(s, "2026-02", "2026-02-15");
  assert.equal(e[0].status, "overdue");
  assert.equal(e[0].amount, 50);
  assert.equal(e[1].status, "completed");
  assert.deepEqual(calendarSummary(e), { income: 0, expense: 0, goals: 1 });
});
test("Agenda: mensal, semanal e anual respeitam as mesmas regras do servidor", () => {
  for (const frequency of ["daily", "weekly", "monthly", "yearly"]) {
    const s = state();
    s.recurring = [rule({ frequency, startDate: "2026-02-01", limit: 3 })];
    const events = calendarEvents(s, "2026-02", "2026-01-01");
    processDue(s, "2026-02-28");
    assert.deepEqual(
      events.map((e) => e.date),
      s.transactions.map((t) => t.date),
    );
  }
});
function quiz(id, wrong) {
  const answers = curriculum[id].quiz.map((q, i) =>
    i < wrong ? (q.answer + 1) % q.options.length : q.answer,
  );
  return {
    bestScore: 3,
    draft: [0, 0, 0],
    last: {
      answers,
      score: 3 - wrong,
      total: 3,
      attempt: 2,
      submittedAt: "2026-01-01",
    },
  };
}
test("Revisão usa última tentativa, não melhor nota nem rascunho", () => {
  const s = state();
  s.learning = { 0: { quiz: quiz(0, 1) }, 1: { quiz: quiz(1, 2) } };
  const before = structuredClone(s),
    r = studyRecommendations(s);
  assert.equal(r[0].id, 1);
  assert.equal(r[1].id, 0);
  assert.equal(r[0].mistakes.length, 2);
  assert.match(r[0].reason, /3\/3/);
  assert.deepEqual(s, before);
});
test("Revisão muda após tentativa correta e explica as respostas", () => {
  const s = state();
  s.learning = { 0: { quiz: quiz(0, 2) } };
  assert.ok(studyRecommendations(s)[0].mistakes[0].explanation);
  s.learning[0].quiz = quiz(0, 0);
  assert.equal(
    studyRecommendations(s).find((r) => r.id === 0).kind,
    "practice",
  );
});
test("Revisão: objetivo filtra, conta nova não inventa erros", () => {
  const s = state();
  const r = studyRecommendations(s, "reserve");
  assert.deepEqual(
    r.map((x) => x.id),
    [4, 8, 9],
  );
  assert.ok(r.every((x) => x.kind === "start" && x.mistakes.length === 0));
  assert.equal(studyRecommendations(s, "invalid").length, 17);
});
test("Juros: aporte no fim, taxa zero e conversão efetiva anual", () => {
  assert.equal(
    compound({ initial: 1000, monthly: 0, rate: 1, months: 2, unit: "month" })
      .total,
    1020.1,
  );
  assert.equal(
    compound({ initial: 0, monthly: 100, rate: 1, months: 2, unit: "month" })
      .total,
    201,
  );
  assert.equal(
    compound({ initial: 1000, monthly: 0, rate: 12, months: 12, unit: "year" })
      .total,
    1120,
  );
  assert.equal(
    compound({
      initial: 1000,
      monthly: 100,
      rate: 0,
      months: 12,
      unit: "month",
    }).total,
    2200,
  );
});
test("Parcelas: total, desconto e taxa implícita", () => {
  const r = installments({ cash: 1000, down: 0, payment: 1100, count: 1 });
  assert.ok(Math.abs(r.implied - 0.1) < 1e-10);
  assert.equal(r.total, 1100);
  assert.equal(
    installments({ cash: 1000, down: 0, payment: 90, count: 10 }).difference,
    -100,
  );
  assert.equal(
    installments({ cash: 100, down: 100, payment: 10, count: 1 }).implied,
    null,
  );
});
test("Reserva: prazo arredondado, aporte zero, objetivo alcançado", () => {
  assert.equal(
    reserve({ expenses: 1000, coverage: 6, current: 500, monthly: 200 }).months,
    28,
  );
  assert.equal(
    reserve({ expenses: 1000, coverage: 6, current: 500, monthly: 0 }).months,
    null,
  );
  assert.equal(
    reserve({ expenses: 1000, coverage: 6, current: 6000, monthly: 0 }).months,
    0,
  );
});
test("Simuladores recusam vazio, negativo, prazo fracionário e overflow", () => {
  const s = { initial: 1000, monthly: 10, rate: 1, months: 12, unit: "month" };
  for (const overrides of [
    { initial: -1 },
    { rate: "" },
    { months: 1.5 },
    { months: 600, rate: 100 },
  ])
    assert.throws(() => compound({ ...s, ...overrides }));
});
test("Comparação: diferença B menos A e nenhuma mutação", () => {
  const a = { invested: 1000, interest: 10, total: 1010 },
    b = { invested: 2000, interest: 20, total: 2020 };
  const before = structuredClone(a);
  assert.equal(comparisonRows("compound", a, b)[2].difference, 1010);
  assert.deepEqual(a, before);
});
test("Comparação: prazo indeterminado e taxa em pontos percentuais", () => {
  assert.equal(
    comparisonRows(
      "reserve",
      { target: 100, remaining: 50, months: null },
      { target: 100, remaining: 20, months: 2 },
    )[2].difference,
    null,
  );
  assert.ok(
    Math.abs(
      comparisonRows(
        "installments",
        { total: 100, difference: 0, implied: 0.01 },
        { total: 110, difference: 10, implied: 0.02 },
      )[2].difference - 0.01,
    ) < 1e-10,
  );
  assert.equal(formatScenario(null, "number"), "Não estimável");
});
test("Histórico: inicializa apenas o mês corrente, avança e preserva passado", () => {
  const s = state();
  ensureBudgetHistory(s, "2026-01");
  ensureBudgetHistory(s, "2026-03");
  s.categories[0].budget = 250;
  syncCurrentBudgets(s, "2026-03");
  assert.equal(budgetLimit(s, "c", "2026-01"), 100);
  assert.equal(budgetLimit(s, "c", "2026-02"), 100);
  assert.equal(budgetLimit(s, "c", "2026-03"), 250);
  assert.equal(budgetLimit(s, "c", "2025-12"), null);
  assert.throws(() => ensureBudgetHistory(s, "2026-02"));
});
test("Histórico conserva categoria arquivada e zero não é ausência", () => {
  const s = state();
  s.categories[0].budget = 0;
  ensureBudgetHistory(s, "2026-01");
  ensureBudgetHistory(s, "2026-02");
  s.categories = [];
  syncCurrentBudgets(s, "2026-02");
  assert.equal(budgetRows(s, "2026-01")[0].limit, 0);
  assert.equal(budgetRows(s, "2026-01")[0].name, "Casa");
});
test("Recorrência automática é idempotente e não paga contas", () => {
  const s = state();
  s.recurring = [rule()];
  assert.equal(processDue(s, "2026-02-28").created.length, 2);
  assert.equal(processDue(s, "2026-02-28").created.length, 0);
});
test("Assistente explica novidades sem chave nem alteração do estado", () => {
  const s = state(),
    before = structuredClone(s);
  for (const [q, pattern] of [
    ["Como usar o calendário?", /calendário/],
    ["Como funciona a revisão sugerida?", /revisão/],
    ["Como comparar cenários?", /cenários/],
  ])
    assert.match(localReply(q, s, "2026-02-01").insight.title, pattern);
  assert.deepEqual(s, before);
});
