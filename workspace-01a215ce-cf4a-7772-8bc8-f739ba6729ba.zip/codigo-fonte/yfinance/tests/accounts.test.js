import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { initialAccount } from "../lib/account-state.js";
import { publicTestState } from "../lib/public-test-data.js";
import { processDue } from "../lib/automation.js";
import { ensureBudgetHistory } from "../src/budget-model.js";
import { calendarEvents } from "../src/calendar-model.js";
import { acquireDatabaseLock } from "../lib/database-lock.js";
test("Cadastro: estado inicial sem dados financeiros, limites ou progresso fictícios", () => {
  const s = initialAccount("2026-10");
  for (const key of [
    "transactions",
    "goals",
    "recurring",
    "notifications",
    "chat",
    "completed",
    "challenges",
  ])
    assert.deepEqual(s[key], [], key);
  assert.deepEqual(s.learning, {});
  assert.ok(s.categories.length > 0);
  assert.ok(s.categories.every((c) => c.budget === 0));
  assert.deepEqual(Object.keys(s.budgetHistory), ["2026-10"]);
  assert.notEqual(initialAccount().categories[0].id, s.categories[0].id);
});
test("Conta pública: cenário janeiro–novembro com vínculos válidos e registros variados", () => {
  const s = publicTestState("2026-10-07");
  assert.equal(s.transactions.length, 198);
  assert.equal(new Set(s.transactions.map((t) => t.date.slice(0, 7))).size, 11);
  assert.ok(s.transactions.some((t) => t.date > "2026-10-07"));
  assert.ok(s.transactions.every((t) => t.notes.includes("fictício")));
  assert.equal(
    new Set(s.transactions.map((t) => t.id)).size,
    s.transactions.length,
  );
  for (const t of s.transactions) {
    assert.ok(
      s.categories.some((c) => c.id === t.categoryId && c.type === t.type),
    );
    assert.ok(t.amount > 0);
  }
  assert.ok(s.goals.length);
  assert.ok(Object.keys(s.learning).length);
  assert.equal(s.recurring.length, 2);
  assert.equal(
    calendarEvents(s, "2026-01").filter((e) => e.status === "recorded").length,
    2,
  );
});
test("Cenário sintético não cria histórico de orçamento futuro nem duplica recorrências", () => {
  for (const today of [
    "2026-01-01",
    "2026-10-07",
    "2026-11-24",
    "2027-02-01",
  ]) {
    const s = publicTestState(today),
      count = s.transactions.length;
    assert.ok(
      Object.keys(s.budgetHistory).every((m) => m <= today.slice(0, 7)),
    );
    assert.doesNotThrow(() => ensureBudgetHistory(s, today.slice(0, 7)));
    assert.equal(processDue(s, today).created.length, 0);
    assert.equal(s.transactions.length, count);
  }
});
test("Trava impede servidor e semeador concorrentes e pode ser liberada", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "yf-lock-"));
  try {
    const release = acquireDatabaseLock(root);
    assert.throws(() => acquireDatabaseLock(root), /Já existe/);
    release();
    const second = acquireDatabaseLock(root);
    second();
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});
