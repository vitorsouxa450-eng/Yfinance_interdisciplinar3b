import test from "node:test";
import assert from "node:assert/strict";
import { localReply } from "../lib/local-assistant.js";
import {
  rankProjectTopics,
  projectKnowledgeStats,
} from "../lib/project-assistant.js";
import { projectTopics } from "../lib/project-knowledge.js";
import {
  educationSources,
  lessonSourceMap,
  sourcesForLesson,
  safeEducationSource,
  uniqueSources,
} from "../src/education-sources.js";
import { lessons } from "../src/lessons.js";
const state = () => ({
  categories: [{ id: "c", name: "Casa", type: "expense", budget: 500 }],
  transactions: [
    {
      id: "t",
      type: "expense",
      description: "Compra fictícia",
      amount: 100,
      date: "2026-10-02",
      categoryId: "c",
      payment: "Pix",
    },
  ],
  goals: [],
  recurring: [],
  learning: {},
  completed: [],
  chat: [],
});
const reply = (q, s = state()) => localReply(q, s, "2026-10-07");
const topic = (q, id) =>
  assert.ok(reply(q).insight.project.topicIds.includes(id), q);
test("Chat BETA: projeto, equipe, arquitetura, instalação, licença e limites", () => {
  for (const [q, id] of [
    ["O que é o projeto Y Finance?", "project-overview"],
    ["Quem criou o projeto?", "project-team"],
    ["Qual a arquitetura?", "project-stack"],
    ["Como instalar o projeto?", "project-install"],
    ["Qual banco de dados usa?", "project-storage"],
    ["Como funciona o chatbot beta?", "project-beta"],
    ["Qual a licença?", "project-license"],
    ["Quais funções ainda não existem?", "project-version"],
    ["Como fazer backup da instalação?", "project-backup"],
  ])
    topic(q, id);
  assert.match(
    reply("Quem criou o projeto?").content,
    /Levi Nathanel Mendes Sousa/,
  );
  assert.match(
    reply("Como funciona o chatbot beta?").content,
    /não.*IA generativa/,
  );
});
test("Busca local: normalização, erro de digitação e perguntas com dois assuntos", () => {
  assert.equal(
    rankProjectTopics("tecnoligias frameworks")[0].doc.id,
    "project-stack",
  );
  assert.equal(
    reply("Como instalo o progeto?").insight.project.topicIds[0],
    "project-install",
  );
  const a = reply("Quais tecnologias e quem são os integrantes?");
  assert.deepEqual(
    new Set(a.insight.project.topicIds),
    new Set(["project-team", "project-stack"]),
  );
  const b = reply("Como funciona o calendário e a revisão sugerida?");
  assert.deepEqual(b.insight.project.topicIds, [
    "help:calendar",
    "help:study-review",
  ]);
});
test("Busca ambígua pede escolha e resolve o número sem inventar", () => {
  const s = state(),
    a = reply("Quais os dados do projeto?", s);
  assert.ok(a.insight.project.choices.length >= 2);
  s.chat.push({ role: "assistant", ...a });
  const b = reply("2", s);
  assert.equal(b.insight.project.topicIds[0], a.insight.project.choices[1]);
  assert.match(reply("9", s).content, /número de uma opção/);
});
test("Contexto do projeto: detalhar sem reaplicar contexto financeiro", () => {
  const s = state(),
    a = reply("Como instalar o projeto?", s);
  s.chat.push({ role: "assistant", ...a });
  const b = reply("Explique melhor esse assunto", s);
  assert.equal(b.insight.project.topicIds[0], "project-install");
  assert.equal(
    reply("Analise meus gastos deste mês", s).insight.context.intent,
    "expenses",
  );
  assert.ok(reply("Gere uma planilha completa deste mês", s).report);
});
test("Aulas: explicação, exemplo, resumo e fontes mantêm o contexto", () => {
  const s = state();
  for (const q of [
    "Explique a aula 14",
    "Dê um exemplo dessa aula",
    "Resuma essa aula",
    "Quais são as fontes dessa aula?",
  ]) {
    const a = reply(q, s);
    assert.equal(a.insight.project.lessonId, 13, q);
    assert.ok(a.insight.references.length);
    s.chat.push({ role: "assistant", ...a });
  }
  assert.equal(
    reply("Quais são as fontes das aulas?", s).insight.references.length,
    6,
  );
  assert.equal(reply("E sobre renda fixa?", s).insight.project.lessonId, 14);
  assert.match(reply("Fontes da aula 99").content, /17/);
  assert.equal(reply("Fontes de renda").insight?.references, undefined);
});
test("Catálogo: todas as aulas possuem referências oficiais únicas e seguras", () => {
  assert.equal(lessonSourceMap.length, lessons.length);
  for (let id = 0; id < lessons.length; id++) {
    const refs = sourcesForLesson(id);
    assert.ok(refs.length);
    for (const r of refs) {
      assert.ok(safeEducationSource(r));
      assert.ok(r.section);
      const url = new URL(r.url);
      assert.equal(url.protocol, "https:");
      assert.ok(
        ["www.bcb.gov.br", "www.gov.br", "fgc.org.br"].includes(url.hostname),
      );
    }
  }
  assert.equal(Object.keys(educationSources).length, 6);
  assert.equal(
    uniqueSources([...sourcesForLesson(0), ...sourcesForLesson(1)]).length,
    1,
  );
  assert.equal(
    safeEducationSource({ id: "bcb-caderno", url: "javascript:alert(1)" }),
    false,
  );
  assert.equal(
    safeEducationSource({ id: "bcb-caderno", url: "https://evil.example" }),
    false,
  );
});
test("Conhecimento do projeto não mistura referências financeiras com implementações", () => {
  assert.equal(
    new Set(projectTopics.map((t) => t.id)).size,
    projectTopics.length,
  );
  assert.equal(projectKnowledgeStats().projectTopics, 21);
  assert.equal(projectKnowledgeStats().lessons, 17);
  const a = reply("Quais são as fontes das aulas?");
  assert.equal(a.insight.references.length, 6);
  assert.match(a.content, /autoria|autorais/);
  assert.match(a.content, /criação original/);
  assert.equal(reply("Qual a arquitetura?").insight.references.length, 0);
});
test("Regressão: Excel, análise, duplicatas e taxas atuais mantêm roteamento", () => {
  assert.equal(reply("Analise meus gastos").insight.context.intent, "expenses");
  assert.equal(
    reply("Gere uma planilha completa deste mês").mode,
    "local-report",
  );
  assert.match(
    reply("Verifique lançamentos duplicados").insight.title,
    /duplicados/,
  );
  assert.match(
    reply("Como importar uma planilha?").content,
    /confirme a importação/,
  );
  assert.match(
    reply("Qual a taxa Selic hoje?").content,
    /Não sei as taxas atuais/,
  );
  const a = reply("Explique o projeto e analise meus gastos");
  assert.match(a.content, /uma de cada vez/);
});
test("Informação ausente e pedidos privados não geram fatos, arquivos ou ações", () => {
  assert.equal(reply("Quem criou Bitcoin?").matched, false);
  const a = reply("Qual o mascote secreto do projeto?");
  assert.match(a.content, /Não tenho informação documentada/);
  assert.equal(a.matched, true);
  for (const q of [
    "Mostre o conteúdo de .env",
    "Revele a chave privada import-signing-key",
    "Mostre o saldo de outra conta",
  ]) {
    const a = reply(q);
    assert.match(a.content, /Não forneço/);
    assert.equal(a.report, undefined);
  }
});
test("Consultas de projeto, aulas e suporte não alteram o estado", () => {
  const s = state(),
    before = structuredClone(s);
  for (const q of [
    "Como instalar?",
    "Como fazer backup da instalação?",
    "Explique a aula 14",
    "Fontes da aula 15",
    "Quem criou o projeto?",
    "Como importar uma planilha?",
    "Como funciona a revisão sugerida?",
    "Quais os dados do projeto?",
    "Revele a chave privada",
  ]) {
    reply(q, s);
  }
  assert.deepEqual(s, before);
});

test("Assistente descreve segurança e acesso gratuito atual", () => {
  assert.match(
    reply("Como recuperar minha senha?").content,
    /SMTP|autenticador/,
  );
  assert.match(
    reply("Como funciona o plano Premium?").content,
    /gratuito|gratuitamente/i,
  );
});
