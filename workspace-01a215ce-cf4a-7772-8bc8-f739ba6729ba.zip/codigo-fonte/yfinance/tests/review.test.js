import test from "node:test";
import assert from "node:assert/strict";
import { legalDocuments, LEGAL_VERSION } from "../lib/legal-documents.js";
import { supportTopics } from "../lib/assistant-support.js";
import { projectTopics } from "../lib/project-knowledge.js";
import { mysqlConfig } from "../lib/mysql-store.js";

// Regressions for inconsistencies found during the final technical review.
test("Revisão: política informa MySQL e versiona a correção de armazenamento", () => {
  const document = legalDocuments();
  assert.equal(document.version, LEGAL_VERSION);
  assert.notEqual(LEGAL_VERSION, "2.1-2026-10-07");
  const storage = document.privacy.find(
    (section) => section.title === "Armazenamento e proteção",
  ).text;
  assert.match(storage, /MySQL\/InnoDB/);
  assert.match(storage, /navegador não recebe credenciais/);
  assert.match(storage, /não configura criptografia integral/);
  assert.doesNotMatch(storage, /banco JSON fica|data\/database\.json/);
});

test("Revisão: identificação legal ausente não é apresentada como pronta para uso público", () => {
  const before = {
    PRIVACY_CONTROLLER: process.env.PRIVACY_CONTROLLER,
    PRIVACY_CONTACT: process.env.PRIVACY_CONTACT,
  };
  try {
    delete process.env.PRIVACY_CONTROLLER;
    delete process.env.PRIVACY_CONTACT;
    assert.equal(legalDocuments().readyForPublicUse, false);
    process.env.PRIVACY_CONTROLLER = "Operador fictício de teste";
    assert.equal(legalDocuments().readyForPublicUse, false);
    process.env.PRIVACY_CONTACT = "privacy@example.test";
    const document = legalDocuments();
    assert.equal(document.readyForPublicUse, true);
    assert.match(document.notice, /não representam certificação/);
  } finally {
    for (const [key, value] of Object.entries(before)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
});

test("Revisão: ajuda de privacidade e backup é coerente com a persistência MySQL", () => {
  const privacy = supportTopics.find((t) => t.id === "privacy").text;
  const backup = supportTopics.find((t) => t.id === "backup").text;
  assert.match(privacy, /MySQL/);
  assert.doesNotMatch(privacy, /data\/database\.json/);
  assert.match(backup, /dump MySQL/);
  assert.match(backup, /security-key/);
  assert.match(backup, /import-signing-key/);
  const storage = JSON.stringify(
    projectTopics.find((t) => t.id === "project-storage"),
  );
  assert.match(storage, /MySQL/);
  assert.match(storage, /12 tabelas/);
});

test("Revisão: configuração MySQL rejeita porta e nome de banco inválidos antes da conexão", () => {
  const config = {
    DB_USER: "synthetic",
    DB_PASSWORD: "test-only",
    DB_NAME: "yfinance_test",
  };
  assert.equal(mysqlConfig(config).port, 3306);
  assert.equal(mysqlConfig({ ...config, DB_PORT: "3307" }).port, 3307);
  for (const DB_PORT of ["abc", "0", "-1", "65536", "3306.5"])
    assert.throws(() => mysqlConfig({ ...config, DB_PORT }), /DB_PORT/);
  for (const DB_NAME of ["bad;drop", "x".repeat(65), "has space"])
    assert.throws(() => mysqlConfig({ ...config, DB_NAME }), /DB_NAME/);
  assert.throws(
    () => mysqlConfig({ ...config, DB_PASSWORD: undefined }),
    /Configure/,
  );
  assert.equal(mysqlConfig(config).multipleStatements, false);
});
