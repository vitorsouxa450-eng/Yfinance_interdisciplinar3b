import test from "node:test";
import assert from "node:assert/strict";
import { demoSettings } from "../scripts/create-demo.js";

const env = { DB_HOST: "127.0.0.1", DB_PORT: "3307", DB_NAME: "yfinance", DB_USER: "yfinance_app", DB_PASSWORD: "FicticiaSomente@Teste2026" };
test("Comando direto: exige autorização explícita e valores reais", () => {
  assert.throws(() => demoSettings(env, []), /--sim/);
  for (const key of Object.keys(env)) {
    const values = { ...env }; delete values[key];
    assert.throws(() => demoSettings(values, ["--sim"]), new RegExp(key));
  }
  assert.throws(() => demoSettings({ ...env, DB_PASSWORD: "SENHA_DO_PROJETO" }, ["--sim"]), /DB_PASSWORD/);
  for (const port of ["abc", "0", "65536", "3.5"])
    assert.throws(() => demoSettings({ ...env, DB_PORT: port }, ["--sim"]), /DB_PORT/);
});
test("Comando direto: credenciais administrativas completas e separadas", () => {
  assert.throws(() => demoSettings({ ...env, DB_ADMIN_USER: "admin" }, ["--sim"]), /juntos/);
  assert.throws(() => demoSettings({ ...env, DB_ADMIN_PASSWORD: "secreto" }, ["--sim"]), /juntos/);
  const result = demoSettings({ ...env, DB_ADMIN_USER: "admin", DB_ADMIN_PASSWORD: "secreto" }, ["--sim"]);
  assert.equal(result.admin.user, "admin");
  assert.equal(result.admin.password, "secreto");
  assert.ok(!Object.hasOwn(result.values, "DB_ADMIN_USER"));
  assert.ok(!Object.hasOwn(result.values, "DB_ADMIN_PASSWORD"));
});
test("Comando direto: reutiliza sem administrador e mantém portas independentes", () => {
  const result = demoSettings(env, ["--sim"]);
  assert.equal(result.admin, null);
  assert.equal(result.values.DB_PORT, "3307");
  assert.equal(result.values.LOCAL_API_PORT, "5174");
  assert.equal(result.values.LOCAL_SITE_PORT, "5173");
  assert.equal(result.values.LOCAL_LANDING_PORT, "5175");
  assert.equal(demoSettings({ ...env, LOCAL_API_PORT: "6184" }, ["--sim"]).values.LOCAL_API_PORT, "6184");
});
