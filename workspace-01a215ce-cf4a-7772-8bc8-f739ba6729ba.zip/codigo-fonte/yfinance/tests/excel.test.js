import { test, before } from "node:test";
import assert from "node:assert/strict";
import ExcelJS from "exceljs";
import { createReport } from "../lib/reports.js";
import { readImport, applyImport, financialHash } from "../lib/excel-import.js";
import {
  ensureBudgetHistory,
  syncCurrentBudgets,
  budgetLimit,
} from "../src/budget-model.js";
const security = { owner: "synthetic-test", key: "a".repeat(64) },
  today = "2026-02-10",
  s = {
    profile: { name: "Teste" },
    categories: [
      { id: "c", name: "Casa", type: "expense", budget: 100, color: "#2563eb" },
    ],
    transactions: [
      {
        id: "t",
        type: "expense",
        description: "Conta fictícia",
        date: "2026-02-02",
        amount: 20,
        payment: "Pix",
        notes: "",
        categoryId: "c",
      },
    ],
    recurring: [],
    goals: [],
    notifications: [],
    budgetAlerts: {},
  };
ensureBudgetHistory(s, "2026-01");
ensureBudgetHistory(s, "2026-02");
s.categories[0].budget = 200;
syncCurrentBudgets(s, "2026-02");
let bytes;
before(async () => {
  bytes = (
    await createReport(
      s,
      { kind: "completo", start: "2026-01-01", end: "2026-02-28" },
      today,
      security,
    )
  ).buffer;
});
const parse = (b, state = s, owner = security.owner) =>
  readImport(b, { ...security, owner, state, today });
async function edit(fn) {
  const w = new ExcelJS.Workbook();
  await w.xlsx.load(bytes);
  fn(w);
  return Buffer.from(await w.xlsx.writeBuffer());
}
test("Excel: limites diferentes por mês e ida/volta sem alteração", async () => {
  const w = new ExcelJS.Workbook();
  await w.xlsx.load(bytes);
  assert.equal(w.getWorksheet("Orçamentos").getCell("C6").value, 100);
  assert.equal(w.getWorksheet("Orçamentos").getCell("C7").value, 200);
  const p = await parse(bytes);
  assert.deepEqual(p.errors, []);
  assert.equal(p.counts.total, 0);
});
test("Excel: atualização atual não reescreve passado e entra no hash", async () => {
  const p = await parse(
    await edit((w) => (w.getWorksheet("Orçamentos").getCell("C7").value = 250)),
  );
  assert.deepEqual(p.errors, []);
  const next = applyImport(s, p, today);
  assert.equal(budgetLimit(next, "c", "2026-01"), 100);
  assert.equal(budgetLimit(next, "c", "2026-02"), 250);
  assert.notEqual(financialHash(next), financialHash(s));
});
test("Excel: mês passado e mês adulterado são recusados", async () => {
  for (const [address, value] of [
    ["C6", 105],
    ["A7", new Date("2020-01-01T00:00:00Z")],
  ]) {
    const p = await parse(
      await edit(
        (w) => (w.getWorksheet("Orçamentos").getCell(address).value = value),
      ),
    );
    assert.ok(p.errors.length > 0);
  }
});
test("Excel: arquivo de outra conta é bloqueado", async () => {
  await assert.rejects(
    () => parse(bytes, s, "other-owner"),
    (e) => e.status === 403,
  );
});
test("Excel: seis relatórios e ausência de histórico não inventam limites", async () => {
  for (const kind of [
    "completo",
    "receitas",
    "despesas",
    "orcamentos",
    "metas",
    "recorrencias",
  ]) {
    const b = (
      await createReport(
        s,
        { kind, start: "2025-12-01", end: "2026-02-28" },
        today,
        security,
      )
    ).buffer;
    const p = await parse(b);
    assert.deepEqual(p.errors, []);
    assert.equal(p.counts.total, 0);
  }
});
