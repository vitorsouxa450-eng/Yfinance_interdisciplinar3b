import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import bcrypt from "bcryptjs";
import { publicTestState } from "../lib/public-test-data.js";
import { publicTestAccount } from "../src/public-test-account.js";
import { openDatabase, loadEnvironment } from "../lib/database.js";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
loadEnvironment(root);
const store = await openDatabase(root);
try {
  const db = await store.load();
  const existing = db.users.find((u) => u.email === publicTestAccount.email);
  if (existing) {
    if (!existing.publicTest)
      throw Error(
        "O endereço reservado pertence a uma conta não pública. Nenhum dado foi alterado.",
      );
    console.log(
      "Conta pública já existe. Registros, senha e alterações dos visitantes foram preservados.",
    );
  } else {
    const user = {
      id: randomUUID(),
      email: publicTestAccount.email,
      password: await bcrypt.hash(publicTestAccount.password, 12),
      demo: false,
      publicTest: true,
      state: publicTestState(),
    };
    const next = { ...db, users: [...db.users, user] };
    await store.save(next);
    console.log(
      `Conta pública criada: ${user.state.transactions.length} lançamentos fictícios, janeiro–novembro de 2026. Contas existentes preservadas.`,
    );
  }
  console.log(
    `E-mail público: ${publicTestAccount.email}\nSenha pública: ${publicTestAccount.password}\nNão utilize esta conta para dados pessoais. Não há reset automático.`,
  );
} finally {
  await store.close();
}
