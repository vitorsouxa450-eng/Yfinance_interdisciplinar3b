import { fileURLToPath } from "node:url";
import { loadEnvironment } from "../lib/database.js";
import { prepareLocalDatabase } from "../lib/local-database.js";
import { localPorts } from "./local-ports.js";

loadEnvironment(fileURLToPath(new URL("../", import.meta.url)));
try {
  process.env.PORT = String(localPorts().LOCAL_API_PORT);
  if (!(process.env.NODE_ENV === "test" && process.env.DB_DRIVER === "json-test")) {
    const result = await prepareLocalDatabase();
    console.log(result.schemaCreated
      ? "Banco local pronto, sem contas ou lançamentos de demonstração. Use Criar conta no site."
      : "Banco local verificado. Contas e registros existentes preservados.");
  }
  process.argv.push("--api-only");
  await import("../server.js");
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
