import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { parseEnv } from "node:util";
import readline from "node:readline";
import { configureLocal, SetupError } from "../lib/local-setup.js";

const root = fileURLToPath(new URL("../", import.meta.url));
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: Boolean(process.stdin.isTTY && process.stdout.isTTY) });
let secret = false;
const write = rl._writeToOutput.bind(rl);
rl._writeToOutput = text => { if (!secret) write(text); };
const input = rl[Symbol.asyncIterator]();
rl.on("SIGINT", () => rl.close());
async function ask(label, fallback = "", hidden = false) {
  process.stdout.write(label + (fallback ? hidden ? " [Enter mantém a senha salva]" : ` [${fallback}]` : "") + ": ");
  secret = hidden;
  try {
    const line = await input.next();
    if (line.done) throw new SetupError("Configuração cancelada.");
    return (hidden ? line.value : line.value.trim()) || fallback;
  } finally {
    if (hidden && process.stdin.isTTY) process.stdout.write("\n");
    secret = false;
  }
}
async function confirm(label) {
  return /^(s|sim)$/i.test(await ask(label + " (s/N)"));
}
try {
  let saved = {};
  try { saved = parseEnv(await fs.readFile(new URL("../.env", import.meta.url), "utf8")); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
  console.log("Y Finance — configuração pelo Prompt\nPare as APIs antes de continuar. Nenhum banco será apagado.\nAs senhas não aparecem ao digitar e a senha administrativa não é salva.\n");
  console.log("1 — Usar banco e usuário já preparados\n2 — Preparar banco e usuário com acesso administrativo");
  const mode = await ask("Escolha", saved.DB_NAME ? "1" : "2");
  if (!["1", "2"].includes(mode)) throw new SetupError("Escolha 1 ou 2 e execute novamente.");
  const values = { DB_HOST: "127.0.0.1" };
  values.DB_PORT = await ask("Porta TCP real do MySQL", saved.DB_PORT || "");
  if (!/^\d+$/.test(values.DB_PORT)) throw new SetupError("Informe a porta real do MySQL; não deixe este campo vazio.");
  values.DB_NAME = await ask("Nome do banco", saved.DB_NAME || "yfinance");
  values.DB_USER = await ask("Usuário próprio do projeto (não root)", saved.DB_USER || "yfinance_app");
  values.DB_PASSWORD = await ask("Senha desse usuário (para criar: mínimo 12 caracteres)", saved.DB_USER === values.DB_USER ? saved.DB_PASSWORD || "" : "", true);
  values.LOCAL_API_PORT = await ask("Porta da API", saved.LOCAL_API_PORT || "5174");
  values.LOCAL_SITE_PORT = await ask("Porta do site principal", saved.LOCAL_SITE_PORT || "5173");
  values.LOCAL_LANDING_PORT = await ask("Porta da landing page", saved.LOCAL_LANDING_PORT || "5175");
  let admin = null;
  if (mode === "2") {
    admin = { user: await ask("Usuário administrativo do MySQL"), password: await ask("Senha administrativa do MySQL", "", true) };
    if (!admin.user) throw new SetupError("Informe o usuário administrativo da instalação.");
  }
  console.log(`\nDestino: 127.0.0.1:${values.DB_PORT} / ${values.DB_NAME}\nUsuário do projeto: ${values.DB_USER}`);
  if (!await confirm("Esses dados estão corretos?")) throw new SetupError("Configuração cancelada.");
  const result = await configureLocal({ root, values, admin, confirm });
  console.log(`\nConfiguração salva em .env. Senha administrativa não armazenada.\nBanco: ${result.database}; usuário: ${result.user}; MySQL: ${result.port}.\nAgora execute, com a API parada:\nnpm run db:setup\nnpm run seed:public\nDepois abra as três janelas do guia. Não compartilhe o .env.`);
} catch (error) {
  if (error instanceof SetupError) console.error(error.message);
  else {
    const messages = {
      ER_ACCESS_DENIED_ERROR: "Acesso negado. Confira o usuário e a senha do MySQL.",
      ER_DBACCESS_DENIED_ERROR: "O usuário não tem acesso a esse banco.",
      ER_BAD_DB_ERROR: "O banco não existe. Use a opção 2 para preparar uma instalação.",
      ECONNREFUSED: "Não foi possível conectar. Confira o serviço MySQL e a porta.",
      ER_SPECIFIC_ACCESS_DENIED_ERROR: "O acesso administrativo não tem as permissões necessárias.",
    };
    console.error(messages[error.code] || "Não foi possível concluir. Confira os dados, a versão/estrutura MySQL e as permissões; o .env anterior não foi substituído.");
  }
  console.error("Nenhum banco ou usuário foi apagado. Se a preparação foi interrompida, confira os recursos criados antes de tentar novamente.");
  process.exitCode = 1;
} finally { rl.close(); }
