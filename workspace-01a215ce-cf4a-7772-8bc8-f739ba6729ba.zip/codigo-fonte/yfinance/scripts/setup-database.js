import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import mysql from "mysql2/promise";
import { assertMysqlSchema } from "../lib/schema-validation.js";
import { mysqlConfig } from "../lib/mysql-store.js";
import { loadEnvironment } from "../lib/database.js";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
loadEnvironment(root);
const connection = await mysql.createConnection(mysqlConfig());
try {
  const [[v]] = await connection.query("SELECT VERSION() AS version");
  if (
    !/^8\./.test(v.version) ||
    /mariadb/i.test(v.version) ||
    /^8\.0\.(?:[0-9]|1[0-5])(?:\D|$)/.test(v.version)
  )
    throw Error("Use MySQL 8.0.16+ na série 8.x (recomendado: 8.4 LTS).");
  const [tables] = await connection.query("SHOW TABLES");
  if (tables.length) {
    await assertMysqlSchema(connection, process.env.DB_NAME);
    console.log(
      "Schema versão 1 já instalado. Nenhuma tabela ou dado substituído.",
    );
  } else {
    const sql = await fs.readFile(
      path.join(root, "database/schema.sql"),
      "utf8",
    );
    for (const statement of sql
      .split(";")
      .map((x) => x.trim())
      .filter(Boolean))
      await connection.query(statement);
    await assertMysqlSchema(connection, process.env.DB_NAME);
    console.log(
      "Schema MySQL criado. Execute npm run seed:public para criar a conta demonstrativa.",
    );
  }
} finally {
  await connection.end();
}
