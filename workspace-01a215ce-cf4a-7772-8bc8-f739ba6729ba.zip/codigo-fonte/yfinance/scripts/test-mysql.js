// Creates only a fresh randomly named test schema, never drops the application's DB.
import mysql from "mysql2/promise";
import fs from "node:fs/promises";
import { randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import { once } from "node:events";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadEnvironment } from "../lib/database.js";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
loadEnvironment(root);
if (!process.env.DB_TEST_USER || process.env.DB_TEST_PASSWORD === undefined)
  throw Error(
    "Configure DB_TEST_USER e DB_TEST_PASSWORD: usuário separado, com ALL em `yfinance_test_%`.*. Não use o usuário da aplicação.",
  );
const name = "yfinance_test_" + randomBytes(8).toString("hex");
const config = {
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_TEST_USER,
  password: process.env.DB_TEST_PASSWORD,
};
const c = await mysql.createConnection(config);
let created = false;
try {
  await c.query(
    `CREATE DATABASE ${name} CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci`,
  );
  created = true;
  await c.query(`USE ${name}`);
  const sql = await fs.readFile(path.join(root, "database/schema.sql"), "utf8");
  for (const statement of sql
    .split(";")
    .map((x) => x.trim())
    .filter(Boolean))
    await c.query(statement);
  const child = spawn(process.execPath, ["--test", "tests"], {
    cwd: root,
    stdio: "inherit",
    env: {
      ...process.env,
      TEST_MYSQL: "1",
      DB_DRIVER: "mysql",
      DB_NAME: name,
      DB_USER: config.user,
      DB_PASSWORD: config.password,
      NODE_ENV: "test",
    },
  });
  const [code] = await once(child, "exit");
  process.exitCode = code ?? 1;
} finally {
  if (created) await c.query(`DROP DATABASE ${name}`);
  await c.end();
}
