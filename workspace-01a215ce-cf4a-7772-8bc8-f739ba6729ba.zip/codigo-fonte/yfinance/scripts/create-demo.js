import path from "node:path";
import { fileURLToPath } from "node:url";
import { configureLocal, SetupError } from "../lib/local-setup.js";
import { prepareLocalDatabase } from "../lib/local-database.js";

export function demoSettings(env, args) {
  if (!args.includes("--sim")) throw new SetupError("Use --sim para autorizar a preparação sem perguntas. Nenhum dado existente será apagado.");
  for (const key of ["DB_HOST", "DB_PORT", "DB_NAME", "DB_USER", "DB_PASSWORD"])
    if (!env[key] || /^(PORTA_|USUARIO_|SENHA_|SUBSTITUA|CAMINHO_)/.test(env[key]))
      throw new SetupError(`Defina ${key} com o valor real usando set, conforme o guia.`);
  if (!/^\d+$/.test(env.DB_PORT) || Number(env.DB_PORT) < 1 || Number(env.DB_PORT) > 65535)
    throw new SetupError("DB_PORT deve ser a porta TCP real do MySQL.");
  const hasAdmin = Boolean(env.DB_ADMIN_USER);
  if (hasAdmin !== (env.DB_ADMIN_PASSWORD !== undefined))
    throw new SetupError("Para preparar banco/usuário, defina DB_ADMIN_USER e DB_ADMIN_PASSWORD juntos. Para apenas reutilizar, remova ambos.");
  if (hasAdmin && [env.DB_ADMIN_USER, env.DB_ADMIN_PASSWORD].some(v => /^(USUARIO_|SENHA_|SUBSTITUA)/.test(v)))
    throw new SetupError("Substitua os dados administrativos pelos valores reais.");
  return {
    values: {
      DB_DRIVER: "mysql", DB_HOST: env.DB_HOST, DB_PORT: env.DB_PORT,
      DB_NAME: env.DB_NAME, DB_USER: env.DB_USER, DB_PASSWORD: env.DB_PASSWORD,
      LOCAL_API_PORT: env.LOCAL_API_PORT || "5174",
      LOCAL_SITE_PORT: env.LOCAL_SITE_PORT || "5173",
      LOCAL_LANDING_PORT: env.LOCAL_LANDING_PORT || "5175",
    },
    admin: hasAdmin ? { user: env.DB_ADMIN_USER, password: env.DB_ADMIN_PASSWORD } : null,
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const settings = demoSettings(process.env, process.argv.slice(2));
    console.log("1/3 preparando acesso MySQL sem apagar dados");
    if (settings.admin) {
      // Retain the existing dedicated-user preparation as an optional tool.
      await configureLocal({
        root: fileURLToPath(new URL("../", import.meta.url)),
        ...settings,
        confirm: async () => true,
      });
    } else {
      // Same DB_* connection as the local API; no extra administrator variables.
      await prepareLocalDatabase(settings.values);
    }
    Object.assign(process.env, settings.values);
    delete process.env.DB_ADMIN_USER;
    delete process.env.DB_ADMIN_PASSWORD;
    console.log("2/3 criando ou verificando as tabelas");
    await import("./setup-database.js");
    console.log("3/3 preparando a conta de demonstração");
    await import("./create-public-account.js");
    console.log("Pronto. Abra as três janelas indicadas no guia do usuário. Nenhum banco foi apagado.");
  } catch (error) {
    console.error(error instanceof SetupError ? error.message : "Falha na preparação. Confira porta, credenciais, permissões e estrutura do MySQL. Pare a API antes de repetir. Não apague o banco.");
    console.error("A preparação pode ter criado recursos antes da falha; registros e senhas existentes não foram removidos nem redefinidos.");
    process.exitCode = 1;
  }
}
