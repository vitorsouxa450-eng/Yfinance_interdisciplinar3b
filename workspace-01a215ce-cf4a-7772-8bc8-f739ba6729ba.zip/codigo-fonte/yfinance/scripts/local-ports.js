// Local development only. Database ports and production PORT are independent.
export function localPorts(env = process.env) {
  const ports = {};
  for (const [name, fallback] of Object.entries({
    LOCAL_API_PORT: 5174,
    LOCAL_SITE_PORT: 5173,
    LOCAL_LANDING_PORT: 5175,
  })) {
    const value = String(env[name] ?? fallback).trim();
    if (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > 65535)
      throw new Error(`${name} inválida: informe uma porta entre 1 e 65535.`);
    ports[name] = Number(value);
  }
  if (new Set(Object.values(ports)).size !== 3)
    throw new Error("LOCAL_API_PORT, LOCAL_SITE_PORT e LOCAL_LANDING_PORT devem ser diferentes.");
  return ports;
}
