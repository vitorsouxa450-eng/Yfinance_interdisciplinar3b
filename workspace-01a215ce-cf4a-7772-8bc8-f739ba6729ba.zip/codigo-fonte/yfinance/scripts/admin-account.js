// Offline operator tool. Never serve this script or expose it as a public HTTP endpoint.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { openDatabase } from "../lib/database.js";
import { makeReset } from "../lib/security-core.js";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
if (fs.existsSync(path.join(root, ".env")))
  process.loadEnvFile(path.join(root, ".env"));
const store = await openDatabase(root);
try {
  const db = await store.load(),
    args = process.argv.slice(2),
    command = args[0];
  const get = (name) => {
    const i = args.indexOf("--" + name);
    return i >= 0 ? args[i + 1] : null;
  };
  if (command !== "issue-reset")
    throw Error(
      "Comando disponível: issue-reset --email ... [--base-url HTTPS]. Execute com o servidor parado.",
    );
  {
    const email = get("email")?.trim().toLowerCase(),
      u = db.users.find((u) => u.email === email && !u.demo);
    if (!u) throw Error("Conta não encontrada. Nenhum dado alterado.");
    if (u.publicTest)
      throw Error(
        "A conta pública de avaliação é protegida; não altere suas credenciais ou acesso pelo comando administrativo.",
      );
    let output;
    const reset = makeReset(u);
    u.passwordReset = reset.record;
    const base =
        get("base-url") ||
        process.env.APP_PUBLIC_URL ||
        "http://localhost:3000",
      url = new URL("/redefinir", base);
    if (
      url.protocol !== "https:" &&
      !["localhost", "127.0.0.1"].includes(url.hostname)
    )
      throw Error("Use uma URL HTTPS pública ou localhost para teste local.");
    url.hash = "token=" + reset.token;
    output =
      "LINK SENSÍVEL — não é um envio de e-mail. Entregue em canal seguro somente após verificar a identidade do titular. Expira em 30 minutos; 2FA permanece obrigatório.\n" +
      url.href;
    await store.save(db);
    console.log(output);
  }
} finally {
  await store.close();
}
