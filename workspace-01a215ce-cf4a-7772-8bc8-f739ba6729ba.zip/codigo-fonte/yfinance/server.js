import { removeLegacyPlans } from "./lib/access-migration.js";
import { installAccountSecurity } from "./lib/account-security.js";
import { securityKey, notification } from "./lib/security-core.js";
import { LEGAL_VERSION } from "./lib/legal-documents.js";
import { openDatabase, loadEnvironment } from "./lib/database.js";
import { installRequestGate } from "./lib/request-gate.js";
import {
  ensureBudgetHistory,
  syncCurrentBudgets,
  currentBudgetMonth,
} from "./src/budget-model.js";
import { Worker } from "node:worker_threads";
import {
  IMPORT_LIMITS,
  financialHash,
  applyImport,
} from "./lib/excel-import.js";
import { todayBR } from "./lib/automation.js";
import express from "express";
import { createServer as createHttpServer } from "node:http";
import {
  ensureAutomation,
  processDue,
  refreshBudgetAlerts,
  applyRecurringAction,
  nextOccurrence,
} from "./lib/automation.js";
import { createReport, normalizeReport } from "./lib/reports.js";
import { localReply } from "./lib/local-assistant.js";
import { curriculum, quizPassScore } from "./src/curriculum.js";
import fs from "node:fs";
import path from "node:path";
import { randomUUID, randomBytes, createHash, createHmac } from "node:crypto";
import { fileURLToPath } from "node:url";
const root = path.dirname(fileURLToPath(import.meta.url));
loadEnvironment(root);
const store = await openDatabase(root);
const key = securityKey(root);

const importKeyFile = path.join(root, "data", "import-signing-key");
if (!fs.existsSync(importKeyFile))
  fs.writeFileSync(importKeyFile, randomBytes(32).toString("hex"), {
    mode: 0o600,
    flag: "wx",
  });
const importKey = fs.readFileSync(importKeyFile, "utf8").trim();
if (!/^[a-f0-9]{64}$/.test(importKey))
  throw new Error(
    "Chave de importação inválida. Restaure data/import-signing-key a partir do seu backup.",
  );
let db = await store.load();
const persist = () => store.save(db);
// Apply references for an atomic SQL commit; roll memory back if the database rejects it.
async function commitChanges(changes) {
  for (const [object] of changes)
    if (
      object?.id &&
      object?.state &&
      !db.users.some((u) => u.id === object.id)
    )
      throw Object.assign(new Error("Conta encerrada."), { status: 401 });
  const previous = changes.map(([object, key]) => [
    object,
    key,
    Object.hasOwn(object, key),
    object[key],
  ]);
  for (const [object, key, value] of changes) object[key] = value;
  try {
    await persist();
  } catch (error) {
    for (const [object, key, existed, value] of previous.reverse()) {
      if (existed) object[key] = value;
      else delete object[key];
    }
    throw error;
  }
}
function maintainedState(user) {
  const state = structuredClone(user.state);
  const before = JSON.stringify(state.notifications || []);
  if (user.preferences?.productUpdates)
    notification(
      state,
      "update",
      "Novidades da versão 2.1",
      "Chatbot e biblioteca gratuitos para todas as contas. Os recursos de segurança e seus registros foram mantidos.",
      "configuracoes",
      "release:2.1",
    );
  state.notifications = (state.notifications || [])
    .filter((n) => Date.parse(n.createdAt) > Date.now() - 90 * 86400000)
    .slice(0, 200);
  const trimmed = before !== JSON.stringify(state.notifications);
  const history = ensureBudgetHistory(state);
  const due = processDue(state),
    alerts = refreshBudgetAlerts(state);
  return history || due.changed || alerts || trimmed ? state : null;
}
async function maintainUser(user) {
  const state = maintainedState(user);
  if (state) await commitChanges([[user, "state", state]]);
}
async function maintainAll() {
  const changes = [];
  for (const user of db.users) {
    const state = maintainedState(user);
    if (state) changes.push([user, "state", state]);
  }
  const sessions = db.sessions.filter(
    (s) =>
      s.expires > Date.now() &&
      (!s.cookieOnly ||
        (s.lastSeenAt || s.createdAt) > Date.now() - 30 * 60000),
  );
  if (sessions.length !== db.sessions.length)
    changes.push([db, "sessions", sessions]);
  const challenges = (db.loginChallenges || []).filter(
    (x) => x.expires > Date.now(),
  );
  if (challenges.length !== (db.loginChallenges || []).length)
    changes.push([db, "loginChallenges", challenges]);
  for (const u of db.users) {
    if (u.passwordReset?.expires < Date.now())
      changes.push([u, "passwordReset", null]);
    if (u.pending2FA?.expires < Date.now())
      changes.push([u, "pending2FA", null]);
  }
  if (changes.length) await commitChanges(changes);
}
const app = express();
const exclusive = installRequestGate(app, async () => {
  db = await store.load();
});
const httpServer = createHttpServer(app);
app.disable("x-powered-by");
if (process.env.TRUST_PROXY_HOPS)
  app.set(
    "trust proxy",
    Math.min(2, Math.max(0, Number(process.env.TRUST_PROXY_HOPS) || 0)),
  );
app.use(async (req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
  next();
});
app.use(async (req, res, next) => {
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; form-action 'self'" +
      (process.env.FRAME_ANCESTORS
        ? "; frame-ancestors " + process.env.FRAME_ANCESTORS
        : ""),
  );
  res.setHeader(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=()",
  );
  if (secureRequest(req))
    res.setHeader("Strict-Transport-Security", "max-age=31536000");
  if (!req.path.startsWith("/api/")) return next();
  const origin = req.get("origin"),
    allowed = [`http://${req.get("host")}`, `https://${req.get("host")}`];
  if (process.env.APP_PUBLIC_URL)
    try {
      allowed.push(new URL(process.env.APP_PUBLIC_URL).origin);
    } catch {}
  if (
    !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
    ((origin && !allowed.includes(origin)) ||
      req.get("sec-fetch-site") === "cross-site")
  )
    return res
      .status(403)
      .json({ error: "Origem da solicitação não permitida." });
  const sess = sessionFor(req);
  if (sess) {
    res.setHeader("X-Account-Id", sess.userId);
    if (
      req.get("x-account-context") &&
      req.get("x-account-context") !== sess.userId
    )
      return res.status(401).json({ error: "A conta mudou. Entre novamente." });
    res.setHeader("X-CSRF-Token", csrfFor(sess));
    if (
      req.method !== "GET" &&
      req.method !== "HEAD" &&
      req.path !== "/api/bootstrap" &&
      req.get("x-csrf-token") !== csrfFor(sess)
    )
      return res.status(403).json({
        error: "Verificação de segurança expirou. Recarregue a página.",
      });
    if (Date.now() - sess.lastSeenAt > 5 * 60000)
      await commitChanges([[sess, "lastSeenAt", Date.now()]]);
  }
  next();
});
app.use(express.json({ limit: "200kb" }));
app.use(async (req, res, next) => {
  if (
    req.path.startsWith("/api/") &&
    req.method === "POST" &&
    req.path !== "/api/imports/preview" &&
    (req.get("content-length") === "0" ||
      !req.body ||
      typeof req.body !== "object" ||
      Array.isArray(req.body))
  )
    return res
      .status(400)
      .json({ error: "Envie um objeto JSON válido no corpo da solicitação." });
  next();
});
const hash = (t) => createHash("sha256").update(t).digest("hex");
const dateNow = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(
    new Date(),
  );
const csrfFor = (s) =>
  createHmac("sha256", key)
    .update("csrf:" + s.hash)
    .digest("hex");
function cookieToken(req) {
  return req.headers.cookie?.match(
    /(?:^|;\s*)yf_session=([a-f0-9]{64})(?:;|$)/,
  )?.[1];
}
function sessionFor(req) {
  const t = cookieToken(req);
  if (!t) return null;
  const s = db.sessions.find(
    (s) =>
      s.cookieOnly &&
      s.hash === hash(t) &&
      s.expires > Date.now() &&
      (s.lastSeenAt || s.createdAt || 0) > Date.now() - 30 * 60000,
  );
  return s || null;
}
function secureRequest(req) {
  return (
    process.env.COOKIE_SECURE === "true" ||
    req.secure ||
    req.get("x-forwarded-proto") === "https"
  );
}
function setCookie(req, res, token, remove = false) {
  const secure = secureRequest(req);
  res.setHeader(
    "Set-Cookie",
    `yf_session=${token}; HttpOnly; Path=/; Max-Age=${remove ? 0 : 43200}; SameSite=${secure ? "None" : "Lax"}${secure ? "; Secure; Partitioned" : ""}`,
  );
}
function clearCookie(req, res) {
  setCookie(req, res, "", true);
}
async function session(user, req, res, isNew = false, replaceUser = false) {
  if (!isNew && !db.users.some((u) => u.id === user.id))
    throw fail("Conta encerrada.", 401);
  const token = randomBytes(32).toString("hex"),
    now = Date.now(),
    record = {
      id: randomUUID(),
      hash: hash(token),
      userId: user.id,
      createdAt: now,
      lastSeenAt: now,
      expires: now + 12 * 3600000,
      cookieOnly: true,
    };
  const others = db.sessions.filter(
      (s) => s.expires > now && s.userId !== user.id,
    ),
    own = replaceUser
      ? []
      : db.sessions
          .filter(
            (s) => s.expires > now && s.userId === user.id && s.cookieOnly,
          )
          .slice(-4);
  await commitChanges([
    [db, "sessions", [...others, ...own, record]],
    ...(isNew ? [[db, "users", [...db.users, user]]] : []),
    ...(replaceUser
      ? [[db, "users", db.users.map((u) => (u.id === user.id ? user : u))]]
      : []),
  ]);
  setCookie(req, res, token);
  res.setHeader("X-Account-Id", user.id);
  res.setHeader("X-CSRF-Token", csrfFor(record));
  return csrfFor(record);
}
function userFor(req, allowLegacy = false) {
  let s = sessionFor(req);
  if (!s && allowLegacy) {
    const t = req.headers.authorization?.replace(/^Bearer /, "");
    s =
      t &&
      db.sessions.find(
        (s) => !s.cookieOnly && s.hash === hash(t) && s.expires > Date.now(),
      );
  }
  return s && db.users.find((u) => u.id === s.userId);
}
async function output(u) {
  if (!db.users.some((x) => x.id === u.id)) throw fail("Conta encerrada.", 401);
  await maintainUser(u);
  const { _importReceipts, ...publicState } = u.state;
  return {
    importInfo: u.importBackup
      ? {
          id: u.importBackup.id,
          at: u.importBackup.at,
          counts: u.importBackup.counts,
          undone: u.importBackup.undone,
          canUndo: canUndoImport(u),
        }
      : null,
    state: {
      ...publicState,
      settings: {
        ...publicState.settings,
        reducedMotion: !!u.preferences?.reducedMotion,
      },
      learning: u.state.learning || {},
      recurring: u.state.recurring.map((r) => ({
        ...r,
        nextDue: r.status === "active" ? nextOccurrence(r) : null,
      })),
    },
    publicTest: u.publicTest === true,
    legalAccepted: u.legal?.version === LEGAL_VERSION,
    aiMode:
      !!(accounts.aiInfo().available && u.preferences?.externalAI) &&
      !u.publicTest,
  };
}
const fail = (message, status = 400) =>
  Object.assign(new Error(message), { status });
const text = (v, max = 120) => {
  if (typeof v !== "string" || !v.trim() || v.length > max)
    throw fail("Preencha os campos corretamente.");
  return v.trim();
};
const money = (v, zero = false) => {
  if (!["string", "number"].includes(typeof v))
    throw fail("Informe um valor numérico válido.");
  const n = Number(v);
  if (v === "" || !Number.isFinite(n) || n < (zero ? 0 : 0.01) || n > 1e12)
    throw fail("Informe um valor válido.");
  return Math.round(n * 100) / 100;
};
const date = (v) => {
  if (
    typeof v !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/.test(v) ||
    !Number.isFinite(Date.parse(v)) ||
    new Date(v).toISOString().slice(0, 10) !== v
  )
    throw fail("Data inválida.");
  return v;
};
const accounts = installAccountSecurity(app, {
  getDb: () => db,
  commit: commitChanges,
  issue: session,
  output,
  fail,
  text,
  key,
  userFor,
  sessionFor,
  clearCookie,
  purgeUser: (id) => {
    importPreviews.delete(id);
    importingUsers.delete(id);
  },
});
app.use("/api", async (req, res, next) => {
  req.user = userFor(req);
  if (!req.user || req.user.demo)
    return res
      .status(401)
      .json({ error: "Sua sessão expirou. Entre novamente." });
  await maintainUser(req.user);
  next();
});
app.post("/api/logout", async (req, res) => {
  const current = sessionFor(req);
  await commitChanges([
    [db, "sessions", db.sessions.filter((s) => s !== current)],
  ]);
  clearCookie(req, res);
  res.json({ ok: true });
});
app.get("/api/state", async (req, res) => res.json(await output(req.user)));
app.post("/api/action", async (req, res, next) => {
  try {
    const { action, payload: p = {} } = req.body;
    if (!p || typeof p !== "object" || Array.isArray(p))
      throw fail("Os dados da ação devem ser um objeto JSON válido.");
    const s = structuredClone(req.user.state);
    const find = (list, id) => {
      const v = list.find((x) => x.id === id);
      if (!v) throw fail("Registro não encontrado.", 404);
      return v;
    };
    if (action === "transaction.save") {
      const type = p.type;
      if (!["income", "expense"].includes(type)) throw fail("Tipo inválido.");
      const cat = find(s.categories, p.categoryId);
      if (cat.type !== type) throw fail("Categoria incompatível.");
      const original = p.id ? find(s.transactions, p.id) : null;
      const item = {
        ...(original?.recurringId
          ? {
              recurringId: original.recurringId,
              occurrenceKey: original.occurrenceKey,
              generatedAt: original.generatedAt,
            }
          : {}),
        id: original?.id || randomUUID(),
        type,
        description: text(p.description),
        amount: money(p.amount),
        date: date(p.date),
        categoryId: cat.id,
        payment: text(p.payment || "Pix", 40),
        notes: typeof p.notes === "string" ? p.notes.slice(0, 1000) : "",
      };
      s.transactions = s.transactions
        .filter((x) => x.id !== item.id)
        .concat(item);
    } else if (action === "transaction.delete") {
      find(s.transactions, p.id);
      s.transactions = s.transactions.filter((x) => x.id !== p.id);
    } else if (typeof action === "string" && action.startsWith("recurring.")) {
      applyRecurringAction(s, action, p, { fail, text, money });
      processDue(s);
    } else if (action === "notification.read") {
      ensureAutomation(s);
      const notification = find(s.notifications, p.id);
      notification.readAt ||= new Date().toISOString();
    } else if (action === "notification.archive") {
      const notification = find(s.notifications, p.id);
      notification.archivedAt = new Date().toISOString();
      notification.readAt ||= notification.archivedAt;
    } else if (action === "notification.readAll") {
      ensureAutomation(s);
      for (const n of s.notifications) n.readAt ||= new Date().toISOString();
    } else if (action === "goal.save") {
      const item = {
        id: p.id ? find(s.goals, p.id).id : randomUUID(),
        name: text(p.name),
        category: text(p.category, 60),
        target: money(p.target),
        current: money(p.current ?? 0, true),
        date: p.date ? date(p.date) : "",
        color: /^#[a-f0-9]{6}$/i.test(p.color) ? p.color : "#3b82f6",
      };
      s.goals = s.goals.filter((x) => x.id !== item.id).concat(item);
    } else if (action === "goal.deposit") {
      const g = find(s.goals, p.id);
      g.current = Math.round((g.current + money(p.amount)) * 100) / 100;
      if (g.current > 1e12) throw fail("Valor acima do limite.");
    } else if (action === "goal.delete") {
      find(s.goals, p.id);
      s.goals = s.goals.filter((x) => x.id !== p.id);
    } else if (action === "category.save") {
      if (!["income", "expense"].includes(p.type)) throw fail("Tipo inválido.");
      const name = text(p.name, 50);
      if (
        s.categories.some(
          (c) =>
            c.name.toLowerCase() === name.toLowerCase() &&
            c.type === p.type &&
            c.id !== p.id,
        )
      )
        throw fail("Essa categoria já existe.");
      const old = p.id ? find(s.categories, p.id) : null;
      if (
        old &&
        old.type !== p.type &&
        (s.transactions.some((t) => t.categoryId === p.id) ||
          (s.recurring || []).some((r) => r.categoryId === p.id))
      )
        throw fail("O tipo de uma categoria em uso não pode ser alterado.");
      const item = {
        id: old?.id || randomUUID(),
        name,
        type: p.type,
        budget: money(p.budget || 0, true),
        color: /^#[a-f0-9]{6}$/i.test(p.color) ? p.color : "#3b82f6",
      };
      s.categories = s.categories.filter((c) => c.id !== item.id).concat(item);
    } else if (action === "category.delete") {
      find(s.categories, p.id);
      if (
        s.transactions.some((t) => t.categoryId === p.id) ||
        (s.recurring || []).some((r) => r.categoryId === p.id)
      )
        throw fail(
          "Esta categoria tem lançamentos ou recorrências. Reclassifique os lançamentos; categorias vinculadas ao histórico de regras devem ser mantidas.",
        );
      s.categories = s.categories.filter((c) => c.id !== p.id);
    } else if (action === "budget.save") {
      if (p.month && p.month !== currentBudgetMonth())
        throw fail(
          "Somente o mês atual pode ser editado. Reabra os orçamentos para conferir o mês.",
          409,
        );
      const category = find(s.categories, p.id);
      if (category.type !== "expense")
        throw fail("Orçamentos se aplicam às categorias de despesa.");
      category.budget = money(p.budget, true);
    } else if (action === "profile.save") {
      s.profile.name = text(p.name, 80);
    } else if (action === "settings.save") {
      s.settings = {
        ...s.settings,
        dark: typeof p.dark === "boolean" ? p.dark : s.settings.dark,
        hide: typeof p.hide === "boolean" ? p.hide : s.settings.hide,
      };
    } else if (typeof action === "string" && action.startsWith("learning.")) {
      const id = Number(p.id);
      if (!Number.isInteger(id) || !curriculum[id])
        throw fail("Aula inválida.");
      s.learning ||= {};
      const progress = (s.learning[id] ||= {});
      const content = curriculum[id];
      const now = new Date().toISOString();
      if (action === "learning.visit") {
        progress.visitedAt = now;
      } else if (action === "learning.challenge.start") {
        progress.challenge ||= {
          steps: [],
          reflection: "",
          startedAt: now,
          completedAt: null,
        };
      } else if (action.startsWith("learning.challenge.")) {
        const c = progress.challenge;
        if (!c)
          throw fail("Comece o desafio antes de registrar seu progresso.");
        if (action === "learning.challenge.step") {
          if (
            !Number.isInteger(p.step) ||
            p.step < 0 ||
            p.step >= content.challenge.steps.length ||
            typeof p.done !== "boolean"
          )
            throw fail("Etapa inválida.");
          c.steps = p.done
            ? [...new Set([...c.steps, p.step])].sort()
            : c.steps.filter((step) => step !== p.step);
          if (!p.done) c.completedAt = null;
        } else if (
          action === "learning.challenge.note" ||
          action === "learning.challenge.complete"
        ) {
          if (typeof p.reflection !== "string" || p.reflection.length > 2000)
            throw fail("A reflexão deve ter até 2.000 caracteres.");
          const reflection = p.reflection.trim();
          if (action === "learning.challenge.complete") {
            if (c.steps.length !== content.challenge.steps.length)
              throw fail(
                "Realize e marque todas as etapas para concluir o desafio.",
              );
            if (reflection.length < 20)
              throw fail("Escreva uma reflexão com pelo menos 20 caracteres.");
            c.completedAt = now;
          }
          c.reflection = reflection;
          if (c.completedAt && reflection.length < 20) c.completedAt = null;
        } else if (action === "learning.challenge.reopen") {
          c.completedAt = null;
        } else throw fail("Ação de desafio inválida.");
        c.updatedAt = now;
      } else if (action.startsWith("learning.quiz.")) {
        const q = (progress.quiz ||= {
          draft: null,
          attempts: 0,
          bestScore: 0,
          last: null,
          history: [],
        });
        if (action === "learning.quiz.answer") {
          if (
            !Number.isInteger(p.question) ||
            !content.quiz[p.question] ||
            !Number.isInteger(p.answer) ||
            p.answer < 0 ||
            p.answer >= content.quiz[p.question].options.length
          )
            throw fail("Resposta inválida.");
          if (q.last && q.draft === null)
            throw fail("Inicie uma nova tentativa antes de alterar respostas.");
          q.draft ||= Array(content.quiz.length).fill(null);
          q.draft[p.question] = p.answer;
          q.updatedAt = now;
        } else if (action === "learning.quiz.retry") {
          q.draft = Array(content.quiz.length).fill(null);
          q.updatedAt = now;
        } else if (action === "learning.quiz.submit") {
          if (
            !q.draft ||
            q.draft.length !== content.quiz.length ||
            q.draft.some(
              (answer, index) =>
                !Number.isInteger(answer) ||
                answer < 0 ||
                answer >= content.quiz[index].options.length,
            )
          )
            throw fail("Responda todas as perguntas antes de corrigir o quiz.");
          const score = q.draft.reduce(
            (total, answer, index) =>
              total + Number(answer === content.quiz[index].answer),
            0,
          );
          q.attempts += 1;
          q.bestScore = Math.max(q.bestScore, score);
          q.last = {
            answers: [...q.draft],
            score,
            total: content.quiz.length,
            passed: score >= quizPassScore,
            submittedAt: now,
            attempt: q.attempts,
          };
          q.history = [...q.history, q.last].slice(-20);
          q.draft = null;
        } else throw fail("Ação de quiz inválida.");
      } else throw fail("Ação de aprendizagem inválida.");
    } else if (action === "lesson.toggle") {
      const id = Number(p.id);
      if (!Number.isInteger(id) || id < 0 || id > 16)
        throw fail("Aula inválida.");
      s.completed = s.completed.includes(id)
        ? s.completed.filter((x) => x !== id)
        : [...s.completed, id];
    } else if (action === "challenge.toggle") {
      const id = Number(p.id);
      if (![0, 1, 2].includes(id)) throw fail("Desafio inválido.");
      s.challenges = s.challenges.includes(id)
        ? s.challenges.filter((x) => x !== id)
        : [...s.challenges, id];
    } else if (action === "chat.clear") {
      s.chat = [];
      s.chatRevision = (s.chatRevision || 0) + 1;
    } else throw fail("Ação desconhecida.");
    syncCurrentBudgets(s);
    refreshBudgetAlerts(s);
    await commitChanges([[req.user, "state", s]]);
    res.json(await output(req.user));
  } catch (e) {
    next(e);
  }
});
const importPreviews = new Map();
const importingUsers = new Map();
function releaseImport(req) {
  if (importingUsers.get(req.user.id) === req)
    importingUsers.delete(req.user.id);
}
const backupFields = [
  "transactions",
  "categories",
  "goals",
  "recurring",
  "notifications",
  "budgetAlerts",
  "budgetHistory",
];
function backupData(state) {
  return Object.fromEntries(
    backupFields.map((name) => [
      name,
      structuredClone(
        state[name] ||
          (["budgetAlerts", "budgetHistory"].includes(name) ? {} : []),
      ),
    ]),
  );
}
function canUndoImport(user) {
  return (
    !!user.importBackup &&
    !user.importBackup.undone &&
    user.importBackup.day === todayBR() &&
    user.importBackup.afterHash === financialHash(user.state)
  );
}
async function saveImportAtomically(user, state, backup) {
  await commitChanges([
    [user, "state", state],
    [user, "importBackup", backup],
  ]);
}
function analyzeWorkbook(buffer, options) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(
      new URL("./lib/import-worker.js", import.meta.url),
      {
        workerData: { buffer, options },
        resourceLimits: { maxOldGenerationSizeMb: 256 },
        execArgv: [],
      },
    );
    let settled = false;
    const finish = (error, plan) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      worker.terminate();
      error ? reject(error) : resolve(plan);
    };
    const timer = setTimeout(
      () =>
        finish(
          fail(
            "A análise excedeu o tempo limite. Exporte um recorte menor.",
            400,
          ),
        ),
      IMPORT_LIMITS.milliseconds,
    );
    worker.once("message", (result) =>
      result.error
        ? finish(fail(result.error, result.status))
        : finish(null, result.plan),
    );
    worker.once("error", () =>
      finish(
        fail(
          "Não foi possível analisar o arquivo dentro dos limites de segurança. Exporte um recorte menor.",
          400,
        ),
      ),
    );
    worker.once("exit", () => {
      if (!settled)
        finish(
          fail("A análise foi interrompida. Tente um arquivo menor.", 400),
        );
    });
  });
}
const importCleanup = setInterval(() => {
  for (const [id, stage] of importPreviews)
    if (stage.expires < Date.now()) importPreviews.delete(id);
}, 60000);
importCleanup.unref();
app.post(
  "/api/imports/preview",
  (req, res, next) => {
    if (importingUsers.has(req.user.id) || importingUsers.size >= 2)
      return res.status(429).json({
        error:
          "Outra planilha está sendo analisada. Aguarde e tente novamente.",
      });
    importingUsers.set(req.user.id, req);
    importPreviews.delete(req.user.id);
    res.once("finish", () => {
      if (!req.importWorkerStarted) releaseImport(req);
    });
    res.once("close", () => {
      if (!req.importWorkerStarted) releaseImport(req);
    });
    next();
  },
  express.raw({ type: "application/octet-stream", limit: IMPORT_LIMITS.bytes }),
  async (req, res, next) => {
    try {
      if (!Buffer.isBuffer(req.body))
        throw fail("Envie o arquivo XLSX como conteúdo binário.");
      req.importWorkerStarted = true;
      const snapshot = structuredClone(req.user.state),
        beforeHash = financialHash(snapshot),
        day = todayBR();
      const plan = await analyzeWorkbook(req.body, {
        owner: req.user.id,
        key: importKey,
        state: snapshot,
        today: day,
      });
      if (res.destroyed) return;
      if (financialHash(req.user.state) !== beforeHash || day !== todayBR())
        throw fail(
          "Seus dados mudaram durante a análise. Envie a planilha novamente para revisar os dados atuais.",
          409,
        );
      const previewId = randomUUID(),
        expires = Date.now() + 15 * 60000;
      if (JSON.stringify(plan).length > 12 * 1024 * 1024)
        throw fail("A prévia ficou muito extensa. Exporte um recorte menor.");
      while (importPreviews.size >= 10)
        importPreviews.delete(importPreviews.keys().next().value);
      if (!userFor(req))
        throw fail("A sessão foi encerrada durante a análise.", 401);
      importPreviews.set(req.user.id, {
        previewId,
        expires,
        beforeHash,
        day,
        plan,
      });
      res.json({
        preview: {
          previewId,
          expiresAt: new Date(expires).toISOString(),
          ...plan,
          inputDigest: undefined,
        },
      });
    } catch (error) {
      next(error);
    } finally {
      releaseImport(req);
    }
  },
);
app.post("/api/imports/cancel", async (req, res) => {
  if (importPreviews.get(req.user.id)?.previewId === req.body.previewId)
    importPreviews.delete(req.user.id);
  res.json({ ok: true });
});
app.post("/api/imports/commit", async (req, res, next) => {
  try {
    if (req.body.confirm !== true)
      throw fail("Confirme expressamente a revisão antes de importar.");
    const stage = importPreviews.get(req.user.id);
    if (!stage && req.user.importBackup?.id === req.body.previewId)
      return res.json({
        ...(await output(req.user)),
        importMessage: req.user.importBackup.undone
          ? "Esta importação já foi desfeita."
          : "Esta importação já foi confirmada; nada foi duplicado.",
      });
    if (
      !stage ||
      stage.previewId !== req.body.previewId ||
      stage.expires < Date.now()
    )
      throw fail(
        "Prévia expirada, cancelada ou já utilizada. Analise a planilha novamente.",
        409,
      );
    if (
      stage.beforeHash !== financialHash(req.user.state) ||
      stage.day !== todayBR()
    ) {
      importPreviews.delete(req.user.id);
      throw fail(
        "Os dados mudaram após a prévia. Analise novamente antes de confirmar; nada foi importado.",
        409,
      );
    }
    const nextState = applyImport(req.user.state, stage.plan, stage.day);
    syncCurrentBudgets(nextState, stage.day.slice(0, 7));
    refreshBudgetAlerts(nextState);
    const backup = {
      id: stage.previewId,
      exportId: stage.plan.source.exportId,
      day: stage.day,
      at: new Date().toISOString(),
      counts: stage.plan.counts,
      before: backupData(req.user.state),
      afterHash: financialHash(nextState),
      undone: false,
    };
    await saveImportAtomically(req.user, nextState, backup);
    importPreviews.delete(req.user.id);
    res.json({
      ...(await output(req.user)),
      importMessage: `${stage.plan.counts.add} registro(s) acrescentado(s), ${stage.plan.counts.update} atualizado(s). Nenhuma exclusão. Backup anterior preservado.`,
    });
  } catch (error) {
    next(error);
  }
});
app.get("/api/imports/backup/:id", async (req, res, next) => {
  try {
    const backup = req.user.importBackup;
    if (!backup || backup.id !== req.params.id)
      throw fail("Backup não encontrado nesta conta.", 404);
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="YFinance-backup-antes-da-importacao.json"',
    );
    res.json({
      format: "YFINANCE_FINANCIAL_BACKUP_1",
      createdAt: backup.at,
      description:
        "Dados financeiros anteriores à última importação. Não contém senha, sessão, chat ou reflexões. Este JSON é uma cópia de segurança, não um arquivo aceito pelo importador XLSX.",
      data: backup.before,
    });
  } catch (error) {
    next(error);
  }
});
app.post("/api/imports/undo", async (req, res, next) => {
  try {
    const backup = req.user.importBackup;
    if (req.body.confirm !== true || !backup || backup.id !== req.body.backupId)
      throw fail("Revise e confirme a importação que deseja desfazer.");
    if (!canUndoImport(req.user))
      throw fail(
        "Não é possível desfazer: houve outra alteração financeira, mudou o dia ou a operação já foi desfeita. O backup continua disponível.",
        409,
      );
    const state = structuredClone(req.user.state);
    const read = new Map(
      (state.notifications || []).map((n) => [n.id, n.readAt]),
    );
    const events = state.notifications.filter((n) => n.type !== "budget");
    Object.assign(state, structuredClone(backup.before));
    state.notifications = [
      ...events,
      ...state.notifications.filter((n) => n.type === "budget"),
    ]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, 200);
    for (const n of state.notifications)
      if (read.get(n.id)) n.readAt = read.get(n.id);
    state._importReceipts[backup.exportId].status = "undone";
    await saveImportAtomically(req.user, state, { ...backup, undone: true });
    importPreviews.delete(req.user.id);
    res.json({
      ...(await output(req.user)),
      importMessage:
        "Importação desfeita. Dados financeiros anteriores restaurados; perfil, conversas e estudos preservados. Exporte uma nova planilha antes de importar outra vez.",
    });
  } catch (error) {
    next(error);
  }
});

const exportingUsers = new Set();
app.post("/api/reports", async (req, res, next) => {
  if (exportingUsers.has(req.user.id))
    return res.status(429).json({
      error:
        "Uma planilha já está sendo gerada para esta conta. Aguarde a conclusão.",
    });
  exportingUsers.add(req.user.id);
  try {
    const snapshot = structuredClone(req.user.state);
    const report = await createReport(snapshot, req.body, undefined, {
      owner: req.user.id,
      key: importKey,
    });
    if (!userFor(req)) throw fail("Sessão encerrada durante a geração.", 401);
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${report.filename}"`,
    );
    res.send(report.buffer);
  } catch (error) {
    next(error);
  } finally {
    exportingUsers.delete(req.user.id);
  }
});
const chattingUsers = new Set();
app.post("/api/chat", async (req, res, next) => {
  if (chattingUsers.has(req.user.id))
    return res.status(429).json({
      error:
        "Já estou respondendo a uma mensagem desta conta. Aguarde a conclusão.",
    });
  chattingUsers.add(req.user.id);
  try {
    const message = text(req.body.message, 2000);
    const revision = req.user.state.chatRevision || 0;
    const snapshot = structuredClone(req.user.state);
    let usedExternal = false;
    let reply = localReply(message, snapshot);
    if (reply.report) {
      try {
        reply.report = normalizeReport(reply.report, snapshot);
      } catch (error) {
        reply = {
          content: error.message,
          mode: "local-report",
          insight: {
            version: 1,
            title: "Ajuste o relatório",
            context: null,
            suggestions: ["Gere uma planilha completa deste mês"],
            metrics: [],
            note: "Nenhum arquivo foi gerado. Confira os filtros.",
          },
        };
      }
    }
    // All supported calculations and exports stay local, even if an optional key exists.
    // Only an unrecognized request can use the pre-existing, explicitly configured provider.
    if (
      !reply.matched &&
      reply.mode !== "local-report" &&
      accounts.aiInfo().available &&
      req.user.preferences?.externalAI &&
      !req.user.publicTest
    ) {
      try {
        usedExternal = true;
        const today = dateNow();
        const rows = snapshot.transactions.filter(
          (t) => t.date >= today.slice(0, 7) + "-01" && t.date <= today,
        );
        const totals = (type) =>
          rows
            .filter((t) => t.type === type)
            .reduce((n, t) => n + Math.round(t.amount * 100), 0) / 100;
        const response = await fetch(
          process.env.AI_API_URL ||
            "https://api.openai.com/v1/chat/completions",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${process.env.AI_API_KEY}`,
            },
            body: JSON.stringify({
              model: process.env.AI_MODEL || "gpt-4o-mini",
              messages: [
                {
                  role: "system",
                  content: `Você é um educador financeiro brasileiro. Não prometa retornos, não dê recomendações de ativos e não diga que alterou registros. Se não souber, explique a limitação. Dados agregados deste mês até ${today}: receitas ${totals("income")}, despesas ${totals("expense")}. Esse saldo não é bancário e a base pode estar incompleta. Responda em português. Metas atuais: ${JSON.stringify(snapshot.goals.map((g) => ({ nome: g.name, objetivo: g.target, acumulado: g.current })))}.`,
                },
                { role: "user", content: message },
              ],
              max_tokens: 600,
            }),
            signal: AbortSignal.timeout(25000),
          },
        );
        if (!response.ok) throw new Error("Serviço externo indisponível");
        const data = await response.json(),
          content = data.choices?.[0]?.message?.content;
        if (typeof content !== "string" || !content.trim())
          throw new Error("Resposta externa inválida");
        reply = {
          content: content.slice(0, 12000),
          mode: "ai",
          insight: {
            version: 1,
            title: "Orientação com IA conectada",
            context: null,
            metrics: [],
            suggestions: ["Analise meus gastos", "Como estão meus orçamentos?"],
            note: "Resposta do provedor configurado. Confira as informações importantes; não houve alteração nos seus registros.",
          },
        };
      } catch {
        reply = {
          ...reply,
          mode: "local-fallback",
          content:
            "O serviço externo não respondeu. Continuo disponível no modo local.\n\n" +
            reply.content,
        };
      }
    }
    if (!userFor(req))
      throw fail("A sessão mudou. A resposta foi descartada.", 403);
    if (usedExternal && !req.user.preferences?.externalAI)
      throw fail("Autorização revogada. Resposta externa descartada.", 409);
    if ((req.user.state.chatRevision || 0) !== revision)
      throw fail(
        "A conversa foi limpa durante a resposta. A resposta anterior foi descartada.",
        409,
      );
    const createdAt = new Date().toISOString();
    const nextState = structuredClone(req.user.state);
    nextState.chat.push(
      { id: randomUUID(), role: "user", content: message, createdAt },
      {
        id: randomUUID(),
        role: "assistant",
        content: reply.content,
        createdAt,
        mode: reply.mode || "local",
        ...(reply.insight ? { insight: reply.insight } : {}),
        ...(reply.report ? { report: reply.report } : {}),
      },
    );
    nextState.chat = nextState.chat.slice(-100);
    await commitChanges([[req.user, "state", nextState]]);
    res.json({ ...(await output(req.user)), mode: reply.mode || "local" });
  } catch (error) {
    next(error);
  } finally {
    chattingUsers.delete(req.user.id);
  }
});
app.use("/api", (req, res) =>
  res.status(404).json({ error: "Endpoint não encontrado." }),
);
app.use((err, req, res, next) => {
  console.error("Falha na API:", err.status || 500, err.code || "operation");
  res.status(err.status || 500).json({
    error:
      err.type === "entity.parse.failed"
        ? "JSON inválido."
        : err.type === "entity.too.large"
          ? "Envio acima do limite permitido."
          : err.status
            ? err.message
            : "Não foi possível salvar. Tente novamente.",
  });
});
if (process.argv.includes("--api-only")) {
  app.get("/", (req, res) =>
    res.json({ service: "Y Finance API", status: "ok" }),
  );
} else if (
  process.env.NODE_ENV === "production" ||
  process.argv.includes("--production")
) {
  app.get("/premium", async (req, res) => res.redirect(302, "/biblioteca"));
  app.use(express.static(path.join(root, "dist")));
  app.get("/{*path}", async (req, res) =>
    res.sendFile(path.join(root, "dist", "index.html")),
  );
} else {
  const { createServer } = await import("vite");
  const vite = await createServer({
    server: {
      middlewareMode: true,
      hmr: { server: httpServer },
      allowedHosts: true,
      fs: {
        deny: [
          "**/.env*",
          "**/data/**",
          "**/server.js",
          "**/lib/**",
          "**/scripts/**",
          "**/database/**",
          "**/lib/educational-library.js",
          "**/tests*.mjs",
          "**/tests/**",
        ],
      },
    },
    appType: "spa",
  });
  app.use(vite.middlewares);
}
// Idempotent cleanup: existing users, credentials and financial data are preserved.
const cleanedUsers = db.users.map(removeLegacyPlans);
if (cleanedUsers.some((u, i) => u !== db.users[i]))
  await commitChanges([[db, "users", cleanedUsers]]);

await maintainAll();
const automationTimer = setInterval(() => {
  exclusive(maintainAll).catch((error) => {
    console.error("Falha na verificação de recorrências:", error.message);
  });
}, 60000);
automationTimer.unref();
httpServer.listen(process.env.PORT || 3000, "0.0.0.0", () =>
  console.log(
    process.argv.includes("--api-only")
      ? "Y Finance API ouvindo em http://localhost:" + process.env.PORT
      : "Y Finance disponível na porta " + (process.env.PORT || 3000),
  ),
);

for (const signal of ["SIGTERM", "SIGINT"])
  process.once(signal, () => {
    clearInterval(automationTimer);
    httpServer.close(async () => {
      await store.close();
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  });
