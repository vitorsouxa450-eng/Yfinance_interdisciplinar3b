# Banco de dados

## Dados básicos

O Y Finance utiliza um banco relacional MySQL, com 12 tabelas e dados separados por conta.

- **Versão compatível:** MySQL 8.0.16 ou superior da série 8.x; recomendado 8.4 LTS.
- **Mecanismo das tabelas:** InnoDB.
- **Codificação:** `utf8mb4`.
- **Valores financeiros:** `DECIMAL(16,2)`, com duas casas decimais.
- **Datas dos lançamentos:** `DATE`.
- **Dados complementares:** campos `JSON`.
- **Definição das tabelas:** [database/schema.sql](../codigo-fonte/yfinance/database/schema.sql).

## Tabelas

| Tabela | Dados armazenados e finalidade |
| --- | --- |
| `schema_versions` | Versão da estrutura do banco (`version`) e data de aplicação (`applied_at`). |
| `users` | Contas: identificador, e-mail único, hash da senha, indicadores de conta demonstrativa/pública, preferências e informações complementares em `account_data` e `state_data`. |
| `categories` | Categorias de receitas ou despesas: nome, tipo (`kind`), cor e limite atual de orçamento (`budget`). |
| `transactions` | Receitas e despesas: descrição, tipo, valor (`amount`), categoria e data (`transaction_date`). Informações como pagamento e observações ficam em `details`. |
| `recurring_rules` | Regras de lançamentos recorrentes: descrição, tipo, valor e categoria. Frequência, datas e controle de geração ficam em `details`. |
| `goals` | Metas financeiras: nome, valor desejado (`target_amount`) e acumulado (`current_amount`). Prazo, cor e categoria descritiva ficam em `details`. |
| `notifications` | Avisos internos da conta, com conteúdo, leitura e controle de repetição em `details`. |
| `chat_messages` | Histórico de mensagens do usuário e do assistente, com conteúdo e identificação em `details`. |
| `learning_progress` | Progresso por aula: visitas, desafios, reflexões, respostas e resultados dos quizzes em `details`. O conteúdo das aulas permanece no código do site. |
| `budget_months` | Histórico mensal dos limites de orçamento. Cada registro identifica um mês no formato `YYYY-MM` e guarda os limites em `details`. |
| `sessions` | Sessões autenticadas: hash de identificação, usuário, expiração (`expires_at_ms`) e informações de atividade. |
| `login_challenges` | Desafios temporários de autenticação em dois fatores: hash, usuário, expiração e dados complementares. |

## Identificação e relacionamentos

- `users.id` identifica a conta. As tabelas de dados pessoais se vinculam a ela por `user_id`.
- Categorias, lançamentos, recorrências, metas, notificações, mensagens, progresso e orçamentos usam a chave composta `(user_id, id)`.
- Lançamentos e recorrências se relacionam à categoria pela chave `(user_id, category_id)`, mantendo o vínculo dentro da mesma conta.
- `sessions` e `login_challenges` usam `hash` como chave primária; `schema_versions` usa `version`.
- `position` preserva a ordem dos registros nas coleções. `details` reúne atributos complementares que não possuem coluna própria.
