# Testes de uso — Y Finance 2.1.0

Testes de uso executados em Linux, pela interface do site com automação em Chromium e, na seção de configuração, pelo terminal. Foi utilizado MySQL 8.4.9 isolado. Foram utilizadas contas fictícias em instalações de teste, sem alterar dados pessoais. A navegação em tela estreita foi simulada no navegador, não em um celular físico.

**Resultado: 55 testes de uso aprovados nos cenários abaixo.**

## Uso no modo integrado

Os cenários TU01–TU21 foram executados na revisão anterior, com interface e API no mesmo servidor.

| Teste | Ação realizada | Resultado esperado | Resultado observado | Status |
| --- | --- | --- | --- | --- |
| TU01 — Cadastro de conta | Preencher cadastro e aceitar os termos. | Abrir conta sem movimentações ou metas fictícias. | Conta criada; 0 lançamentos e 0 metas. | Aprovado |
| TU02 — Cadastrar receita | Registrar receita de R$ 100 com data e categoria. | Salvar e exibir a receita. | Receita de R$ 100 salva e presente na listagem. | Aprovado |
| TU03 — Cadastrar despesa e consultar saldo | Registrar despesa de R$ 10 e abrir o dashboard. | Saldo de R$ 90. | Despesa salva e saldo de R$ 90 exibido. | Aprovado |
| TU04 — Editar despesa | Alterar a despesa de R$ 10 para R$ 15. | Saldo atualizado para R$ 85. | Despesa alterada e saldo de R$ 85 exibido. | Aprovado |
| TU05 — Sair da conta | Usar Sair da conta em Configurações. | Encerrar a sessão e voltar ao acesso. | Formulário de login exibido após saída. | Aprovado |
| TU06 — Senha incorreta | Tentar entrar com senha incorreta. | Recusar o acesso. | Login recusado; a conta não foi aberta. | Aprovado |
| TU07 — Persistência após recarga e login | Recarregar a página, sair e entrar novamente. | Manter os lançamentos e o saldo de R$ 85. | Os dois lançamentos e a edição da despesa foram preservados. | Aprovado |
| TU08 — Meta e aporte | Criar meta de R$ 1.000 e registrar aporte de R$ 20. | Atualizar a meta sem descontar do saldo financeiro. | Meta com R$ 20 acumulados; saldo permaneceu R$ 85. | Aprovado |
| TU09 — Categorias | Criar, renomear e excluir uma categoria sem lançamentos. | Salvar cada alteração e permitir excluir a categoria livre. | Categoria criada, renomeada e removida. | Aprovado |
| TU10 — Categoria em uso | Tentar excluir a categoria da despesa cadastrada. | Recusar exclusão e preservar a categoria. | Exclusão recusada; categoria e lançamento mantidos. | Aprovado |
| TU11 — Exportar Excel | Baixar o relatório completo em Relatórios Excel. | Gerar um XLSX com os registros da conta. | Download concluído; arquivo XLSX aberto para conferência das planilhas. | Aprovado |
| TU12 — Prévia de importação | Alterar o valor da despesa para R$ 18 em uma cópia XLSX e usar Analisar sem salvar. | Mostrar a alteração sem gravar no banco. | Prévia exibida; a despesa permaneceu R$ 15 antes da confirmação. | Aprovado |
| TU13 — Confirmar importação | Autorizar e confirmar a prévia da despesa de R$ 18. | Atualizar o lançamento existente, sem duplicá-lo. | Despesa atualizada para R$ 18; mantidos os dois lançamentos da conta. | Aprovado |
| TU14 — Desfazer importação | Desfazer a última importação e confirmar, sem alteração financeira intermediária. | Restaurar o valor anterior. | Despesa voltou para R$ 15. | Aprovado |
| TU15 — Biblioteca gratuita | Pesquisar renda irregular e abrir o material encontrado. | Exibir a leitura sem cobrança ou ativação adicional. | Material e referências abertos na conta recém-criada. | Aprovado |
| TU16 — Assistente gratuito | Perguntar como organizar o orçamento. | Exibir resposta local sem cobrança nem alteração dos lançamentos. | Resposta exibida; receita e despesa permaneceram inalteradas. | Aprovado |
| TU17 — Leitura e quiz | Concluir a primeira leitura, enviar um quiz com dois acertos e recarregar. | Preservar a leitura e aprovar o quiz com dois de três acertos. | Leitura concluída e quiz aprovado com dois acertos, mantidos após recarga. | Aprovado |
| TU18 — Simulador de juros e aportes | Simular R$ 100 iniciais, R$ 10 mensais, 12 meses e juros zero. | Exibir R$ 220 sem alterar transações ou metas. | Resultado de R$ 220 exibido; transações e metas inalteradas. | Aprovado |
| TU19 — Recorrência sem duplicação | Criar despesa mensal de R$ 5 com início no dia do ambiente e recarregar duas vezes. | Gerar uma ocorrência vencida, sem duplicar nas recargas. | Um lançamento de R$ 5 foi gerado e permaneceu único. | Aprovado |
| TU20 — Orçamento por categoria | Definir limite de R$ 200 para Alimentação no mês atual e recarregar. | Manter o limite informado. | Limite de R$ 200 salvo e exibido após recarga. | Aprovado |
| TU21 — Navegação em tela estreita | Em janela de 390 × 844, abrir o menu e acessar Despesas. | Permitir navegar e consultar lançamentos sem rolagem horizontal da página. | Menu funcionou e Despesas exibiu os registros dentro da largura testada. | Aprovado |

## Abertura pelo localhost em três janelas

Nova execução com site em 5173, API em 5174 e landing page em 5175, usando Chromium/Linux e MySQL isolado. Os comandos de abertura passaram a ser `npm run dev:api`, `npm run dev:site` e `npm run dev:landing`; o roteiro do Prompt Windows não foi executado.

| Teste | Ação realizada | Resultado esperado | Resultado observado | Status |
| --- | --- | --- | --- | --- |
| TU22 — Cadastro de conta | Preencher cadastro e aceitar os termos. | Abrir conta sem movimentações ou metas fictícias. | Conta criada; 0 lançamentos e 0 metas. | Aprovado |
| TU23 — Cadastrar receita | Registrar receita de R$ 100 com data e categoria. | Salvar e exibir a receita. | Receita de R$ 100 salva e presente na listagem. | Aprovado |
| TU24 — Cadastrar despesa e consultar saldo | Registrar despesa de R$ 10 e abrir o dashboard. | Saldo de R$ 90. | Despesa salva e saldo de R$ 90 exibido. | Aprovado |
| TU25 — Editar despesa | Alterar a despesa de R$ 10 para R$ 15. | Saldo atualizado para R$ 85. | Despesa alterada e saldo de R$ 85 exibido. | Aprovado |
| TU26 — Sair da conta | Usar Sair da conta em Configurações. | Encerrar a sessão e voltar ao acesso. | Formulário de login exibido após saída. | Aprovado |
| TU27 — Senha incorreta | Entrar com senha incorreta pelo site em 5173. | Recusar o acesso. | Mensagem de credenciais inválidas exibida. | Aprovado |
| TU28 — Persistência após recarga e login | Entrar novamente e abrir o dashboard. | Preservar registros e saldo R$ 85. | Registros preservados e saldo exibido. | Aprovado |
| TU29 — Excel via proxy | Baixar relatório pelo site em 5173. | Baixar XLSX pela API separada. | Arquivo XLSX recebido sem erro. | Aprovado |
| TU30 — Rota direta | Abrir Educação e recarregar. | Manter acesso sem erro 404. | Tela de educação exibida após recarga. | Aprovado |
| TU31 — Landing page | Abrir localhost:5175 com os outros servidores ligados. | Exibir página independente. | Landing page carregada. | Aprovado |
| TU32 — API separada | Abrir localhost:5174. | Identificar o servidor da API. | Resposta de identificação recebida. | Aprovado |
| TU33 — Conta demonstrativa após reinício | Reabrir os três servidores e entrar com a conta pública, aceitando o compartilhamento. | Abrir a conta preenchida e preservar os registros já salvos. | Conta pública com 198 lançamentos; conta fictícia de teste manteve seus dois registros. | Aprovado |

## Configuração apenas pelo Prompt

Configurador verificado com entrada pelo terminal Linux, inclusive terminal interativo com senhas ocultas. As ações usaram banco e usuário fictícios separados; os comandos Windows de descoberta do serviço não foram executados.

| Teste | Ação realizada | Resultado esperado | Resultado observado | Status |
| --- | --- | --- | --- | --- |
| TU34 — Preparação automática | Usar a opção 2 do configurador com banco e usuário novos. | Preparar acesso e salvar a configuração sem editor de texto. | Banco e usuário criados; `.env` gerado; setup e seed concluídos. | Aprovado |
| TU35 — Senha oculta | Executar `npm run configurar` em terminal interativo e digitar uma senha com caracteres especiais. | Não exibir a senha e preservar seu valor. | Senha ausente da saída; conexão validada e valor salvo corretamente. | Aprovado |
| TU36 — Cancelar configuração | Responder não à confirmação do destino. | Manter a configuração anterior. | Operação cancelada e `.env` preservado. | Aprovado |
| TU37 — Reutilizar instalação | Configurar novamente banco e usuário existentes. | Preservar senha e registros. | Mantidos os 198 lançamentos e a senha do usuário MySQL. | Aprovado |
| TU38 — Senha incorreta | Informar senha incorreta para o usuário existente. | Recusar sem redefinir a senha ou sobrescrever a configuração. | Acesso recusado; senha, registros e `.env` preservados. | Aprovado |
| TU39 — API em uso | Tentar configurar enquanto a API usa o mesmo banco. | Solicitar que a API seja parada. | Configuração bloqueada e `.env` preservado. | Aprovado |
| TU40 — Abertura após configuração | Iniciar as três janelas após gerar a configuração, entrar na conta pública, recarregar e abrir a landing page. | Abrir o site e a landing page com os dados demonstrativos. | Login e recarga mantiveram 198 lançamentos; landing page abriu sem erros de JavaScript. | Aprovado |

## Preparação por comandos diretos, sem configurador interativo

TU41–TU44 foram executados na revisão anterior, com preparação de usuário próprio por `DB_ADMIN_*`, ainda disponível como ferramenta opcional. Verificação em Linux com variáveis de ambiente equivalentes às linhas `set` do guia, entrada padrão fechada e MySQL isolado. Os servidores foram iniciados com `node scripts/start-local-api.js` e os dois comandos `npx vite` do manual. O Prompt Windows não foi executado.

| Teste | Ação realizada | Resultado esperado | Resultado observado | Status |
| --- | --- | --- | --- | --- |
| TU41 — Autorização explícita | Executar a preparação sem `--sim`. | Recusar antes de preparar recursos. | Comando recusado, sem gerar `.env`. | Aprovado |
| TU42 — Preparação sem perguntas | Definir os valores de ambiente e executar `node scripts/create-demo.js --sim` sem entrada interativa. | Preparar acesso, tabelas e dados demonstrativos. | Banco, usuário, 12 tabelas e conta com 198 lançamentos preparados; senha administrativa ausente da configuração salva e da saída. | Aprovado |
| TU43 — Repetir preparação | Executar novamente o mesmo comando autorizado. | Preservar a instalação existente. | Mantidos os 198 lançamentos e a senha do usuário MySQL. | Aprovado |
| TU44 — Abrir com Node e Vite | Iniciar a API com Node e as interfaces com os comandos Vite; entrar, recarregar e abrir a landing page. | Acessar os endereços 5173 e 5175 com a API em 5174. | Login público com 198 lançamentos, recarga e landing page funcionando, sem erros de JavaScript. | Aprovado |

## Abertura sem demonstração e uso com cadastro novo

Cenários executados em MySQL isolado, com banco de teste inicialmente inexistente. A API recebeu a conexão MySQL local pelo ambiente, sem `.env`, sem configurador e sem executar seed antes do cadastro. Navegação em Chromium/Linux; o fluxo Windows não foi executado. A primeira rodada de navegação atingiu o limite de tempo do ambiente; a continuação foi concluída após reduzir o consumo de memória do servidor de desenvolvimento.

| Teste | Ação realizada | Resultado esperado | Resultado observado | Status |
| --- | --- | --- | --- | --- |
| TU45 — Abrir sem demonstração | Iniciar a API local apontando para um banco de teste inexistente, sem executar os passos 4 e 5. | Preparar estrutura vazia e aceitar acesso pelo site. | 12 tabelas criadas, zero contas e zero lançamentos; nenhum `.env` gravado. | Aprovado |
| TU46 — Cadastro sem seed | Na tela de acesso, clicar em Criar conta, preencher os campos e aceitar os termos. | Entrar com conta própria vazia. | Conta cadastrada e painel acessível com zero lançamentos e zero metas. | Aprovado |
| TU47 — Uso financeiro da conta nova | Cadastrar receita de R$ 100 e despesa de R$ 10 pela interface. | Salvar registros próprios e mostrar saldo de R$ 90. | Dois lançamentos persistidos e saldo conferido no painel. | Aprovado |
| TU48 — Recursos gratuitos sem demonstração | Abrir material da biblioteca e enviar pergunta ao assistente local. | Usar os recursos na conta recém-criada sem ativação adicional. | Material aberto e resposta local exibida e persistida. | Aprovado |
| TU49 — Continuar usando a conta | Recarregar, sair e entrar novamente com o cadastro criado. | Preservar os lançamentos. | Login normal e os dois lançamentos mantidos. | Aprovado |
| TU50 — Acrescentar demonstração depois | Parar a API, executar o comando de demonstração e iniciá-la novamente. | Acrescentar conta pública sem modificar a conta própria. | Conta própria, senha e dois lançamentos preservados; conta pública acessível com 198 lançamentos separados. | Aprovado |
| TU51 — Repetir demonstração opcional | Executar novamente o comando de demonstração com a API parada. | Não duplicar nem redefinir contas e registros. | Mesmas contas, senhas e 200 lançamentos totais, sendo 198 públicos e dois próprios. | Aprovado |
| TU52 — Evitar processos simultâneos | Com a API ativa, tentar executar demonstração e outra API para o mesmo banco. | Recusar as duas operações concorrentes. | Ambos os comandos recusados com orientação para parar a API. | Aprovado |

## Revalidação da versão atual

Após a simplificação do guia, foram repetidos pela interface os cenários de uso TU01–TU21, agora com API, site e landing page separados, em uma instalação nova sem demonstração. Foram conferidos cadastro, login, senha incorreta, receitas e despesas, metas, categorias, orçamento, recorrências, Excel (exportar, prévia, confirmar e desfazer), biblioteca, assistente local, leitura/quiz, simulador e tela de 390 × 844. Os resultados esperados foram mantidos, sem erros de JavaScript nos fluxos concluídos. A demonstração também foi executada duas vezes em outro banco isolado, mantendo 198 lançamentos, sem duplicação.

O reinício foi feito com os registros de teste já salvos. A segunda conta foi cadastrada pela interface. Para conferir o bloqueio de `.env`, foi criado somente na instalação temporária um arquivo com marcador fictício, removido após o teste; não foram utilizados segredos reais nessa requisição.

| Teste | Ação realizada | Resultado esperado | Resultado observado | Status |
| --- | --- | --- | --- | --- |
| TU53 — Reiniciar com dados salvos | Encerrar a API, iniciá-la novamente e abrir o painel da conta usada nos testes. | Preservar sessão e registros. | Sessão aceita e três lançamentos mantidos, incluindo a recorrência. | Aprovado |
| TU54 — Alternar contas próprias | Cadastrar uma segunda conta, consultar seus dados e entrar novamente na primeira. | Isolar os dados entre as contas. | Segunda conta sem lançamentos nem metas da primeira; primeira conta manteve seus três lançamentos. | Aprovado |
| TU55 — Acesso a arquivos privados | Solicitar pelo endereço do site arquivos existentes `.env`, `server.js`, `data/security-key` e `lib/database.js`. | Impedir o download do conteúdo privado. | As quatro requisições foram recusadas com HTTP 403; marcador de teste não foi exposto. | Aprovado |

**Limites:** execução em Linux/Chromium, não no Windows do usuário. A porta MySQL daquele computador ainda não foi informada. SMTP, recuperação por e-mail real e provedor externo de IA não foram validados com serviços externos configurados; o assistente local foi testado.
