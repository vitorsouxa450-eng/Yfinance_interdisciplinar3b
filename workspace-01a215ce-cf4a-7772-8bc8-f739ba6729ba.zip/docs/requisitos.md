# Requisitos — Y Finance 2.1.0

## Requisitos funcionais

| ID | Requisito |
| --- | --- |
| RF01 | Permitir cadastro com aceite dos termos, login e logout. Contas novas recebem categorias iniciais, sem lançamentos, metas ou progresso fictício. |
| RF02 | Permitir alteração de senha, autenticação em dois fatores por TOTP, códigos de recuperação e revogação de sessões. |
| RF03 | Permitir exportação dos dados pessoais e exclusão confirmada da própria conta. Oferecer recuperação de senha por e-mail quando SMTP e URL HTTPS estiverem configurados; informar indisponibilidade caso contrário. |
| RF04 | Permitir cadastrar, consultar, filtrar, editar, excluir e exportar receitas e despesas em CSV. Validar valores positivos, datas e categoria correspondente ao tipo do lançamento. |
| RF05 | Permitir criar e editar categorias de receitas e despesas, impedir duplicações e bloquear a exclusão de categorias em uso. |
| RF06 | Exibir no dashboard receitas, despesas e saldo do período selecionado, calculando saldo como receitas menos despesas. |
| RF07 | Permitir definir limites por categoria no mês atual e consultar os limites históricos, sem reescrever os meses anteriores. |
| RF08 | Permitir criar, editar e excluir metas, informar valor desejado, acumulado, prazo opcional e aportes. Aportes em metas não alteram o saldo dos lançamentos. |
| RF09 | Permitir criar, editar, pausar, retomar e encerrar recorrências. Gerar lançamentos vencidos sem duplicar a mesma ocorrência e sem realizar pagamentos. |
| RF10 | Exibir no calendário lançamentos, previsões de recorrências e prazos de metas. |
| RF11 | Exibir notificações internas de orçamento, conta e segurança, permitindo leitura e arquivamento. |
| RF12 | Disponibilizar 17 aulas, trilhas, desafios, reflexões, quizzes, fontes e revisão sugerida. Registrar leitura, desafio e quiz separadamente; cada quiz tem três questões, exige dois acertos para aprovação e preserva a melhor nota. |
| RF13 | Simular juros e aportes, compras à vista ou parceladas e reserva financeira, com comparação local entre cenários A/B, sem alterar lançamentos ou metas. |
| RF14 | Disponibilizar biblioteca gratuita para contas autenticadas, com pesquisa, filtro por assunto, materiais e referências. |
| RF15 | Disponibilizar assistente BETA gratuito para contas autenticadas, com respostas locais sobre finanças, aulas e projeto, contexto da conta e histórico. O assistente não altera registros financeiros nem consulta cotações em tempo real. |
| RF16 | Exportar seis tipos de relatório Excel: completo, receitas, despesas, orçamentos, metas e recorrências. Importar planilhas compatíveis da mesma conta e instalação, exigindo prévia e confirmação. Preservar os registros ausentes da planilha e os dados financeiros anteriores à importação; permitir desfazer a última importação no mesmo dia, desde que o estado continue compatível. |
| RF17 | Permitir editar perfil e preferências de tema, ocultação de valores, redução de movimento e avisos. |
| RF18 | Disponibilizar uma landing page independente, com informações sobre o site e exemplos demonstrativos. |

## Requisitos não funcionais

| ID | Requisito |
| --- | --- |
| RNF01 | Proteger senhas por hash e restringir os dados à conta autenticada. Exigir sessão válida, proteção CSRF e origem autorizada nas operações de alteração. |
| RNF02 | Manter integridade dos vínculos e valores no MySQL. Confirmar salvamento somente após a conclusão da transação; em caso de falha, não informar sucesso. |
| RNF03 | Serializar operações para evitar perda de alterações concorrentes e limitar a execução a uma instância da API por banco. |
| RNF04 | Preservar dados e sessões ainda válidas após reinício. Permitir recuperação por backup do banco acompanhado das chaves e configurações correspondentes. |
| RNF05 | Oferecer interface responsiva, controles identificados e navegação por teclado, sem pressupor certificação de acessibilidade. |
| RNF06 | Permitir instalação reproduzível com dependências fixadas e estrutura SQL definida. Manter testes de alteração e exclusão separados dos dados pessoais. |
| RNF07 | Manter credenciais do banco e chaves privadas fora do navegador e da entrega pública. Informar o tratamento dos dados e as limitações dos recursos. |
| RNF08 | Organizar o código em módulos identificáveis, manter regras testáveis e documentação coerente com a versão do site. |
| RNF09 | Informar falhas de persistência sem trocar silenciosamente o MySQL por outro armazenamento. A versão atual não estabelece garantia de disponibilidade ou capacidade máxima. |
| RNF10 | Preservar a licença do projeto e os avisos autorais dos componentes de terceiros distribuídos com o código. |
