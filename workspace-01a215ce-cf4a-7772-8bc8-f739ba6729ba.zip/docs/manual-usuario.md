# Guia do usuário — Y Finance

Como abrir e usar o projeto no Windows, com a pasta **workspace na Área de Trabalho**.

## Antes de começar

- Tenha **Node.js com npm instalado** e **MySQL instalado e ligado**. Versões: Node 20.19+ da série 20 ou 22.12+; MySQL 8.0.16+ da série 8.x.
- O acesso MySQL informado é **usuário `root` e senha `root`**, para uso local. Não exponha esse acesso à internet.
- Substitua **`PORTA_REAL_DO_MYSQL`** nos comandos pelo número da porta do seu MySQL. Se não souber, peça ao responsável pelo computador.

Não é preciso abrir Workbench, editar arquivos ou criar o banco manualmente.

## Como abrir o Prompt de Comando

1. Pressione **Windows+D** e dê **dois cliques na pasta workspace**, já extraída.
2. Confira se ela contém `README.md`, `docs`, `imagens` e `codigo-fonte`.
3. Pressione **Alt+D**, digite **`cmd`** e aperte **Enter**.

O Prompt abrirá na pasta certa. Digite **uma linha por vez** e aperte **Enter**. Para colar, use **Ctrl+V** ou o **botão direito**.

Sempre que o guia pedir um **Prompt novo**, volte à pasta `workspace` no Explorador e repita **Alt+D → `cmd` → Enter**.

---

## Passo 1: instalar as dependências

Faça isso **uma vez por computador**, com internet.

Abra um Prompt na pasta `workspace` e execute:

```bat
cd codigo-fonte\yfinance
npm install
```

**O que esperar:** a instalação termina e a linha para digitar reaparece. Se houver erro, resolva antes de continuar. Depois, digite `exit` e aperte **Enter** para fechar a janela.

---

## Passo 2: ligar o sistema — três janelas

Abra **três Prompts novos**, todos pela pasta `workspace`. Execute somente o bloco correspondente em cada janela.

### Janela 1: API

Substitua `PORTA_REAL_DO_MYSQL` antes de executar:

```bat
cd codigo-fonte\yfinance
set DB_HOST=127.0.0.1
set DB_PORT=PORTA_REAL_DO_MYSQL
set DB_USER=root
set DB_PASSWORD=root
set DB_NAME=yfinance
node scripts\start-local-api.js
```

**O que esperar:** `Y Finance API ouvindo em http://localhost:5174`.

O banco e as tabelas são preparados automaticamente, sem dados fictícios. Se já existirem, seus registros são preservados. As linhas `set` normalmente não exibem mensagem e valem apenas nessa janela.

### Janela 2: site principal

```bat
cd codigo-fonte\yfinance
npx vite --config vite.local.config.js --host 0.0.0.0 --port 5173 --strictPort
```

**O que esperar:** `Local: http://localhost:5173/`.

### Janela 3: landing page

```bat
cd codigo-fonte\yfinance
npx vite --config vite.local.config.js --mode landing --host 0.0.0.0 --port 5175 --strictPort
```

**O que esperar:** `Local: http://localhost:5175/`.

**Deixe as três janelas abertas.** Pode minimizar pelo botão **—**, mas não fechar pelo **X**. Elas ficam ocupadas pelos servidores; não digite o próximo bloco na mesma janela. Não é necessário executar build ou `npm start`.

---

## Passo 3: entrar no site

Abra o navegador, pressione **Ctrl+L**, digite **`http://localhost:5173`** e aperte **Enter**.

**Primeiro acesso:**

1. Clique em **Criar conta**.
2. Preencha **Nome**, **E-mail**, **Senha** e **Confirmar senha**. Use uma senha de pelo menos 8 caracteres.
3. Leia os termos, marque a caixa de aceite e clique em **Criar conta**.

A conta começa vazia e já pode ser usada normalmente. Não é necessário preparar uma demonstração.

**Já tem conta?** Preencha e-mail e senha do cadastro e clique em **Entrar**. Essa senha não é a senha do MySQL.

**Landing page:** pressione **Ctrl+T** e acesse **`http://localhost:5175`**. Ela é informativa; o cadastro e o uso da conta ficam no site principal, em **5173**.

---

## Passo 4: encerrar e abrir novamente

**Para encerrar:**

1. No site, clique em **Configurações → Sair da conta**.
2. Em cada Prompt, pressione **Ctrl+C**. Se houver texto selecionado, pressione **Esc** antes.
3. Se pedir confirmação, digite a letra indicada e aperte **Enter**. Depois, feche a janela.

**Para abrir novamente:** mantenha o MySQL ligado e repita apenas os **passos 2 e 3**, incluindo as linhas `set`. Não precisa instalar de novo ou cadastrar outra conta. Seus dados continuam no banco.

Não apague o banco nem a pasta `data/`.

---

## Problemas comuns

| Problema | O que fazer |
| --- | --- |
| `node` ou `npm` não reconhecido | Peça ao responsável para corrigir a instalação e reabra o Prompt. |
| `package.json` não encontrado | Abra o Prompt em `workspace` e execute `cd codigo-fonte\yfinance`. |
| `Access denied` | Confira o usuário e a senha do MySQL. |
| Falha na conexão com o banco | Confira se o MySQL está ligado e se substituiu `PORTA_REAL_DO_MYSQL` pelo número correto. |
| Porta em uso ou outra API ativa | Encerre as janelas antigas do projeto antes de abrir novas. |
| Estrutura do banco incompatível | Não apague nem force a recriação. Peça ajuda ao responsável. |
| Site não abre | Confira se as três janelas estão abertas e mostram os endereços esperados. |
| Painel vazio após cadastro | É normal: cadastre seus próprios lançamentos. |

Se precisar de ajuda, envie somente a mensagem de erro, sem senhas ou dados pessoais.

*Validação realizada em Linux com MySQL isolado. A execução no Windows do usuário ainda precisa ser confirmada.*
