# Arquitetura

[Início](../README.md) · [Requisitos](requisitos.md) · [Banco de dados](banco-de-dados.md)

## 1. Visão geral

React no navegador, Node.js/Express no servidor e MySQL/InnoDB na persistência. O modo local do manual usa três processos: API em 5174, site principal em 5173 e landing page em 5175.

```text
Navegador → Vite :5173 → /api (proxy) → Express :5174 → mysql2 → MySQL
Navegador → Vite :5175 → landing page
```

O navegador chama `/api` na mesma origem do site; o Vite encaminha as solicitações preservando Host e Origin. A autenticação por cookie e as verificações CSRF permanecem na API, sem liberar CORS. As portas locais são configuráveis no `.env`; a porta MySQL é independente.

O modo integrado foi preservado: `npm run dev` usa Vite como middleware; `npm run build` e `npm start` servem `dist/` e API pelo Express, em `PORT` (padrão 3000). Apenas uma API pode usar cada banco. Os componentes React são funcionais; não há versão móvel nativa.

## 2. Organização do código

Caminhos relativos a `codigo-fonte/yfinance/`:

| Caminho em `codigo-fonte/yfinance/` | Responsabilidade |
| --- | --- |
| `server.js` | Inicialização do servidor, rotas, ações, relatórios, importação, chat e gravação |
| `src/main.jsx` | Entrada React, navegação, finanças, formulários e integração das telas |
| `src/account-api.js` | Requisições relativas `/api/`, contexto de conta, CSRF e tratamento de sessão |
| `src/AuthPage.jsx`, `src/AccountCenter.jsx` | Cadastro/login, conta, segurança, recuperação e biblioteca |
| `src/FinanceTools.jsx`, `src/ExcelImport.jsx` | Recorrências, notificações, exportação/importação Excel |
| `src/EducationHub.jsx`, `src/Simulators.jsx` | Educação, progresso e cálculos simulados |
| `src/*-model.js` | Regras de orçamento, calendário, simulação, comparação e revisão |
| `lib/account-security.js`, `lib/security-core.js` | Autenticação, preferências, consentimentos, TOTP e proteção de segredos |
| `lib/automation.js` | Automação recorrente |
| `lib/database.js`, `lib/mysql-store.js`, `lib/mysql-schema.js`, `lib/schema-validation.js` | Configuração, repositório SQL, transações, mapeamento e trava MySQL |
| `lib/request-gate.js` | Fila de requisições e manutenção; aguarda cada operação terminar |
| `database/schema.sql` | Definição das 12 tabelas MySQL |
| `lib/database-lock.js` | Trava de arquivo usada apenas nos testes com JSON |
| `lib/reports.js`, `lib/excel-import.js`, `lib/import-worker.js` | Arquivos XLSX, validação e análise isolada em worker |
| `lib/local-assistant.js` e módulos auxiliares | Respostas locais, contexto, cálculos e conhecimento do projeto |
| `lib/educational-library.js` | Catálogo e artigos da biblioteca |
| `public/` | Logo, favicons, fontes locais e licença tipográfica |
| `scripts/` | Instalação do banco, conta demonstrativa, recuperação de acesso e testes MySQL |
| `scripts/start-local-api.js`, `scripts/local-ports.js` | Inicialização da API separada e validação das três portas locais |
| `scripts/configure-local.js`, `lib/local-setup.js` | Configuração interativa pelo terminal, preparação não destrutiva do banco/usuário e gravação do `.env`; senha administrativa não é salva |
| `scripts/create-demo.js` | Demonstração opcional com variáveis de ambiente e `--sim`; acrescenta a conta pública sem apagar contas ou registros |
| `lib/local-database.js` | Preparação automática local de banco e tabelas vazias na abertura da API, com validação de schema e bloqueio de concorrência; não cria demonstração nem grava credenciais |
| `vite.local.config.js` | Servidores do site/landing page, proxy `/api` e bloqueio de arquivos privados |
| `tests/` | Testes automatizados com instalações temporárias e dados fictícios |

O servidor também importa modelos de `src/`; a pasta deve ser mantida após o build.

## 3. API

São 32 combinações de método e caminho, com prefixo `/api`. O formato padrão é JSON; relatórios retornam XLSX e a prévia de importação recebe o arquivo binário. Na tabela, rotas sem método explícito seguem o último método indicado na mesma célula.

| Grupo | Método e rota |
| --- | --- |
| Público | `GET /access`, `GET /legal`, `POST /bootstrap` |
| Autenticação | `POST /auth/register`, `/auth/login`, `/auth/claim-legacy`, `/auth/verify-2fa`, `/auth/request-reset`, `/auth/reset-password` |
| Sessão/estado | `POST /logout`, `GET /state`, `POST /action` |
| Conta | `GET /account`, `POST /legal/accept`, `/account/preferences`, `/account/password`, `/account/sessions/revoke`, `/account/delete` |
| 2FA | `POST /account/2fa/setup`, `/account/2fa/enable`, `/account/2fa/disable`, `/account/2fa/recovery` |
| Privacidade/biblioteca | `GET /privacy/export`, `GET /library`, `GET /library/:id` |
| Excel | `POST /reports`, `/imports/preview`, `/imports/cancel`, `/imports/commit`, `/imports/undo`; `GET /imports/backup/:id` |
| Assistente | `POST /chat` |

`POST /action` recebe `{ action, payload }`, por exemplo `transaction.save`, `goal.deposit` ou `budget.save`. A API valida campos e vínculos com a conta autenticada.

Códigos de erro: 400 (validação), 401 (autenticação), 403 (acesso proibido), 404 (recurso ausente), 409 (conflito), 413 (limite de envio), 429 (limite de tentativas), 500 (falha interna) e 503 (SMTP indisponível).

## 4. Segurança

- Senhas com bcrypt; sessão em cookie HttpOnly e hash no servidor.
- Expiração em 12 horas ou 30 minutos sem atividade na API; consultas automáticas contam como atividade.
- Validação de origem, CSRF e contexto da conta nas alterações autenticadas.
- 2FA TOTP com proteção contra reutilização, segredo cifrado com AES-GCM e códigos de recuperação de uso único armazenados por hash.
- Importação XLSX com verificação de proprietário, assinatura, estrutura e análise limitada em Worker.
- Credenciais e chaves fora da interface; CSP restrita à própria origem para conexões.

## 5. Integrações e ambiente

SMTP e IA externa são opcionais e não foram configurados no ambiente validado. O assistente local funciona sem eles. Variáveis em `.env` ou no ambiente do servidor:

| Variáveis | Finalidade |
| --- | --- |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | Conexão MySQL privada; nunca expor no frontend |
| `PRIVACY_CONTROLLER`, `PRIVACY_CONTACT` | Responsável real e canal de privacidade exibidos nos documentos legais |
| `PORT`, `NODE_ENV` | Porta e modo da execução integrada |
| `LOCAL_API_PORT`, `LOCAL_SITE_PORT`, `LOCAL_LANDING_PORT` | Portas do modo local em três janelas; padrões 5174, 5173 e 5175 |
| `APP_PUBLIC_URL`, `COOKIE_SECURE`, `TRUST_PROXY_HOPS`, `FRAME_ANCESTORS` | URL pública, cookies, proxy confiável e enquadramento |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | E-mail opcional; configuração segura e URL HTTPS necessárias |
| `AI_API_KEY`, `AI_API_URL`, `AI_MODEL`, `AI_PROVIDER_NAME`, `AI_PROVIDER_PRIVACY_URL` | IA externa opcional; requer configuração e autorização do titular |

## 6. Landing page

`codigo-fonte/yfinance-landing/index.html` é uma página informativa independente, com recursos embutidos e sem acesso às contas.

## 7. Diagramas entregues

13 imagens PNG geradas com PlantUML, em `imagens/diagramas/`.

| Diagrama | Imagem |
| --- | --- |
| 01 — Atividades da interface do site | [Abrir PNG](../imagens/diagramas/01_Atividades_Interface_Site.png) |
| 02 — Objetos e estado da interface do site | [Abrir PNG](../imagens/diagramas/02_Objetos_Estado_Interface_Site.png) |
| 03 — Objetos e estruturas do servidor | [Abrir PNG](../imagens/diagramas/03_Objetos_Estruturas_Servidor.png) |
| 04 — Estrutura modular do servidor | [Abrir PNG](../imagens/diagramas/04_Estrutura_Modular_Servidor.png) |
| 05.1 — Casos de uso: acesso, segurança e privacidade | [Abrir PNG](../imagens/diagramas/05_Casos_De_Uso.png) |
| 05.2 — Casos de uso: finanças, aprendizagem e operação | [Abrir PNG](../imagens/diagramas/05_Casos_De_Uso_Parte_02.png) |
| 06 — Componentes da interface do site | [Abrir PNG](../imagens/diagramas/06_Componentes_Interface_Site.png) |
| 07.1 — Modelo lógico MySQL: finanças e integridade referencial | [Abrir PNG](../imagens/diagramas/07_MER_Logico.png) |
| 07.2 — Modelo lógico MySQL: conta, segurança e versão do schema | [Abrir PNG](../imagens/diagramas/07_MER_Logico_Parte_02.png) |
| 07.3 — Modelo lógico MySQL: aprendizagem, mensagens e histórico | [Abrir PNG](../imagens/diagramas/07_MER_Logico_Parte_03.png) |
| 08.1 — Modelo conceitual: organização financeira | [Abrir PNG](../imagens/diagramas/08_MER_Conceitual.png) |
| 08.2 — Modelo conceitual: aprendizagem, acesso e privacidade | [Abrir PNG](../imagens/diagramas/08_MER_Conceitual_Parte_02.png) |
| 09 — Fluxo de processamento da API | [Abrir PNG](../imagens/diagramas/09_Fluxo_Processamento_API.png) |

## Referências

[Node.js](https://nodejs.org/api/) · [Express](https://expressjs.com/) · [React](https://react.dev/) · [Vite](https://vite.dev/guide/) · [MySQL](https://dev.mysql.com/doc/refman/8.4/en/) · [mysql2](https://sidorares.github.io/node-mysql2/docs)
