# Projeto Interdisciplinar Y Finance

**Site de gestão e educação financeira pessoal · Versão 2.1.0**

O Y Finance reúne receitas, despesas, orçamento, metas, recorrências e educação financeira. Inclui 17 aulas, simuladores, biblioteca, assistente local e relatórios Excel. Todos os recursos são gratuitos para contas cadastradas. O site não acessa bancos nem realiza pagamentos.

## Execução

Requisitos: Node.js `^20.19.0 || >=22.12.0` com npm, MySQL 8.0.16+ na série 8.x (recomendado 8.4 LTS) e navegador atualizado. Use uma versão LTS suportada do Node compatível com esse intervalo.

Siga os blocos do [manual](docs/manual-usuario.md), mantendo a organização atual das pastas. O fluxo principal usa comandos diretos, sem configurador interativo nem editor de texto:

1. Em `codigo-fonte/yfinance`, instale as dependências com `npm install`.
2. Abra três terminais e execute os blocos do **passo 2 do manual**. A abertura da API prepara automaticamente o banco e as tabelas vazias, se necessário; não é preciso preparar demonstração antes.
3. Acesse o site e cadastre ou entre na sua conta, conforme o **passo 3 do manual**.

Comandos de inicialização:

| Janela | Inicialização dentro de `codigo-fonte/yfinance` | Endereço |
| --- | --- | --- |
| API | Variáveis `set DB_*` e `node scripts/start-local-api.js` | http://localhost:5174 |
| Site principal | `npx vite --config vite.local.config.js --host 0.0.0.0 --port 5173 --strictPort` | http://localhost:5173 |
| Landing page | `npx vite --config vite.local.config.js --mode landing --host 0.0.0.0 --port 5175 --strictPort` | http://localhost:5175 |

Abra **http://localhost:5173** e clique em **Criar conta** para cadastrar seu próprio acesso, ou entre com uma conta existente. Não é necessário criar a demonstração antes. Mantenha o MySQL e os três terminais ligados. Não é necessário build. Use a porta real do MySQL e não publique as linhas com senhas.

O modo integrado anterior continua disponível: `npm run build` e `npm start`, usando `PORT` (padrão 3000). **Escolha um modo por vez: nunca inicie duas APIs para o mesmo banco.**

### Conta demonstrativa

- E-mail: `professor@yfinance.test`
- Senha: `YFinance@Teste2026!`

A demonstração só é criada quando solicitada. O seed cria 198 movimentações fictícias e preserva a conta se ela já existir. **Os dados são compartilhados: não use informações pessoais.** Uma conta própria começa sem movimentações ou progresso preenchidos.

## Organização

```text
README.md
LICENSE
.gitignore
docs/
  requisitos.md
  arquitetura.md
  banco-de-dados.md
  testes.md
  manual-usuario.md
imagens/
  logo/
  diagramas/
  telas/
    site-principal/   # 23 capturas enviadas pelo grupo
    landing-page/     # 8 capturas enviadas pelo grupo
videos/
  link-video.txt
codigo-fonte/
  yfinance/
  yfinance-landing/
```

## Documentação

| Arquivo | Conteúdo |
| --- | --- |
| [Requisitos](docs/requisitos.md) | Requisitos funcionais e não funcionais |
| [Arquitetura](docs/arquitetura.md) | Componentes, API, segurança e diagramas |
| [Banco de dados](docs/banco-de-dados.md) | Informações básicas e descrição das tabelas |
| [Testes](docs/testes.md) | Testes de uso executados e resultados |
| [Manual](docs/manual-usuario.md) | Instalação, uso e solução de problemas |

## Imagens e vídeo

- [Telas do site principal](imagens/telas/site-principal/): 23 capturas em PNG, extraídas de `telas YFinance.pdf`.
- [Telas da landing page](imagens/telas/landing-page/): 8 capturas em PNG, extraídas de `Prints LandingPage YFinance.pdf`.
- [Vídeo do projeto no YouTube](https://youtu.be/weFqpbNgT0E): o endereço também está salvo em [videos/link-video.txt](videos/link-video.txt). Não há uma cópia MP4 no projeto; o acesso exige internet.
- [13 diagramas PNG](docs/arquitetura.md#7-diagramas-entregues), [logo](imagens/logo/) e [código da landing page](codigo-fonte/yfinance-landing/index.html).

As novas capturas mantêm a resolução original e a ordem dos PDFs, com nomes descritivos. As quatro capturas de validação anteriores foram preservadas em `imagens/telas/`. Revise os dados visíveis nas telas antes de publicar o repositório.

## Equipe e licença

- Levi Nathanael Mendes Sousa — 3B
- Pedro Henrique Coneglian de Arruda — 3B
- Vitor Silva Souza — 3B
- Vítor Oliveira Rangel — 3B

Consulte [LICENSE](LICENSE). As licenças das dependências e fontes acompanham os respectivos recursos.

## Entrega

Um integrante deve enviar um documento de texto com a URL do repositório e conferir o acesso do professor.

Não publique `.env`, `data/`, dumps privados, chaves, dados pessoais, `node_modules/`, `dist/` ou diretórios internos do ambiente. O projeto está preparado para execução local; os cenários de uso verificados estão em [Testes](docs/testes.md).
